'use strict';

// Concept collection: actual product specifications and placement are confirmed on inquiry.
window.LUNIC_VASTU = [
  {
    "id": "pyramid",
    "name": "Copper Vastu Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu.webp",
    "subtitle": "A small ritual for the spaces you call home.",
    "description": "An architectural copper pyramid with a square base and a warm, polished surface. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper finish",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper pyramid",
      "tamba",
      "तांबा"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-pyramid",
    "name": "Brass Vastu Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-pyramid.webp",
    "subtitle": "A warm point of focus.",
    "description": "A single square-based brass pyramid with clean edges and a softly brushed golden finish. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Brass-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "peetal pyramid",
      "पीतल"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "quartz-pyramid",
    "name": "Clear Quartz Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/quartz-pyramid.webp",
    "subtitle": "Geometry, held in a little light.",
    "description": "A single transparent clear quartz pyramid, with polished triangular faces, subtle internal veils and a square base. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Clear quartz concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "sphatik pyramid",
      "sphatika",
      "crystal pyramid",
      "स्फटिक"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "amethyst-pyramid",
    "name": "Amethyst Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/amethyst-pyramid.webp",
    "subtitle": "A violet accent for a quiet corner.",
    "description": "A single polished amethyst pyramid with translucent violet colour and natural-looking pale mineral bands. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Amethyst concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "purple pyramid"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "rose-quartz-pyramid",
    "name": "Rose Quartz Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/rose-quartz-pyramid.webp",
    "subtitle": "A softer expression of form.",
    "description": "A single polished pale pink rose quartz pyramid with gently clouded translucency. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Rose quartz concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "pink pyramid"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "nine-pyramid-plate",
    "name": "Nine-Pyramid Copper Plate",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/nine-pyramid-plate.webp",
    "subtitle": "Nine small forms. One composition.",
    "description": "A square copper plate bearing exactly nine small raised copper pyramids arranged in a precise three-by-three grid. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "9 pyramid plate",
      "nine pyramids"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "eightyone-pyramid-plate",
    "name": "81-Pyramid Copper Plate",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/eightyone-pyramid-plate.webp",
    "subtitle": "A finely ordered geometric field.",
    "description": "A square copper plate bearing a regular nine-by-nine grid of eighty-one small raised pyramids. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "81 pyramid plate",
      "eighty one pyramids"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "three-layer-pyramid",
    "name": "Three-Layer Copper Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/three-layer-pyramid.webp",
    "subtitle": "Layers of considered geometry.",
    "description": "A stepped copper Vastu pyramid made of three nested square tiers with a small pyramidal apex. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "3 layer pyramid",
      "multilayer pyramid"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "copper-helix",
    "name": "Copper Vastu Helix",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/copper-helix.webp",
    "subtitle": "A simple curve, thoughtfully placed.",
    "description": "A single upright copper helix with three broad smooth coils rising from a small circular metal foot. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Copper-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper coil",
      "tamba helix"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-helix",
    "name": "Brass Vastu Helix",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-helix.webp",
    "subtitle": "A sculptural line in warm brass.",
    "description": "A single upright brass helix with three smooth coils and a small circular metal foot. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Brass-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "brass coil",
      "peetal helix"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "zinc-helix",
    "name": "Zinc Vastu Helix",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/zinc-helix.webp",
    "subtitle": "A cool metallic counterpoint.",
    "description": "A single upright satin silver-grey zinc helix with three smooth coils and a small circular foot. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Zinc-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "zinc coil",
      "silver grey helix"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "copper-vastu-strip",
    "name": "Copper Vastu Strip",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/copper-vastu-strip.webp",
    "subtitle": "A detail to discuss with your space.",
    "description": "A neat coil of narrow flat copper strip with one short gently curved tail revealing the thin rectangular profile. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Copper-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper tape",
      "copper patti",
      "metal strip"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-vastu-strip",
    "name": "Brass Vastu Strip",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-vastu-strip.webp",
    "subtitle": "A warm metallic line.",
    "description": "A neat coil of narrow flat golden brass strip with one short gently curved tail revealing the thin rectangular profile. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Brass-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "brass tape",
      "brass patti",
      "metal strip"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "aluminium-vastu-strip",
    "name": "Aluminium Vastu Strip",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/aluminium-vastu-strip.webp",
    "subtitle": "A restrained silver-toned finish.",
    "description": "A neat coil of narrow flat satin aluminium strip with a short gently curved tail revealing the thin rectangular profile. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Aluminium-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "aluminum strip",
      "aluminium tape",
      "silver metal strip"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "copper-vastu-plate",
    "name": "Copper Vastu Plate",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/copper-vastu-plate.webp",
    "subtitle": "An elemental surface, simply made.",
    "description": "A single thick square copper plate with bevelled edges and a subtly hammered, uninscribed surface, standing at a slight backward lean. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Copper-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper sheet",
      "tamba plate"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-vastu-plate",
    "name": "Brass Vastu Plate",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-vastu-plate.webp",
    "subtitle": "A considered square of warm metal.",
    "description": "A single thick square brass plate with bevelled edges and a softly brushed, uninscribed surface, standing at a slight backward lean. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Brass-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "brass sheet",
      "peetal plate"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-tortoise",
    "name": "Brass Tortoise",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-tortoise.webp",
    "subtitle": "A small sculptural moment.",
    "description": "A single low brass tortoise sculpture with four visible feet, a domed patterned shell and a gently extended head. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "turtle",
      "kachhua",
      "कछुआ"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "crystal-tortoise",
    "name": "Crystal Tortoise",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/crystal-tortoise.webp",
    "subtitle": "A familiar form, full of light.",
    "description": "A single clear quartz tortoise carving with a translucent domed shell, four feet and a gently extended head. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Clear quartz concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "crystal turtle",
      "sphatik tortoise",
      "kachhua"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "kamadhenu",
    "name": "Kamadhenu Cow & Calf",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/kamadhenu.webp",
    "subtitle": "A tender composition for a sacred corner.",
    "description": "One brass sculpture group of a standing Indian cow and a small calf nuzzling beside her, both on a single low oval brass base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "kamdhenu",
      "cow calf",
      "gaumata",
      "कामधेनु"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "elephant-pair",
    "name": "Brass Elephant Pair",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/elephant-pair.webp",
    "subtitle": "Two forms, in quiet company.",
    "description": "A matching pair of small Indian brass elephant sculptures with gently raised trunks, standing side by side. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "hathi",
      "elephants",
      "हाथी"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "sun-plaque",
    "name": "Brass Surya Plaque",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/sun-plaque.webp",
    "subtitle": "A little solar warmth for your space.",
    "description": "A circular brass wall plaque of a serene traditional Indian sun face surrounded by a symmetrical ring of gently curling rays, standing against a discreet support. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "sun face",
      "surya",
      "सूर्य"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "om-symbol",
    "name": "Brass Om Symbol",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/om-symbol.webp",
    "subtitle": "A familiar symbol, thoughtfully displayed.",
    "description": "A single freestanding traditional Devanagari Om symbol, ॐ, cast in warm brass on a minimal narrow rectangular base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "aum",
      "omkar",
      "ॐ"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "swastik-symbol",
    "name": "Brass Swastik Symbol",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/swastik-symbol.webp",
    "subtitle": "An auspicious form for a considered entrance.",
    "description": "A traditional Hindu brass puja plaque with an upright sacred swastik, four small dots and a circular lotus-petal border. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "swastika",
      "svastika",
      "स्वस्तिक"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "running-horse",
    "name": "Brass Running Horse",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/running-horse.webp",
    "subtitle": "Movement, captured in a sculptural line.",
    "description": "A single graceful brass horse sculpture in a running pose with flowing mane and tail, supported on a low integral oval base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "horse",
      "ghoda",
      "अश्व"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-camel",
    "name": "Brass Camel",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-camel.webp",
    "subtitle": "A distinctive silhouette in warm brass.",
    "description": "A single elegant brass one-humped camel sculpture standing on four legs with a slender curved neck and simple understated surface detail. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "camel",
      "oont",
      "ऊंट"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-deer",
    "name": "Brass Deer",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-deer.webp",
    "subtitle": "A light-footed sculptural accent.",
    "description": "A single graceful brass deer sculpture with a slender neck, small branching antlers and four legs on a discreet low base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "deer",
      "hiran",
      "हिरण"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "rabbit-pair",
    "name": "Brass Rabbit Pair",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/rabbit-pair.webp",
    "subtitle": "A gentle pair for a personal corner.",
    "description": "A matching pair of small seated brass rabbit sculptures with long upright ears and softly rounded bodies. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "rabbits",
      "hare",
      "khargosh",
      "खरगोश"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-eagle",
    "name": "Brass Eagle",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-eagle.webp",
    "subtitle": "A sculptural study in wings and form.",
    "description": "A single brass eagle sculpture with wings partly spread, perched on a low sculpted rock-like brass base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "eagle",
      "bird",
      "garuda"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "quartz-sphere",
    "name": "Clear Quartz Sphere",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/quartz-sphere.webp",
    "subtitle": "A quiet orbit of reflected light.",
    "description": "A single polished transparent clear quartz sphere with fine natural-looking internal veils, resting in a discreet low brass ring cradle. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Clear quartz concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "sphatik ball",
      "crystal ball",
      "quartz ball"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "rose-quartz-tree",
    "name": "Rose Quartz Tree",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/rose-quartz-tree.webp",
    "subtitle": "A small tree in the softest pink.",
    "description": "A small decorative tree of delicate copper wire branches bearing pale pink rose quartz chip leaves, rooted in a low rough dark stone base. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Rose quartz concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "pink crystal tree",
      "rose quartz bonsai"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "citrine-tree",
    "name": "Citrine Crystal Tree",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/citrine-tree.webp",
    "subtitle": "A warm little canopy of colour.",
    "description": "A small decorative tree of copper wire branches bearing translucent honey-yellow citrine chip leaves, rooted in a low rough dark stone base. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Citrine concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "yellow crystal tree",
      "citrine bonsai"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "seven-stone-tree",
    "name": "Seven-Stone Crystal Tree",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/seven-stone-tree.webp",
    "subtitle": "A little colour for your everyday.",
    "description": "A small decorative copper wire tree with seven distinct clusters of crystal chip leaves in violet, indigo, blue, green, yellow, orange and red, on a low rough stone base. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Mixed-stone concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "seven chakra tree",
      "7 stone tree",
      "rainbow tree"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "quartz-point",
    "name": "Clear Quartz Point",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/quartz-point.webp",
    "subtitle": "A natural-looking point of focus.",
    "description": "A single upright clear quartz point with six prismatic sides and a naturally formed pointed termination, showing subtle translucent internal veils. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Clear quartz concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "crystal pencil",
      "sphatik point",
      "quartz tower"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "black-tourmaline",
    "name": "Black Tourmaline Cluster",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/black-tourmaline.webp",
    "subtitle": "A dark, tactile mineral accent.",
    "description": "A single compact cluster of intergrown jet-black tourmaline prismatic crystals with realistic vertical striations and slightly uneven terminations. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Black tourmaline concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "schorl",
      "black crystal",
      "tourmaline"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "salt-lamp",
    "name": "Rock Salt Lamp",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/salt-lamp.webp",
    "subtitle": "A small pool of amber light.",
    "description": "An irregular pink-orange rock salt lamp glowing softly from within, mounted on a low round dark wooden foot, with the electrical cable discreetly out of view. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Rock-salt concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "himalayan salt lamp",
      "pink salt light"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "salt-bowl",
    "name": "Rock Salt Bowl",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/salt-bowl.webp",
    "subtitle": "A tactile accent in warm mineral tones.",
    "description": "A single shallow carved pink-orange rock salt bowl holding a small handful of matching rough salt chunks as one product set. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Rock-salt concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "salt energizer",
      "salt bowl",
      "sendha namak",
      "सेंधा नमक"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "tabletop-fountain",
    "name": "Tabletop Water Fountain",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/tabletop-fountain.webp",
    "subtitle": "A little movement for a considered corner.",
    "description": "A compact tabletop fountain made of three small staggered copper bowls on a dark charcoal stone structure above an integrated round basin, with a thin gentle stream of water linking the bowls. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Stone & copper concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "water feature",
      "indoor fountain",
      "waterfall"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-diya",
    "name": "Brass Diya",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/brass-diya.webp",
    "subtitle": "A small vessel for a daily ritual.",
    "description": "A single small traditional brass oil lamp with a shallow leaf-shaped oil bowl, one short wick spout and a low pedestal foot, shown unlit. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "deepak",
      "oil lamp",
      "दीया"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "brass-bell",
    "name": "Brass Puja Bell",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/brass-bell.webp",
    "subtitle": "A resonant detail for your sacred space.",
    "description": "A single traditional Indian brass hand bell with a flared rounded skirt, slim turned handle and small simple lotus finial. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "ghanti",
      "hand bell",
      "puja bell",
      "घंटी"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "copper-kalash",
    "name": "Copper Kalash",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/copper-kalash.webp",
    "subtitle": "A warm vessel for a personal altar.",
    "description": "A single traditional empty copper kalash vessel with a rounded belly, narrow neck and flared rim, with subtle hand-hammered texture. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Copper-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "kalasha",
      "lota",
      "water vessel",
      "कलश"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "incense-holder",
    "name": "Brass Incense Holder",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/incense-holder.webp",
    "subtitle": "A considered place for a familiar ritual.",
    "description": "A single slender leaf-shaped brass incense holder with an ash-catching channel and one small incense socket, shown without incense or smoke. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "agarbatti stand",
      "incense tray",
      "अगरबत्ती"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "dhoop-burner",
    "name": "Brass Dhoop Burner",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/dhoop-burner.webp",
    "subtitle": "A sculptural vessel for your ritual corner.",
    "description": "A single small brass dhoop burner with a perforated domed lid, lotus-like lower bowl, three short feet and a tiny finial, shown empty and unlit. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "loban burner",
      "sambrani",
      "dhoop holder",
      "धूप"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "conch-stand",
    "name": "Shankha on Brass Stand",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/conch-stand.webp",
    "subtitle": "A familiar ritual form, gently held.",
    "description": "A single uninscribed ivory-white spiral conch shell with a natural elongated taper and warm cream opening, resting horizontally on a simple low brass cradle stand. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Shell & brass concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "shankh",
      "conch",
      "shankha",
      "शंख"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "wind-chime",
    "name": "Five-Tube Brass Wind Chime",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/wind-chime.webp",
    "subtitle": "A gentle detail for an open corner.",
    "description": "One elegant wind chime with exactly five slender vertical brass tubes suspended from a dark round wooden cap, a small central striker and a slim dark wind sail, hanging from a discreet thin black display stand. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "chime",
      "hanging bells",
      "windchime"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "brass-urli",
    "name": "Brass Urli Bowl",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/brass-urli.webp",
    "subtitle": "A simple vessel for a welcoming space.",
    "description": "A single broad shallow circular brass urli bowl with two small curved side handles and a gently hammered surface, shown empty. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "uruli",
      "urlis",
      "decorative bowl",
      "उरली"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  }
];
