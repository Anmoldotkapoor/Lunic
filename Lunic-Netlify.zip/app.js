'use strict';

const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const money = (amount) => `₹${amount.toLocaleString('en-IN')}`;

function productEnquiryUrl(product) {
  const phone = String(window.LUNIC_CONFIG?.whatsappNumber || '').replace(/\D/g,'');
  const message = `Hello Lunic,\n\nI’d like to enquire about ${product.name}.\nPlease share the price, availability and product details.\n\nThank you.`;
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

const consultations = [
  {id:'prashna',name:'Chandra Prashna',subtitle:'One question. A clear intention.',price:1100,duration:'One focused query',moon:'crescent',description:'A specific question through Prashna, or Muhurta guidance for a meaningful new beginning.',features:['Prashna or Muhurta','One focused question'],intention:'timing'},
  {id:'crescent',name:'Crescent',subtitle:'Your first light of clarity',price:2100,duration:'15 minutes',moon:'quarter',description:'An introduction to your birth chart, with a thoughtful look at one area of your life.',features:['15-minute personal reading','One life area, explored'],intention:'direction'},
  {id:'moonrise',name:'Moonrise',subtitle:'A deeper kind of perspective',price:5100,duration:'30 minutes',moon:'gibbous',description:'Connect the patterns in your chart, current dashas and the questions shaping your next chapter.',features:['30-minute in-depth reading','Connected themes & guidance'],intention:'deeper',featured:true},
  {id:'purnima',name:'Purnima',subtitle:'The fullness of your story',price:11000,duration:'45 minutes',moon:'full',description:'Space for the bigger picture. Explore your chart, planetary periods and personal priorities in depth.',features:['45-minute comprehensive reading','Your chart, timing & priorities'],intention:'deeper'},
  {id:'tarot',name:'Lunar Tarot',subtitle:'A little light from the cards',price:3100,duration:'30 minutes',moon:'tarot',description:'A moon-inspired space to explore your questions through Tarot. Reflect on the cards, your present circumstances and the possibilities you’d like to consider.',features:['30-minute personal Tarot reading','Your questions & card symbolism'],intention:'reflection'},
  {id:'reserve',name:'Soma Reserve',subtitle:'Your private lunar consultation',price:21000,duration:'Duration agreed personally',moon:'reserve',description:'Our private Jyotish consultation, shaped around the questions and life themes you want to explore in depth. Scope, duration and appointment are agreed personally before confirmation.',features:['A bespoke private consultation','Personal scope & appointment'],intention:'private',vip:true}
];

const originalProducts = [
  {id:'moonstone',name:'Moonstone Sphere',category:'gemstones',categoryLabel:'THE LUNAR COLLECTION',tag:'MOON-INSPIRED',image:'moonstone.webp',subtitle:'A soft reminder to return to yourself.',description:'A milky, luminous moonstone sphere for a reflective corner, a personal altar or a moment of quiet. Its gentle shimmer echoes the changing light of the moon.',details:['Moonstone','Decorative sphere','Personal ritual'],tradition:'Moonstone is often associated with lunar symbolism in contemporary spiritual practice. For chart-specific gemstone guidance, begin with a personal consultation.'},
  {id:'meru',name:'Sri Meru Yantra',category:'yantras',categoryLabel:'SACRED GEOMETRY',tag:'TIMELESS TRADITION',image:'yantra.webp',subtitle:'An invitation to centre your intention.',description:'A three-dimensional interpretation of the Sri Yantra, with ascending geometric tiers and a warm brass finish. A meaningful focal point for meditation and a thoughtfully arranged sacred space.',details:['Brass finish','Sacred geometry','Meditation space'],tradition:'The Sri Yantra is a revered form in the Shakta tradition. Placement and worship practices vary; personal guidance is available on inquiry.'},
  {id:'pearl',name:'Chandra Pearl',category:'gemstones',categoryLabel:'THE CHANDRA EDIT',tag:'LUNAR LUMINOSITY',image:'pearl.webp',subtitle:'Quiet beauty, in its most luminous form.',description:'A luminous pearl, traditionally associated with Chandra in Jyotish. Explore it as a meaningful keepsake or ask about a personal gemstone recommendation before choosing it as an astrological remedy.',details:['Pearl','Chandra symbolism','Personal selection'],tradition:'Pearls have a traditional association with the Moon in Jyotish. Suitability, quality, origin, size and any certification should be discussed and confirmed before purchase.'},
  {id:'pyramid',name:'Copper Vastu Pyramid',category:'vastu',categoryLabel:'SPACE & STILLNESS',tag:'INTENTIONAL SPACES',image:'vastu.webp',subtitle:'A small ritual for the spaces you call home.',description:'An architectural copper pyramid that brings a warm, sculptural accent to a desk, meditation corner or personal altar. Choose it as an intentional object for the space you inhabit.',details:['Copper finish','Vastu-inspired','Home & altar'],tradition:'For placement advice, ask about guidance tailored to your space, its layout and how you intend to use this object.'},
  {id:'amethyst',name:'Amethyst Cluster',category:'gemstones',categoryLabel:'EARTH & INTENTION',tag:'NATURALLY EXPRESSIVE',image:'amethyst.webp',subtitle:'A little stillness, beautifully grounded.',description:'A sculptural cluster of violet crystals for a contemplative corner. Every natural mineral formation is different; inquire to discuss the actual piece, dimensions and availability.',details:['Amethyst','Natural crystal cluster','Decorative object'],tradition:'Amethyst’s violet tones make it a distinctive addition to a reflective corner. Ask about the actual piece and its natural variations.'},
  {id:'chandra-yantra',name:'Chandra Yantra',category:'yantras',categoryLabel:'SACRED GEOMETRY',tag:'A MOMENT FOR CHANDRA',image:'chandra.webp',subtitle:'Make space for your inner moon.',description:'A copper-tone yantra inspired by the traditional symbolism of Chandra. A contemplative object for your sacred space, chosen with attention to its meaning and your own intention.',details:['Copper finish','Lunar symbolism','Personal altar'],tradition:'The preview artwork illustrates the design direction. The final yantra’s geometry, inscriptions, material and any ritual preparation will be confirmed personally before purchase.'}
];


const gemstoneCatalog = window.LUNIC_GEMSTONES || [];
const yantraCatalog = window.LUNIC_YANTRAS || [];
const rudrakshaCatalog = window.LUNIC_RUDRAKSHA || [];
const vastuCatalog = window.LUNIC_VASTU || [];
const catalogIds = new Set([...gemstoneCatalog, ...yantraCatalog, ...rudrakshaCatalog, ...vastuCatalog].map(product => product.id));
const products = [...gemstoneCatalog, ...yantraCatalog, ...rudrakshaCatalog, ...vastuCatalog, ...originalProducts.filter(product => !catalogIds.has(product.id))]
  .map(product => product.id === 'vastu-purusha-yantra' ? {...product, collections:['yantras','vastu'], vastuGroup:'geometry'} : product);

const normalizeSearch = value => String(value).toLocaleLowerCase().replace(/[’']/g, '').replace(/[-–—]/g, ' ').replace(/\s+/g, ' ').trim();
const productById = new Map(products.map(product => [product.id, product]));
const productSearchIndex = new Map(products.map(product => {
  const text = normalizeSearch([product.name, product.vernacular || '', product.planet || '', product.deity || '', product.family || '', product.origin || '', product.vastuGroup || '', product.category, product.series || '', product.subtitle, ...product.details, ...(product.aliases || [])].join(' '));
  return [product.id, {text, words:new Set(text.split(/[^\p{L}\p{N}]+/u))}];
}));
const collectionCounts = Object.fromEntries(['all','navaratna','gemstones','yantras','rudraksha','vastu'].map(category => [category, products.filter(product => productInCollection(product,category)).length]));

const phases = {
  new:{sanskrit:'AMAVASYA',title:'Make room for beginnings.',description:'A quieter sky, a clean page. Write down one intention you’d like to grow, and give yourself permission to begin gently.'},
  waxing:{sanskrit:'SHUKLA PAKSHA',title:'Give your intention a little light.',description:'As the moon grows, choose one small action that supports your intention. Consistency can be a gentle kind of devotion.'},
  full:{sanskrit:'PURNIMA',title:'Pause. Notice what is already full.',description:'Take a moment to reflect on what has grown. Write down three things you’re grateful for, and let yourself receive the good.'},
  waning:{sanskrit:'KRISHNA PAKSHA',title:'There is grace in letting go.',description:'Make a little space. Clear one corner, loosen one expectation, or put down a thought you no longer need to carry.'}
};

const articles = {
  vastu:{category:'A CONSIDERED SPACE',title:'Begin with your space.',body:`<p>A useful placement conversation begins with the room itself: its layout, entrances, natural light and everyday use. Choose objects with a clear idea of where they will sit and what they mean to you.</p><h3>Explore the collection</h3><p>Browse geometry, metal tools, symbolic sculpture, crystals and ritual essentials. Some objects are decorative, some belong to a devotional practice, and others are intended for a guided Vastu selection.</p><h3>Bring a little context</h3><p>For placement guidance, share a simple plan and your intended location. Ask about the actual object’s dimensions, material, finish, fitting and care before choosing.</p><h3>Preview and actual piece</h3><p>Images are for illustration purposes only. Actual products may vary. Availability and final specifications are confirmed personally on inquiry.</p>`,cta:'Explore Vastu objects'},
  rudraksha:{category:'A LIVING TRADITION',title:'A bead. A face. A personal practice.',body:`<p>Rudraksha seeds have a long place in Shaiva devotional practice. They may be chosen as single beads or used in a mala for japa, the repetition of a mantra.</p><h3>What is a mukhi?</h3><p>Mukhi refers to the natural faces or divisions of a bead. The principal grooves run between its poles; a close view of one side alone cannot establish the complete count.</p><h3>Nepali and Java selections</h3><p>Explore both origins in this collection, then ask about the actual specimen’s size, shape, natural lines and supporting identification. The AI previews show a visual direction, rather than proving a bead’s origin or mukhi count.</p><h3>Choose with understanding</h3><p>Discuss your intended practice and practical preferences before choosing a bead or natural joined form.</p><p><a href="https://www.himalayanacademy.com/wp-content/uploads/2025/02/1997-mar-insight-tulsi-and-rudraksha.pdf" target="_blank" rel="noopener noreferrer">Read about the Rudraksha tradition · Himalayan Academy ↗</a></p>`,cta:'Explore Rudraksha'},
  moon:{category:'THE LUNAR LIFE',title:'What your Moon sign says about your inner world',body:`<p>In Jyotish, the Moon—Chandra—is traditionally connected with the mind, emotional experience and our sense of comfort. While the Sun is often the starting point in popular astrology, a Vedic reading gives the Moon an important place in the conversation.</p><h3>A more personal starting point</h3><p>Your Moon sign describes the zodiac sign occupied by the Moon at birth. Its nakshatra, or lunar mansion, adds another layer of symbolism. An astrologer reads these alongside the whole chart, rather than treating any single placement as the whole story.</p><h3>It’s a conversation, not a label</h3><p>Two people with the same Moon sign can have very different lives. Planetary relationships, the ascendant, dashas and personal circumstances all matter. The useful question is less “What am I destined to be?” and more “Which patterns do I recognise, and how would I like to respond?”</p><h3>A small reflection</h3><p>Notice the places, people and routines that help you feel at ease. Bring those observations to a reading. Your lived experience gives the symbols a much more meaningful context.</p>`,cta:'Explore your inner orbit'},
  yantra:{category:'SACRED SPACES',title:'More than geometry: the meaning of a yantra',body:`<p>A yantra is a geometric form used in certain Indian spiritual traditions as a focus for contemplation, ritual or devotion. The word can refer to an instrument or support; in practice, the object is part of a wider relationship with attention and intention.</p><h3>Geometry with a purpose</h3><p>Triangles, circles, a central point and surrounding boundaries recur in many yantras. Their arrangement carries meanings within the particular tradition. The Sri Yantra, for example, is a revered form associated with the Shakta tradition.</p><h3>Begin with understanding</h3><p>Before choosing a yantra, ask what it represents, how it is made, and whether the relevant tradition recommends a particular placement or practice. There is no need to build an elaborate ritual before you understand the object’s meaning.</p><h3>A considered corner</h3><p>A clean, quiet place and a few minutes of undistracted attention can be a thoughtful starting point. If you want to follow a specific devotional practice, seek guidance from someone grounded in that tradition.</p>`,cta:'Explore sacred geometry'},
  reading:{category:'YOUR FIRST READING',title:'A little preparation. A more meaningful reading.',body:`<p>A useful consultation begins with your questions. You don’t need to know astrological terminology. A little preparation simply gives your conversation more room to be personal and specific.</p><h3>Bring the details you know</h3><p>For a birth-chart consultation, prepare your birth date, birth time and birthplace. If the time is approximate or unknown, say so. Your astrologer can explain what can and cannot be explored confidently with the information available.</p><h3>Choose what matters now</h3><p>Write down one to three priorities in plain language. A question such as “How can I approach this career transition?” gives a conversation more shape than trying to cover every part of life in a short session.</p><h3>Choose your depth</h3><ul><li>Chandra Prashna: one focused Prashna question or Muhurta inquiry.</li><li>Crescent: 15 minutes for an introduction and one life area.</li><li>Moonrise: 30 minutes to connect a few related themes.</li><li>Purnima: 45 minutes for a wider conversation.</li><li>Lunar Tarot: a 30-minute personal Tarot reading at ₹3,100, with your questions and the symbolism of the cards at its heart.</li><li>Soma Reserve: our VIP private consultation at ₹21,000, with a personally agreed focus, duration and appointment.</li></ul><h3>Leave room for your own judgment</h3><p>Consider a reading as a perspective to reflect on, alongside your experience and practical circumstances. You remain the person making your choices.</p>`,cta:'Find your reading'}
};

let selectedIntention = 'all';
let activeFilter = 'all';
let yantraFamily = 'all';
let vastuFamily = 'all';
let rudrakshaOrigin = 'all';
let rudrakshaMukhi = 'all';
let productSearch = '';
let visibleProductCount = 9;
let inquiryMessage = '';
let inquiryContext = null;
let lastFocusedElement = null;
let toastTimer;
let savedProducts;
try { const stored = JSON.parse(localStorage.getItem('lunic-inquiry-bag') || '[]'); savedProducts = Array.isArray(stored) ? [...new Set(stored.filter(id => productById.has(id)))] : []; }
catch { savedProducts = []; }

const dialog = document.querySelector('#main-dialog');
const dialogContent = document.querySelector('#dialog-content');

function renderConsultations() { window.LunicReadings?.render(); }

function productInCollection(product, category) {
  if (category === 'all') return true;
  if (category === 'navaratna') return product.series === 'navaratna';
  return product.category === category || (product.collections || []).includes(category);
}

function matchesRudrakshaMukhi(product) {
  return rudrakshaMukhi === 'all' || (rudrakshaMukhi === 'special' ? product.series === 'special-rudraksha' : product.mukhi === Number(rudrakshaMukhi));
}

function resetProductFacets() {
  yantraFamily = 'all';
  vastuFamily = 'all';
  rudrakshaOrigin = 'all';
  rudrakshaMukhi = 'all';
  document.querySelector('#rudraksha-mukhi').value = 'all';
  document.querySelectorAll('[data-yantra-family],[data-rudraksha-origin],[data-vastu-family]').forEach(button => {
    const selected = (button.dataset.yantraFamily || button.dataset.rudrakshaOrigin || button.dataset.vastuFamily) === 'all';
    button.classList.toggle('active',selected);
    button.setAttribute('aria-pressed',String(selected));
  });
}

function renderProducts(withMotion = true, append = false) {
  const query = normalizeSearch(productSearch);
  const terms = query.split(' ').filter(Boolean);
  const matched = products.filter(product => {
    const inCategory = productInCollection(product, activeFilter);
    const inFamily = activeFilter !== 'yantras' || yantraFamily === 'all' || product.family === yantraFamily;
    const inOrigin = activeFilter !== 'rudraksha' || rudrakshaOrigin === 'all' || product.origin === rudrakshaOrigin;
    const inMukhi = activeFilter !== 'rudraksha' || matchesRudrakshaMukhi(product);
    const {text, words} = productSearchIndex.get(product.id);
    const inSearch = terms.every(term => /^\d+$/.test(term) ? words.has(term) : text.includes(term));
    const inVastuGroup = activeFilter !== 'vastu' || vastuFamily === 'all' || product.vastuGroup === vastuFamily;
    return inCategory && inFamily && inOrigin && inMukhi && inVastuGroup && inSearch;
  });
  if (activeFilter === 'vastu' && vastuFamily === 'all') {
    const highlights = ['pyramid','brass-tortoise','salt-lamp','copper-helix','brass-diya','tabletop-fountain','kamadhenu','quartz-pyramid','wind-chime'];
    const rank = product => { const index = highlights.indexOf(product.id); return index < 0 ? 999 : index; };
    matched.sort((a,b) => rank(a) - rank(b));
  }
  const visible = matched.slice(0, visibleProductCount);
  const grid = document.querySelector('#product-grid');
  const existing = [...grid.querySelectorAll('.product-card')];
  const start = append && existing.every((card,index) => card.dataset.productKey === visible[index]?.id) ? existing.length : 0;
  const cards = visible.slice(start).map(product => `<article class="product-card" data-product-key="${product.id}">
    <div class="product-image">
      <button data-product="${product.id}" aria-label="View ${product.name}"><img src="/assets/${product.image}" alt="AI concept image of ${product.name}" loading="lazy" decoding="async" width="900" height="900"><span class="product-look" aria-hidden="true">Explore object ↗</span></button>
      <span class="product-tag">${product.tag}</span>
      <button class="save-product${savedProducts.includes(product.id) ? ' saved' : ''}" data-save="${product.id}" aria-label="${savedProducts.includes(product.id) ? 'Remove' : 'Add'} ${product.name} ${savedProducts.includes(product.id) ? 'from' : 'to'} inquiry bag" aria-pressed="${savedProducts.includes(product.id)}">${icon(savedProducts.includes(product.id) ? 'check' : 'plus')}</button>
    </div>
    <p class="product-image-note">Illustrative image · Actual product may vary</p>
    <div class="product-info"><span class="product-category">${product.categoryLabel}</span>
      <div class="product-title-row"><button data-product="${product.id}"><h3>${product.name}</h3>${product.vernacular ? `<span class="product-local-name">${product.vernacular}</span>` : ''}</button><button class="product-open" data-product="${product.id}" aria-label="View ${product.name} details">${icon('arrow')}</button></div>
      <p class="product-subtitle">${product.subtitle}</p>
      <div class="product-inquiry"><span>Price on inquiry</span><a href="${escapeHtml(productEnquiryUrl(product))}" target="_blank" rel="noopener noreferrer" data-whatsapp-product="${product.id}" aria-label="Enquire about ${escapeHtml(product.name)} on WhatsApp (opens in a new tab)">${icon('whatsapp')}<span>Enquire on WhatsApp</span></a></div>
    </div>
  </article>`).join('');
  if (start) grid.insertAdjacentHTML('beforeend',cards);
  else grid.innerHTML = cards;
  if (!matched.length) document.querySelector('#product-grid').innerHTML = '<div class="collection-empty"><span aria-hidden="true">✧</span><h3>A different kind of search.</h3><p>No objects match those words. Try a gemstone, yantra, Rudraksha, mukhi number or traditional name.</p><button class="text-link" data-action="reset-collection">Explore all essentials <span>↗</span></button></div>';
  if (withMotion) window.LunicExperience?.animateGrid(grid,start);
  document.querySelector('.collection-count').textContent = `${matched.length} object${matched.length === 1 ? '' : 's'}, infinite intention`;
  document.querySelector('#collection-announcement').textContent = `Showing ${visible.length} of ${matched.length} object${matched.length === 1 ? '' : 's'}${query ? ` for ${productSearch.trim()}` : ''}.`;
  const remaining = matched.length - visible.length;
  const pagination = document.querySelector('#collection-pagination');
  pagination.hidden = matched.length === 0;
  document.querySelector('#collection-page-summary').textContent = `Showing ${visible.length} of ${matched.length} object${matched.length === 1 ? '' : 's'}`;
  const more = document.querySelector('[data-action="load-more-products"]');
  more.hidden = remaining <= 0;
  more.innerHTML = `Show ${Math.min(9, remaining)} more ${activeFilter === 'gemstones' || activeFilter === 'navaratna' ? 'gemstones' : activeFilter === 'yantras' ? 'yantras' : activeFilter === 'rudraksha' ? 'rudraksha' : activeFilter === 'vastu' ? (remaining === 1 ? 'Vastu object' : 'Vastu objects') : 'essentials'} ${icon('plus')}`;
  document.querySelectorAll('[data-filter-count]').forEach(label => {
    const category = label.dataset.filterCount;
    const count = collectionCounts[category];
    label.textContent = String(count).padStart(2, '0');
  });
  document.querySelector('.gemstone-intro').hidden = ['yantras','rudraksha','vastu'].includes(activeFilter);
  document.querySelector('.yantra-intro').hidden = activeFilter !== 'yantras';
  document.querySelector('.yantra-families').hidden = activeFilter !== 'yantras';
  document.querySelectorAll('[data-yantra-count]').forEach(label => {
    label.textContent = yantraCatalog.filter(product => label.dataset.yantraCount === 'all' || product.family === label.dataset.yantraCount).length;
  });
  document.querySelector('.rudraksha-intro').hidden = activeFilter !== 'rudraksha';
  document.querySelector('#rudraksha-filters').hidden = activeFilter !== 'rudraksha';
  document.querySelectorAll('[data-rudraksha-total]').forEach(label => { label.textContent = rudrakshaCatalog.length; });
  document.querySelectorAll('[data-rudraksha-count]').forEach(label => {
    label.textContent = rudrakshaCatalog.filter(product => matchesRudrakshaMukhi(product) && (label.dataset.rudrakshaCount === 'all' || product.origin === label.dataset.rudrakshaCount)).length;
  });
  document.querySelector('.vastu-intro').hidden = activeFilter !== 'vastu';
  document.querySelector('.vastu-families').hidden = activeFilter !== 'vastu';
  document.querySelectorAll('[data-vastu-count]').forEach(label => {
    label.textContent = products.filter(product => productInCollection(product,'vastu') && (label.dataset.vastuCount === 'all' || product.vastuGroup === label.dataset.vastuCount)).length;
  });
  document.querySelector('[data-gemstone-total]').textContent = products.filter(product => product.category === 'gemstones').length;
}

function updateBag() {
  const count = document.querySelector('.bag-count');
  count.textContent = savedProducts.length;
  count.hidden = !savedProducts.length;
  document.querySelector('.bag-button').setAttribute('aria-label', `Open inquiry bag, ${savedProducts.length} object${savedProducts.length === 1 ? '' : 's'}`);
  try { localStorage.setItem('lunic-inquiry-bag', JSON.stringify(savedProducts)); } catch { /* The bag still works when browser storage is unavailable. */ }
}

function toggleProduct(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;
  const index = savedProducts.indexOf(id);
  if (index >= 0) { savedProducts.splice(index,1); toast(`${product.name} removed from your inquiry bag.`); }
  else { savedProducts.push(id); toast(`${product.name} added to your inquiry bag.`); }
  updateBag();
  // Preserve the grid, decoded images and keyboard focus when one object changes.
  const saved = savedProducts.includes(id);
  document.querySelectorAll(`[data-save="${id}"]`).forEach(button => {
    button.classList.toggle('saved', saved);
    button.setAttribute('aria-pressed', String(saved));
    button.setAttribute('aria-label', `${saved ? 'Remove' : 'Add'} ${product.name} ${saved ? 'from' : 'to'} inquiry bag`);
    button.innerHTML = icon(saved ? 'check' : 'plus');
  });
}

function openDialog(html, label) {
  window.LunicBirth?.detach();
  if (!dialog.open) lastFocusedElement = document.activeElement;
  dialogContent.innerHTML = html;
  window.LunicExperience?.animateDialog();
  dialog.setAttribute('aria-label', label);
  if (!dialog.open) dialog.showModal();
  document.body.classList.add('dialog-open');
  dialog.scrollTop = 0;
  const heading = dialogContent.querySelector('h2');
  if (heading) {
    heading.id = 'dialog-title';
    heading.tabIndex = -1;
    dialog.setAttribute('aria-labelledby', 'dialog-title');
    heading.focus({preventScroll:true});
  }
}

function closeDialog() { dialog.close(); }
dialog.addEventListener('close', () => { document.body.classList.remove('dialog-open'); lastFocusedElement?.focus({preventScroll:true}); });
document.querySelector('.dialog-close').addEventListener('click', closeDialog);
dialog.addEventListener('click', event => { if(event.target === dialog) { const rect = dialog.getBoundingClientRect(); if(event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDialog(); } });

function showProduct(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;
  const saved = savedProducts.includes(id);
  const originChoices = product.category === 'rudraksha'
    ? '<div class="rudraksha-origin-switch" role="group" aria-label="Choose Rudraksha origin">' + [product, products.find(item => item.id === product.counterpartId)].filter(Boolean).sort((a,b) => (a.origin === 'nepali' ? -1 : 1) - (b.origin === 'nepali' ? -1 : 1)).map(item => `<button data-product="${item.id}" class="${item.id === id ? 'active' : ''}" aria-pressed="${item.id === id}">${item.originLabel === 'Java' ? 'Java · Indonesia' : 'Nepali · Nepal'}</button>`).join('') + '</div>'
    : '';
  openDialog(`<div class="dialog-product${product.category === 'yantras' ? ' yantra-detail' : product.category === 'rudraksha' ? ' rudraksha-detail' : product.category === 'vastu' ? ' vastu-detail' : ''}"><div class="product-image-stage"><img class="dialog-product-image" src="/assets/${product.image}" alt="AI concept image of ${product.name}"><button class="product-zoom" data-action="zoom-product" aria-label="Zoom in on ${product.name}" aria-pressed="false">${icon('zoom')}<span>Look closer</span></button></div><div class="dialog-product-copy"><div class="dialog-eyebrow">${product.categoryLabel}</div><h2>${product.name}</h2><p class="dialog-illustration-note">Images are for illustration purposes only. Actual products may vary.</p>${product.vernacular ? `<p class="dialog-gem-name">${product.vernacular}${product.series === 'navaratna' ? ' · Navaratna' : ''}</p>` : ''}${originChoices}<p class="dialog-description">${product.description}</p><div class="detail-chips">${product.details.map(detail => `<span>${detail}</span>`).join('')}</div><p class="dialog-small">${product.tradition}</p><a class="button" href="${escapeHtml(productEnquiryUrl(product))}" target="_blank" rel="noopener noreferrer" data-whatsapp-product="${id}" aria-label="Enquire about ${escapeHtml(product.name)} on WhatsApp (opens in a new tab)">${icon('whatsapp')}<span>Enquire on WhatsApp</span></a><button class="button secondary-button" data-dialog-save="${id}">${saved ? 'Remove from inquiry bag' : 'Add to inquiry bag'} ${icon(saved ? 'check' : 'plus')}</button><p class="dialog-small">Materials, availability and pricing are confirmed before purchase.</p></div></div>`,product.name);
}

function localDate() { const now = new Date(); return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`; }

function showInquiry(context) {
  inquiryContext = context;
  const plan = context.plan ? consultations.find(p => p.id === context.plan) : null;
  const product = context.product ? products.find(p => p.id === context.product) : null;
  const isBag = context.type === 'bag';
  const isReserve = Boolean(plan?.vip);
  const title = isReserve ? 'Your private orbit.' : plan ? 'A little closer to clarity.' : product ? `A moment for ${product.name.toLowerCase()}.` : isBag ? 'Your little collection of intention.' : context.type === 'remedy' ? 'Find your personal starting point.' : 'Let’s start a conversation.';
  const description = isReserve ? 'Begin your Soma Reserve enquiry. Share the questions that deserve your fullest attention. We’ll agree the focus, duration and appointment personally before you confirm.' : plan ? `Prepare your ${plan.name} inquiry. We’ll confirm availability and the details personally before your consultation.` : product ? 'Ask about this object, its availability, materials or personal suitability. Final details and pricing are confirmed on inquiry.' : isBag ? 'Ask about your selected objects in one message. Availability and prices will be confirmed personally.' : 'Tell us what you’re curious about. We’ll help you find a reading or sacred object that feels relevant to you.';
  const summary = plan ? `<div class="inquiry-summary"><span>${plan.name} · ${plan.duration}</span><strong>${money(plan.price)}</strong></div>` : product ? `<div class="inquiry-summary"><span>${product.name}</span><span>Price on inquiry</span></div>` : isBag ? `<div class="inquiry-summary"><span>${savedProducts.map(id => products.find(p => p.id === id)?.name).join(' · ')}</span><span>${savedProducts.length} object${savedProducts.length === 1 ? '' : 's'}</span></div>` : '';
  openDialog(`<div class="dialog-content-padded${isReserve ? ' reserve-inquiry' : ''}"><div class="dialog-eyebrow">${isReserve ? 'SOMA RESERVE / PRIVATE CLIENT' : plan ? 'YOUR PERSONAL READING' : 'A PERSONAL INQUIRY'}</div><h2>${title}</h2><p class="dialog-description">${description}</p>${summary}<form class="inquiry-form" id="inquiry-form"><div class="field"><label for="inquiry-name">Your name *</label><input id="inquiry-name" name="name" autocomplete="name" placeholder="What should we call you?" maxlength="80" required></div><div class="field"><label for="inquiry-email">Email <span>(optional)</span></label><input id="inquiry-email" name="email" type="email" autocomplete="email" placeholder="you@example.com" maxlength="150"></div>${window.LunicBirth?.fields({required:['crescent','moonrise','purnima','reserve'].includes(plan?.id),today:localDate()}) || ''}${plan ? `<div class="field"><label for="inquiry-date">Preferred date <span>(optional)</span></label><input id="inquiry-date" name="date" type="date" min="${localDate()}"></div><div class="field"><label for="inquiry-time">Preferred time window · IST</label><select id="inquiry-time" name="time"><option value="Flexible">I’m flexible</option><option>Morning · 9 am–12 pm</option><option>Afternoon · 12–4 pm</option><option>Evening · 4–7 pm</option></select></div>${plan.id === 'prashna' ? '<div class="field full-width"><label for="inquiry-focus">Your focus</label><select id="inquiry-focus" name="focus"><option>Prashna · one focused question</option><option>Muhurta · choosing a meaningful time</option></select></div>' : ''}` : ''}<div class="field full-width"><label for="inquiry-message">${isReserve ? 'What deserves our fullest attention?' : plan ? 'What would you like to explore?' : 'Your question or message'} <span>(optional)</span></label><textarea id="inquiry-message" name="message" maxlength="2000" placeholder="A question, a new chapter, or something you’d like a little clarity on…">${escapeHtml(context.message || '')}</textarea></div><p class="form-note">${plan ? 'Preferred times are requests, not confirmed slots. No payment is taken here. ' : ''}This prepares a message to review, then open in WhatsApp, copy or save. Your inquiry is not sent automatically.</p><button type="submit" class="button">${isReserve ? 'Prepare my private enquiry' : 'Prepare my inquiry'} ${icon('arrow')}</button></form></div>`,plan ? `Inquire about ${plan.name}` : 'Prepare your inquiry');
  window.LunicBirth?.attach(document.querySelector('#inquiry-form'));
}

function prepareInquiry(form) {
  const fields = new FormData(form);
  const plan = inquiryContext.plan ? consultations.find(p => p.id === inquiryContext.plan) : null;
  const product = inquiryContext.product ? products.find(p => p.id === inquiryContext.product) : null;
  const lines = ['Hello Lunic,', '', `My name is ${fields.get('name').trim()}.`];
  if (plan) { lines.push(`I’d like to inquire about the ${plan.name}${plan.vip ? ' VIP' : ''} consultation (${money(plan.price)}, ${plan.duration}).`); if(fields.get('focus')) lines.push(`Focus: ${fields.get('focus')}`); }
  else if(product) lines.push(`I’m interested in the ${product.name}. Please share availability, materials, dimensions and pricing.`);
  else if(inquiryContext.type === 'bag') { lines.push('I’m interested in the following objects:'); savedProducts.forEach(id => lines.push(`• ${products.find(p => p.id === id).name}`)); lines.push('Please share availability and pricing.'); }
  else if(inquiryContext.type === 'remedy') lines.push('I’d like some personal guidance on choosing a consultation or sacred object.');
  else lines.push('I’d love to know more about Lunic.');
  if (fields.get('email')?.trim()) lines.push(`Email: ${fields.get('email').trim()}`);
  window.LunicBirth?.appendToMessage(fields,lines);
  if (fields.get('date')) {const [y,m,d] = fields.get('date').split('-');lines.push(`Preferred date: ${d}/${m}/${y}`);}
  if (fields.get('time')) lines.push(`Preferred time: ${fields.get('time')} (IST)`);
  if (fields.get('message')?.trim()) lines.push('',fields.get('message').trim());
  lines.push('','Thank you. Please let me know the next steps.');
  inquiryMessage = lines.join('\n');
  const phone = String(window.LUNIC_CONFIG?.whatsappNumber || '').replace(/\D/g,'');
  const whatsappReady = /^\d{10,15}$/.test(phone);
  const phoneLabel = phone.startsWith('91') && phone.length === 12 ? `+91 ${phone.slice(2,7)} ${phone.slice(7)}` : `+${phone}`;
  openDialog(`<div class="dialog-content-padded"><div class="ready-symbol">${icon('check')}</div><div class="dialog-eyebrow">A THOUGHTFUL FIRST STEP</div><h2>Your inquiry is ready.</h2><p class="dialog-description">${whatsappReady ? `Review your message below, then open WhatsApp to send it to Lunic at ${phoneLabel}.` : 'Lunic’s WhatsApp channel is being set up. For now, copy or save your message so it’s ready when we connect.'}</p><pre class="message-preview">${escapeHtml(inquiryMessage)}</pre><div class="inquiry-actions">${whatsappReady ? `<a class="button" href="https://wa.me/${phone}?text=${encodeURIComponent(inquiryMessage)}" target="_blank" rel="noopener noreferrer">${icon('whatsapp')}<span>Open WhatsApp</span></a>` : ''}<button class="button${whatsappReady ? ' secondary-button' : ''}" data-action="copy-inquiry">Copy inquiry ${icon('plus')}</button><button class="button secondary-button" data-action="save-inquiry">Save as a note ${icon('arrow')}</button></div><p class="dialog-small">${plan ? 'This is a booking inquiry. Your appointment and payment will be confirmed personally after you send it.' : 'No message has been sent and no order has been placed.'}</p><button class="text-link" data-action="edit-inquiry">Start a new inquiry <span>↗</span></button></div>`,'Your inquiry is ready');
}

function showBag() {
  openDialog(`<div class="dialog-content-padded"><div class="dialog-eyebrow">YOUR SACRED SHORTLIST</div><h2>A little collection<br>of intention.</h2>${savedProducts.length ? `<div class="bag-list">${savedProducts.map(id => { const product = products.find(p => p.id === id); return `<div class="bag-item"><img src="/assets/${product.image}" alt="${product.name}"><div><h3>${product.name}</h3><p>Availability & price on inquiry</p></div><button data-bag-remove="${id}" aria-label="Remove ${product.name} from inquiry bag">Remove</button></div>`; }).join('')}</div><p class="bag-total">${savedProducts.length} thoughtfully chosen object${savedProducts.length === 1 ? '' : 's'}. Ask about your whole collection in one personal inquiry.</p><div class="inquiry-actions"><button class="button" data-action="inquire-bag">Inquire about my collection ${icon('arrow')}</button></div><p class="dialog-small">Your shortlist is stored only in this browser. No order or payment is placed here.</p>` : '<p class="empty-bag">Your collection is a clean page. Explore the sacred essentials and use the + button to save an object that speaks to you.</p><a class="button" href="#collection" data-action="browse-collection">Explore the collection '+icon('arrow')+'</a>'}</div>`,'Your inquiry bag');
}

function showArticle(key) {
  const article = articles[key];
  if(!article) return;
  openDialog(`<article class="dialog-content-padded"><div class="dialog-eyebrow">MOON NOTES / ${article.category}</div><h2>${article.title}</h2><div class="article-body">${article.body}<p class="article-footnote">Moon notes are starting points for reflection. Bring your own questions and experiences to the conversation.</p></div><a class="text-link" href="${['yantra','rudraksha','vastu'].includes(key) ? '#collection' : '#consultations'}" data-action="close-and-explore">${article.cta} <span>↗</span></a></article>`,article.title);
}

function showPolicy(type) {
  const privacy = type === 'privacy';
  openDialog(`<div class="dialog-content-padded"><div class="dialog-eyebrow">A LITTLE TRANSPARENCY</div><h2>${privacy ? 'Your space. Your information.' : 'A note on care & intention.'}</h2><div class="article-body">${privacy ? '<p>This preview does not have a booking backend, payment processor, analytics tracker or mailing list. Inquiry text stays in the current page until you copy it, download it or choose to send it through WhatsApp.</p><h3>Birth details and maps</h3><p>Birth details stay in the current form and are not saved in browser storage. The place names you search are sent to Photon for location suggestions. Date and time of birth are not sent to the search provider. A map preview loads OpenStreetMap only when you request it. Opening Google Maps sends the selected place or map pin to Google. Your birth details are included in the message you choose to share through WhatsApp.</p><h3>Your inquiry bag</h3><p>Only the IDs of products you save are stored in this browser’s local storage. Remove them from the inquiry bag, or clear this site’s browser data, to delete the shortlist.</p><h3>When you use WhatsApp</h3><p>The WhatsApp button will open a prepared message. Sending is your choice, and WhatsApp’s privacy terms apply. Lunic’s full business privacy policy and retention practices will be provided before launch.</p>' : '<p>Lunic is currently a design preview. Consultation names and listed fees are proposed offerings. Moonrise is shown as a 30-minute session for this preview; its final duration can be adjusted.</p><h3>Inquiries, not confirmed purchases</h3><p>No appointment is confirmed, order placed or payment taken on this preview. Availability, consultation arrangements, product specifications, final prices, delivery, cancellation and refund terms will be confirmed before purchase.</p><h3>Objects with context</h3><p>All collection images are AI-created illustrations. Actual gemstones and handcrafted objects will vary. No certification, origin, ritual preparation or treatment status is claimed by these preview images.</p><h3>Your choices remain yours</h3><p>Astrology and spiritual objects are offered for personal reflection and traditional practice. They do not guarantee outcomes or replace appropriate medical, legal or financial advice.</p>'}</div></div>`,privacy ? 'Privacy in this preview' : 'Terms and care');
}

function toast(message) { const element = document.querySelector('.toast'); clearTimeout(toastTimer); element.textContent = message; element.classList.add('visible'); toastTimer = setTimeout(() => element.classList.remove('visible'),3500); }

document.addEventListener('click', async (event) => {
  const target = event.target.closest('button,a');
  if(!target) return;
  if(target.dataset.plan) showInquiry({type:'consultation',plan:target.dataset.plan,message:target.dataset.readingPrompt || ''});
  else if(target.dataset.product) showProduct(target.dataset.product);
  else if(target.dataset.save) toggleProduct(target.dataset.save);
  else if(target.dataset.dialogSave) {toggleProduct(target.dataset.dialogSave);showProduct(target.dataset.dialogSave);}
  else if(target.dataset.bagRemove) {toggleProduct(target.dataset.bagRemove);showBag();}
  else if(target.dataset.article) showArticle(target.dataset.article);
  else if(target.dataset.yantraFamily) {
    yantraFamily = target.dataset.yantraFamily;
    visibleProductCount = 9;
    document.querySelectorAll('[data-yantra-family]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',String(button === target)); });
    renderProducts();
  }
  else if(target.dataset.vastuFamily) {
    vastuFamily = target.dataset.vastuFamily;
    visibleProductCount = 9;
    document.querySelectorAll('[data-vastu-family]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',String(button === target)); });
    renderProducts();
  }
  else if(target.dataset.rudrakshaOrigin) {
    rudrakshaOrigin = target.dataset.rudrakshaOrigin;
    visibleProductCount = 9;
    document.querySelectorAll('[data-rudraksha-origin]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',String(button === target)); });
    renderProducts();
  }
  else if(target.dataset.filter) {
    activeFilter = target.dataset.filter;
    resetProductFacets();
    visibleProductCount = 9;
    document.querySelectorAll('[data-filter]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',button === target); });
    renderProducts();
  }
  else if(target.dataset.intention) {
    selectedIntention = target.dataset.intention;
    document.querySelectorAll('[data-intention]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',button === target); });
    renderConsultations();
  }
  else if(target.dataset.phase) {
    if (window.LunicExperience) { window.LunicExperience.setPhase(target.dataset.phase); return; }
    const phase = phases[target.dataset.phase];
    if(!phase) return;
    document.querySelector('.interactive-moon').dataset.phase = target.dataset.phase;
    document.querySelector('#phase-sanskrit').textContent = phase.sanskrit;
    document.querySelector('#phase-title').textContent = phase.title;
    document.querySelector('#phase-description').textContent = phase.description;
    document.querySelectorAll('button[data-phase]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',button === target); });
  }
  else if(target.dataset.action) {
    switch(target.dataset.action) {
      case 'load-more-products': {
        const previousCount = document.querySelectorAll('.product-card').length;
        visibleProductCount += 9;
        renderProducts(true,true);
        document.querySelectorAll('.product-card')[previousCount]?.querySelector('button[data-product]')?.focus({preventScroll:true});
        break;
      }
      case 'bag': showBag();break;
      case 'contact': showInquiry({type:'contact'});break;
      case 'personal-remedy': showInquiry({type:'remedy'});break;
      case 'inquire-bag': showInquiry({type:'bag'});break;
      case 'privacy': showPolicy('privacy');break;
      case 'terms': showPolicy('terms');break;
      case 'browse-collection':case 'close-and-explore':closeDialog();break;
      case 'edit-inquiry': showInquiry(inquiryContext || {type:'contact'});break;
      case 'copy-inquiry':
        try { await navigator.clipboard.writeText(inquiryMessage);toast('Inquiry copied. A little clarity, ready to share.');target.innerHTML = `Copied ${icon('check')}`; }
        catch { const preview = document.querySelector('.message-preview');const range = document.createRange();range.selectNodeContents(preview);const selection = window.getSelection();selection.removeAllRanges();selection.addRange(range);toast('Select Copy in your browser to copy the highlighted inquiry.'); }
        break;
      case 'save-inquiry': {
        const url = URL.createObjectURL(new Blob([inquiryMessage],{type:'text/plain;charset=utf-8'}));
        const link = document.createElement('a');link.href=url;link.download='my-lunic-inquiry.txt';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Your inquiry has been saved as a note.');break;
      }
    }
  }
});

document.querySelector('#rudraksha-mukhi').addEventListener('change', event => {
  rudrakshaMukhi = event.target.value;
  visibleProductCount = 9;
  renderProducts();
});

document.addEventListener('submit', event => {
  if(event.target.id === 'inquiry-form') { event.preventDefault(); if(event.target.reportValidity()) prepareInquiry(event.target); }
});

const menuButton = document.querySelector('.menu-button');
const mobileNav = document.querySelector('#mobile-nav');
function closeMenu(){mobileNav.hidden=true;menuButton.setAttribute('aria-expanded','false');menuButton.setAttribute('aria-label','Open navigation');menuButton.innerHTML=icon('menu');}
menuButton.addEventListener('click',()=>{const open=menuButton.getAttribute('aria-expanded')==='true';mobileNav.hidden=open;menuButton.setAttribute('aria-expanded',String(!open));menuButton.setAttribute('aria-label',open?'Open navigation':'Close navigation');menuButton.innerHTML=icon(open?'menu':'close');});
mobileNav.addEventListener('click',event=>{if(event.target.closest('a'))closeMenu();});
document.addEventListener('keydown',event=>{if(event.key==='Escape' && menuButton.getAttribute('aria-expanded')==='true'){closeMenu();menuButton.focus();}});
window.matchMedia('(min-width:651px)').addEventListener('change',event=>{if(event.matches)closeMenu();});

const whatsappChat = document.querySelector('#whatsapp-chat');
const whatsappChatNumber = String(window.LUNIC_CONFIG?.whatsappNumber || '').replace(/\D/g,'');
if (/^\d{10,15}$/.test(whatsappChatNumber)) {
  const greeting = 'Hello Lunic, I’d like to know more about your consultations and sacred collection.';
  whatsappChat.href = `https://wa.me/${whatsappChatNumber}?text=${encodeURIComponent(greeting)}`;
  whatsappChat.hidden = false;
}

renderConsultations();renderProducts();updateBag();
document.querySelector('#year').textContent=new Date().getFullYear();

if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.body.classList.add('js-reveals');
  const observer = new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}});},{threshold:.08});
  document.querySelectorAll('.reveal').forEach(element=>observer.observe(element));
}

