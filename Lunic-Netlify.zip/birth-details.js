'use strict';

(() => {
  const cache = new Map();
  let active = null;
  const pin = '<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg>';
  const accuracyOptions = '<option value="confirmed">Confirmed</option><option value="estimated">Estimated</option><option value="unknown">Unknown</option>';

  function fields({required = false, today}) {
    const star = required ? ' *' : '';
    return `<fieldset class="birth-details" data-birth-required="${required}">
      <legend>Your birth details <span>${required ? 'For your chart reading' : 'Optional'}</span></legend>
      <p class="birth-intro">Share what you know. Mark each detail as confirmed, estimated or unknown.</p>
      <div class="birth-grid">
        <div class="field"><label for="birth-date">Date of birth<span data-birth-marker="date">${star}</span></label><input id="birth-date" name="birthDate" type="date" autocomplete="bday" max="${today}" ${required ? 'required' : ''}><input id="birth-date-estimate" name="birthDateEstimate" placeholder="e.g. May 1995, or around 1995" maxlength="100" aria-label="Estimated date of birth" hidden disabled><label class="birth-accuracy-label" for="birth-date-accuracy">How certain is the date?</label><select id="birth-date-accuracy" name="birthDateAccuracy" data-birth-accuracy="date">${accuracyOptions}</select></div>
        <div class="field"><label for="birth-time">Time of birth<span data-birth-marker="time">${star}</span></label><input id="birth-time" name="birthTime" type="time" step="60" ${required ? 'required' : ''} aria-describedby="birth-time-hint"><input id="birth-time-estimate" name="birthTimeEstimate" placeholder="e.g. around 8 am, or morning" maxlength="100" aria-label="Estimated time of birth" hidden disabled><label class="birth-accuracy-label" for="birth-time-accuracy">How certain is the time?</label><select id="birth-time-accuracy" name="birthTimeAccuracy" data-birth-accuracy="time">${accuracyOptions}</select><small id="birth-time-hint" class="birth-field-hint">Use the local time at your birthplace.</small></div>
        <div class="field birth-place-field"><label for="birth-place">Place of birth<span data-birth-marker="place">${star}</span></label><div class="birth-place-search"><span class="birth-search-icon">${pin}</span><input id="birth-place" name="birthPlace" type="text" placeholder="Search your birth town or city" autocomplete="off" spellcheck="false" maxlength="200" role="combobox" aria-autocomplete="list" aria-controls="birth-place-options" aria-expanded="false" aria-describedby="birth-place-hint birth-place-status" ${required ? 'required' : ''}><ul id="birth-place-options" class="birth-place-options" role="listbox" aria-label="Matching birthplaces" hidden></ul></div><small id="birth-place-hint" class="birth-field-hint">Choose a suggestion to attach a city map pin, or enter a place manually.</small><p id="birth-place-status" class="birth-place-status" role="status" aria-live="polite"></p><label class="birth-accuracy-label" for="birth-place-accuracy">How certain is the place?</label><select id="birth-place-accuracy" name="birthPlaceAccuracy" data-birth-accuracy="place">${accuracyOptions}</select><input type="hidden" name="birthLatitude"><input type="hidden" name="birthLongitude">
        <div id="birth-location-preview" class="birth-location-preview" hidden><div class="birth-location-label">${pin}<div><strong id="birth-selected-label"></strong><small id="birth-location-note">City / town map pin</small></div></div><div class="birth-map-actions"><button type="button" data-birth-map-preview>Preview map ${icon('plus')}</button><a id="birth-map-link" target="_blank" rel="noopener noreferrer">Open Google Maps ${icon('arrow')}</a></div><div id="birth-map-frame" class="birth-map-frame" hidden></div></div>
        <p class="birth-place-credit">Search by <a href="https://photon.komoot.io/" target="_blank" rel="noopener noreferrer">Photon</a> · Map data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a></p></div>
        <div class="field birth-details-notes"><label for="birth-details-notes">Anything to clarify? <span>(optional)</span></label><textarea id="birth-details-notes" name="birthDetailsNotes" rows="2" maxlength="500" placeholder="For example: the time is a family estimate, or only the birth year is known."></textarea></div>
      </div><p class="birth-privacy-note">Your date and time stay in this form until you choose to share your enquiry. Only the place search is sent to the location service.</p>
    </fieldset>`;
  }

  function detach() {
    if (!active) return;
    clearTimeout(active.timer);
    active.request?.abort();
    active.events.abort();
    active = null;
  }

  function attach(form) {
    detach();
    if (!form?.querySelector('.birth-details')) return;
    const state = {form, events:new AbortController(), timer:null, request:null, sequence:0, options:[], highlighted:-1, selected:null};
    active = state;
    const input = form.querySelector('#birth-place');
    const list = form.querySelector('#birth-place-options');
    const status = form.querySelector('#birth-place-status');
    const preview = form.querySelector('#birth-location-preview');
    const frame = form.querySelector('#birth-map-frame');
    const mapLink = form.querySelector('#birth-map-link');
    const previewButton = form.querySelector('[data-birth-map-preview]');
    const required = form.querySelector('.birth-details').dataset.birthRequired === 'true';
    const listen = (element, name, callback) => element.addEventListener(name, callback, {signal:state.events.signal});
    const setStatus = text => { status.textContent = text; };

    function closeOptions() {
      list.hidden = true;
      input.setAttribute('aria-expanded', 'false');
      input.removeAttribute('aria-activedescendant');
      state.highlighted = -1;
    }

    function clearPin() {
      state.selected = null;
      form.elements.birthLatitude.value = '';
      form.elements.birthLongitude.value = '';
      frame.replaceChildren();
      frame.hidden = true;
      previewButton.hidden = false;
      previewButton.innerHTML = `Preview map ${icon('plus')}`;
    }

    function manualPreview() {
      const value = input.value.trim();
      preview.hidden = !value;
      if (!value) return;
      form.querySelector('#birth-selected-label').textContent = value;
      form.querySelector('#birth-location-note').textContent = 'Place entered manually · Map pin not selected';
      mapLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(value)}`;
      previewButton.hidden = true;
    }

    function choose(index) {
      const place = state.options[index];
      if (!place) return;
      clearTimeout(state.timer);
      state.sequence++;
      state.request?.abort();
      clearPin();
      state.selected = place;
      input.value = place.label;
      form.elements.birthLatitude.value = place.latitude;
      form.elements.birthLongitude.value = place.longitude;
      form.querySelector('#birth-selected-label').textContent = place.label;
      form.querySelector('#birth-location-note').textContent = 'City / town map pin · Check this is your intended place';
      mapLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${place.latitude},${place.longitude}`)}`;
      previewButton.hidden = false;
      preview.hidden = false;
      closeOptions();
      setStatus('Place selected. You can preview the map or open Google Maps.');
      input.focus({preventScroll:true});
    }

    function showOptions(options) {
      state.options = options;
      state.highlighted = -1;
      list.innerHTML = options.map((place,index) => `<li role="presentation"><button type="button" role="option" id="birth-place-option-${index}" data-birth-option="${index}" aria-selected="false" tabindex="-1">${pin}<span><strong>${escapeHtml(place.name)}</strong><small>${escapeHtml(place.context)}</small></span></button></li>`).join('');
      list.hidden = !options.length;
      input.setAttribute('aria-expanded', String(Boolean(options.length)));
      input.removeAttribute('aria-activedescendant');
      setStatus(options.length ? `${options.length} places found. Choose your town or city.` : 'No matching place found. Try adding the state or country, or continue with the place entered manually.');
    }

    async function search() {
      const query = input.value.trim();
      if (query.length < 3 || input.disabled) return;
      const sequence = ++state.sequence;
      state.request?.abort();
      const key = query.toLocaleLowerCase();
      const cached = cache.get(key);
      if (cached && Date.now() - cached.saved < 600000) { showOptions(cached.places); return; }
      const request = new AbortController();
      state.request = request;
      let timedOut = false;
      const timeout = setTimeout(() => { timedOut = true; request.abort(); }, 5000);
      setStatus('Finding places…');
      input.setAttribute('aria-busy','true');
      try {
        const url = new URL(window.LUNIC_CONFIG?.placeSearchUrl || 'https://photon.komoot.io/api/');
        url.search = new URLSearchParams({q:query, limit:'6', lang:'en'}).toString();
        url.searchParams.append('layer','city');
        url.searchParams.append('layer','locality');
        url.searchParams.append('layer','district');
        const response = await fetch(url, {signal:request.signal, credentials:'omit', referrerPolicy:'no-referrer', headers:{Accept:'application/json'}});
        if (!response.ok) throw new Error('Place search unavailable');
        const data = await response.json();
        if (active !== state || sequence !== state.sequence || !form.isConnected) return;
        const places = (data.features || []).map(feature => {
          const p = feature.properties || {};
          const [longitude, latitude] = feature.geometry?.coordinates || [];
          const name = p.name || p.city;
          if (!name || !Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude)>90 || Math.abs(longitude)>180) return null;
          const parts = [...new Set([name,p.state || p.county,p.country].filter(Boolean))];
          return {name, label:parts.join(', '), context:parts.slice(1).join(', '), latitude, longitude};
        }).filter(Boolean).filter((place,index,all) => all.findIndex(item => item.label === place.label) === index).slice(0,6);
        if (cache.size >= 40) cache.delete(cache.keys().next().value);
        cache.set(key,{saved:Date.now(),places});
        showOptions(places);
      } catch (error) {
        if (active !== state || sequence !== state.sequence || (request.signal.aborted && !timedOut)) return;
        closeOptions();
        setStatus('Place search is taking a moment. Enter your town/city manually, or try searching again. You can still continue.');
      } finally {
        clearTimeout(timeout);
        if (active === state && sequence === state.sequence) input.removeAttribute('aria-busy');
      }
    }

    function updateAccuracy(kind) {
      const accuracy = form.querySelector(`#birth-${kind}-accuracy`).value;
      const exact = form.querySelector(`#birth-${kind}`);
      const estimate = form.querySelector(`#birth-${kind}-estimate`);
      const unknown = accuracy === 'unknown';
      const estimated = accuracy === 'estimated';
      const marker = form.querySelector(`[data-birth-marker="${kind}"]`);
      marker.textContent = unknown ? ' · unknown' : estimated ? ' · estimated' : required ? ' *' : '';
      exact.required = required && !unknown && (!estimated || kind === 'place');
      exact.disabled = unknown || (estimated && Boolean(estimate));
      exact.hidden = estimated && Boolean(estimate);
      if (estimate) {
        if (estimated && !estimate.value && exact.value) estimate.value = kind === 'date' ? formatDate(exact.value) : formatTime(exact.value);
        estimate.disabled = !estimated;
        estimate.hidden = !estimated;
        estimate.required = required && estimated;
        marker.closest('label').htmlFor = estimated ? estimate.id : exact.id;
      }
      if (kind === 'place') {
        clearTimeout(state.timer);
        state.sequence++;
        state.request?.abort();
        input.removeAttribute('aria-busy');
        closeOptions();
        if (unknown) { clearPin(); preview.hidden = true; setStatus('Birthplace marked as unknown. You can continue.'); }
        else {
          input.placeholder = estimated ? 'Search the nearest known town or city' : 'Search your birth town or city';
          if (state.selected) {
            preview.hidden = false;
            form.querySelector('#birth-location-note').textContent = estimated ? 'Nearest known place · Birthplace marked as estimated' : 'City / town map pin · Check this is your intended place';
          } else manualPreview();
          setStatus('');
        }
      }
    }

    listen(input,'input',() => {
      clearTimeout(state.timer);
      state.sequence++;
      state.request?.abort();
      input.removeAttribute('aria-busy');
      clearPin();
      closeOptions();
      manualPreview();
      if (input.value.trim().length < 3) { setStatus(input.value ? 'Type at least 3 characters to search.' : ''); return; }
      setStatus('');
      state.timer = setTimeout(search, 280);
    });
    listen(input,'focus',() => { if (!state.selected && input.value.trim().length >= 3) { clearTimeout(state.timer); state.timer = setTimeout(search, 280); } });
    listen(input,'keydown',event => {
      if (event.key === 'Escape' && !list.hidden) { event.preventDefault(); event.stopPropagation(); closeOptions(); return; }
      if (event.key === 'Enter' && !list.hidden) { event.preventDefault(); if (state.highlighted >= 0) choose(state.highlighted); return; }
      if (!['ArrowDown','ArrowUp'].includes(event.key) || !state.options.length || list.hidden) return;
      event.preventDefault();
      state.highlighted = (state.highlighted + (event.key === 'ArrowDown' ? 1 : -1) + state.options.length) % state.options.length;
      list.querySelectorAll('[role="option"]').forEach((option,index) => option.setAttribute('aria-selected',String(index === state.highlighted)));
      const option = list.querySelector(`#birth-place-option-${state.highlighted}`);
      input.setAttribute('aria-activedescendant',option.id);
      option.scrollIntoView({block:'nearest'});
    });
    listen(list,'mousedown',event => event.preventDefault());
    listen(list,'click',event => { const option = event.target.closest('[data-birth-option]'); if (option) choose(Number(option.dataset.birthOption)); });
    listen(form,'focusout',event => { if (event.target === input && !form.querySelector('.birth-place-search').contains(event.relatedTarget)) closeOptions(); });
    form.querySelectorAll('[data-birth-accuracy]').forEach(select => listen(select,'change',() => updateAccuracy(select.dataset.birthAccuracy)));
    listen(previewButton,'click',() => {
      if (!state.selected) return;
      const {latitude:lat,longitude:lon,label} = state.selected;
      const url = new URL('https://www.openstreetmap.org/export/embed.html');
      url.search = new URLSearchParams({bbox:[Math.max(-180,lon-.07),Math.max(-90,lat-.045),Math.min(180,lon+.07),Math.min(90,lat+.045)].join(','),layer:'mapnik',marker:`${lat},${lon}`}).toString();
      const iframe = document.createElement('iframe');
      iframe.title = `Map of ${label}`;
      iframe.loading = 'lazy';
      iframe.referrerPolicy = 'no-referrer';
      iframe.src = url;
      frame.replaceChildren(iframe);
      frame.hidden = false;
      previewButton.hidden = true;
    });
  }

  function formatDate(value) { const [year,month,day] = value.split('-'); return `${day}/${month}/${year}`; }
  function formatTime(value) { const [hours,minutes] = value.split(':'); return `${Number(hours)%12 || 12}:${minutes} ${Number(hours)>=12 ? 'PM' : 'AM'}`; }

  function appendToMessage(data, lines) {
    const labels = {date:'Date of birth',time:'Time of birth',place:'Place of birth'};
    const keys = {date:'Date',time:'Time',place:'Place'};
    const birthLines = [];
    for (const kind of ['date','time','place']) {
      const key = keys[kind];
      const accuracy = data.get(`birth${key}Accuracy`);
      const value = String(data.get(accuracy === 'estimated' && kind !== 'place' ? `birth${key}Estimate` : `birth${key}`) || '').trim();
      if (accuracy === 'unknown') birthLines.push(`${labels[kind]}: Unknown`);
      else if (value) {
        const formatted = accuracy === 'confirmed' && kind === 'date' ? formatDate(value) : accuracy === 'confirmed' && kind === 'time' ? `${formatTime(value)} (local birth time)` : value;
        birthLines.push(`${labels[kind]}: ${formatted} (${accuracy === 'estimated' ? 'Estimated' : 'Confirmed'})`);
      }
    }
    const place = String(data.get('birthPlace') || '').trim();
    if (place && data.get('birthPlaceAccuracy') !== 'unknown') {
      const latitude = data.get('birthLatitude');
      const longitude = data.get('birthLongitude');
      if (latitude && longitude) birthLines.push(`Place map pin: ${latitude}, ${longitude}`);
      const query = latitude && longitude ? `${latitude},${longitude}` : place;
      birthLines.push(`Birthplace map: https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`);
    }
    const notes = String(data.get('birthDetailsNotes') || '').trim();
    if (notes) birthLines.push(`Birth details notes: ${notes}`);
    if (birthLines.length) lines.push('', 'Birth details:', ...birthLines, '');
  }

  window.LunicBirth = {fields, attach, detach, appendToMessage};
  dialog.addEventListener('close',detach);
})();
