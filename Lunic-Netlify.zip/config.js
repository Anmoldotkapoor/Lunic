// Lunic's WhatsApp inquiry number, including country code, digits only.
window.LUNIC_CONFIG = { whatsappNumber: '919990751200' };
