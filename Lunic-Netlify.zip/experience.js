'use strict';

(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  let motionPreference = true;
  try { motionPreference = localStorage.getItem('lunic-motion') !== 'off'; } catch { /* Motion works without storage. */ }
  let motionEnabled = motionPreference && !reducedMotion.matches;
  const motionControl = document.querySelector('.motion-control');
  const animations = new Set();

  function animate(element, keyframes, options = {}) {
    if (!motionEnabled || !element?.animate) return;
    const animation = element.animate(keyframes, {duration: 480, easing: 'cubic-bezier(.2,.7,.2,1)', ...options});
    animations.add(animation);
    animation.finished.then(() => animations.delete(animation), () => animations.delete(animation));
    return animation;
  }

  function animateGrid(grid, start = 0) {
    Array.from(grid.children).slice(start).forEach((card, index) => {
      animate(card, [{opacity: 0, transform: 'translateY(23px) scale(.985)'}, {opacity: 1, transform: 'translateY(0) scale(1)'}], {delay: Math.min(index, 8) * 45, duration: 550});
    });
  }

  function animateDialog() {
    animate(dialogContent, [{opacity: 0, transform: 'translateY(12px)'}, {opacity: 1, transform: 'translateY(0)'}], {duration: 360});
  }

  // A short, preference-led reading finder. It does not calculate a birth chart.
  let finder = {step: 1, intention: null, plan: null};
  const intentions = [
    {id: 'question', symbol: '☾', title: 'One question', copy: 'Something specific is on my mind.', suggestion: 'prashna'},
    {id: 'beginning', symbol: '✧', title: 'A new beginning', copy: 'I’m looking for a meaningful time to begin.', suggestion: 'prashna'},
    {id: 'direction', symbol: '◐', title: 'Life & direction', copy: 'I’d like perspective on where I am.', suggestion: 'crescent'},
    {id: 'picture', symbol: '○', title: 'The bigger picture', copy: 'I want to connect the patterns in my life.', suggestion: 'moonrise'},
    {id: 'reflection', symbol: '✦', title: 'Tarot & reflection', copy: 'I’d like to explore my questions through the cards.', suggestion: 'tarot'},
    {id:'private',symbol:'✧',title:'A private consultation',copy:'I’d like a conversation shaped around my priorities.',suggestion:'reserve'}
  ];

  function showFinder(reset = false) {
    if (reset) finder = {step: 1, intention: null, plan: null};
    const intention = intentions.find(item => item.id === finder.intention);
    const progress = `<div class="finder-progress" aria-label="Step ${finder.step} of 3">${['Your intention', 'Your space', 'Your reading'].map((label, index) => `<span class="${index + 1 <= finder.step ? 'complete' : ''}"><i>${index + 1 < finder.step ? '✓' : `0${index + 1}`}</i>${label}</span>`).join('')}</div>`;
    let content;
    if (finder.step === 1) {
      content = `<div class="dialog-eyebrow">A LITTLE DIRECTION FROM LUNIC</div><h2>What brings you<br><em>to this moment?</em></h2><p class="dialog-description">Start with what’s on your mind. There’s no wrong place to begin.</p><div class="finder-options">${intentions.map(item => `<button class="finder-option" data-finder-intention="${item.id}"><span class="finder-option-symbol" aria-hidden="true">${item.symbol}</span><span><strong>${item.title}</strong><small>${item.copy}</small></span>${icon('arrow')}</button>`).join('')}</div>`;
    } else if (finder.step === 2) {
      content = `<div class="dialog-eyebrow">YOUR INTENTION / ${intention.title.toUpperCase()}</div><h2>How much space<br><em>feels right?</em></h2><p class="dialog-description">Choose a focused moment, a longer conversation or a personal Tarot reading. You can always explore another reading.</p><div class="finder-options finder-duration-options">${consultations.map(plan => `<button class="finder-option${plan.id === intention.suggestion ? ' suggested' : ''}" data-finder-plan="${plan.id}"><div class="card-moon ${plan.moon}" aria-hidden="true"></div><span><strong>${plan.name}</strong><small>${plan.duration}${plan.id === intention.suggestion ? ' · Suggested for your intention' : ''}</small></span><span class="finder-option-price">${money(plan.price)} ${icon('arrow')}</span></button>`).join('')}</div><button class="text-link finder-back" data-action="finder-back">← Back to my intention</button>`;
    } else {
      const plan = consultations.find(item => item.id === finder.plan);
      const reasons = {
        prashna: 'A focused space for a Prashna question or Muhurta guidance. Bring the one thing you’d most like to explore.',
        crescent: 'A gentle introduction to your birth chart, with 15 minutes devoted to one life area and your personal questions.',
        moonrise: 'Room to connect related life themes, explore your current dashas and reflect on the questions shaping your next chapter.',
        purnima: 'A wider conversation about your chart, planetary periods and the priorities you’d like to explore in depth.',
        tarot: 'A personal Tarot reading with space for your questions. Explore the symbolism of the cards, reflect on your present circumstances and consider the possibilities ahead.',
        reserve: 'Soma Reserve is our VIP private Jyotish consultation. Begin with your priorities, then agree the focus, session duration and appointment personally. A considered conversation, shaped around you.'
      };
      content = `<div class="finder-result"><div class="finder-result-orbit" aria-hidden="true"><div class="card-moon ${plan.moon}"></div><span>✦</span></div><div class="dialog-eyebrow">A STARTING POINT FOR YOUR INTENTION</div><h2>${plan.name}</h2><p class="dialog-description">${reasons[plan.id]}</p><div class="finder-result-price"><strong>${money(plan.price)}</strong><span>${plan.duration} · One to one</span></div><button class="button finder-book" data-plan="${plan.id}">Explore my ${plan.name} reading ${icon('arrow')}</button><button class="text-link finder-back" data-action="finder-back">← Explore another reading</button></div>`;
    }
    openDialog(`<div class="dialog-content-padded finder-dialog">${progress}${content}</div>`, 'Find your personal reading');
  }

  // Continuous illumination, with direct manipulation and optional playback.
  const range = document.querySelector('#lunar-range');
  const lunarMoon = document.querySelector('.interactive-moon');
  const shadow = document.querySelector('.moon-shadow');
  const cycleButton = document.querySelector('[data-action="play-cycle"]');
  const illuminationLabel = document.querySelector('#lunar-illumination');
  const phaseContent = document.querySelector('.phase-content');
  const phaseSanskrit = document.querySelector('#phase-sanskrit');
  const phaseTitle = document.querySelector('#phase-title');
  const phaseDescription = document.querySelector('#phase-description');
  const phaseButtons = [...document.querySelectorAll('button[data-phase]')];
  const moonEdges = Array.from({length:51}, (_, index) => ({y:index * 2, edge:Math.sqrt(Math.max(0, 2500 - (index * 2 - 50) ** 2))}));
  let lastIllumination = -1;
  let lunarValue = 0;
  let lunarPhase = 'new';
  let cyclePlaying = false;
  let moonTweenId = 0;
  const phaseValues = {new: 0, waxing: 25, full: 50, waning: 75};

  function setCycle(value, announce = true) {
    lunarValue = Math.max(0, Math.min(100, value));
    const cosine = Math.cos(lunarValue / 100 * Math.PI * 2);
    const illumination = Math.round((1 - cosine) * 50);
    const waxing = lunarValue <= 50;
    const points = [];
    for (const {y, edge} of moonEdges) {
      points.push(`${(50 + (waxing ? cosine : -cosine) * edge).toFixed(2)}% ${y}%`);
    }
    shadow.style.clipPath = `polygon(${waxing ? '0% 0%' : '100% 0%'},${points.join(',')},${waxing ? '0% 100%' : '100% 100%'})`;
    shadow.style.transform = 'none';
    shadow.style.opacity = '1';
    lunarMoon.style.setProperty('--illumination', illumination / 100);
    range.value = lunarValue;
    range.style.setProperty('--range-progress', `${lunarValue}%`);
    if (illumination !== lastIllumination) {
      illuminationLabel.textContent = `${illumination}% illuminated`;
      lastIllumination = illumination;
    }
    const phaseKey = lunarValue < 6 || lunarValue > 94 ? 'new' : lunarValue < 44 ? 'waxing' : lunarValue <= 56 ? 'full' : 'waning';
    const name = {new: 'New moon', waxing: 'Waxing moon', full: 'Full moon', waning: 'Waning moon'}[phaseKey];
    range.setAttribute('aria-valuetext', `${name}, ${illumination}% illuminated`);
    // Playback is visual; screen readers receive the final phase when paused.
    if (phaseKey !== lunarPhase || announce) {
      const phase = phases[phaseKey];
      lunarPhase = phaseKey;
      lunarMoon.dataset.phase = phaseKey;
      phaseSanskrit.textContent = phase.sanskrit;
      phaseTitle.textContent = phase.title;
      phaseDescription.textContent = phase.description;
      phaseButtons.forEach(button => {
        const active = button.dataset.phase === phaseKey;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', active);
      });
      if (announce) animate(phaseContent, [{opacity: .2, transform: 'translateY(5px)'}, {opacity: 1, transform: 'translateY(0)'}], {duration: 300});
    }
  }

  function stopCycle() {
    cyclePlaying = false;
    cycleButton.setAttribute('aria-pressed', 'false');
    cycleButton.innerHTML = `${icon('play')}<span>Watch the cycle</span>`;
    phaseContent.setAttribute('aria-live', 'polite');
  }

  function selectPhase(key) {
    stopCycle();
    cancelAnimationFrame(moonTweenId);
    const from = lunarValue;
    const to = phaseValues[key];
    if (!motionEnabled) { setCycle(to); return; }
    const start = performance.now();
    function tween(now) {
      const progress = Math.min(1, (now - start) / 750);
      setCycle(from + (to - from) * (1 - (1 - progress) ** 3), false);
      if (progress < 1) moonTweenId = requestAnimationFrame(tween);
    }
    moonTweenId = requestAnimationFrame(tween);
  }

  range.addEventListener('input', () => {
    stopCycle();
    cancelAnimationFrame(moonTweenId);
    setCycle(Number(range.value), false);
  });
  setCycle(0, false);

  // Draw the atmosphere locally. No heavy animation framework or remote assets.
  const canvas = document.querySelector('.starfield');
  const context = canvas.getContext('2d');
  const hero = document.querySelector('.hero');
  const heroArt = document.querySelector('.hero-art');
  let width = 0;
  let height = 0;
  let stars = [];
  let heroVisible = true;
  let moonVisible = false;
  let frameId = 0;
  let lastFrame = 0;
  let elapsed = 0;
  const pointer = {x: .65, y: .4, targetX: .65, targetY: .4, inside: false};

  function resizeStars() {
    const rectangle = hero.getBoundingClientRect();
    width = rectangle.width;
    height = rectangle.height;
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    context?.setTransform(ratio, 0, 0, ratio, 0, 0);
    stars = Array.from({length: width < 650 ? 42 : 86}, () => ({x: Math.random(), y: Math.random() * .85, size: .5 + Math.random() * 1.2, speed: .15 + Math.random() * .8, phase: Math.random() * Math.PI * 2}));
    drawStars(0);
  }

  function drawStars(time) {
    if (!context || !width) return;
    context.clearRect(0, 0, width, height);
    pointer.x += (pointer.targetX - pointer.x) * .045;
    pointer.y += (pointer.targetY - pointer.y) * .045;
    if (motionEnabled && pointer.inside) heroArt.style.backgroundPosition = `calc(50% + ${(pointer.targetX - .5) * 16}px) calc(51% + ${(pointer.targetY - .5) * 12}px)`;
    const near = [];
    stars.forEach(star => {
      const x = star.x * width + (pointer.x - .5) * star.speed * 15;
      const y = star.y * height + Math.sin(time * .00015 * star.speed + star.phase) * 5;
      const alpha = motionEnabled ? .25 + (Math.sin(time * .0007 * star.speed + star.phase) + 1) * .23 : .4;
      context.fillStyle = `rgba(239,218,190,${alpha})`;
      context.beginPath();context.arc(x, y, star.size, 0, Math.PI * 2);context.fill();
      if (pointer.inside && Math.hypot(x - pointer.x * width, y - pointer.y * height) < 170) near.push({x,y});
    });
    if (motionEnabled && pointer.inside) {
      near.forEach((a, index) => near.slice(index + 1).forEach(b => {
        const distance = Math.hypot(a.x - b.x, a.y - b.y);
        if (distance < 110) {
          context.strokeStyle = `rgba(211,181,145,${(1 - distance / 110) * .22})`;
          context.lineWidth = .6;context.beginPath();context.moveTo(a.x,a.y);context.lineTo(b.x,b.y);context.stroke();
        }
      }));
    }
    const meteor = time % 12000;
    if (motionEnabled && meteor > 1500 && meteor < 2650) {
      const progress = (meteor - 1500) / 1150;
      const x = width * (.92 - progress * .4);
      const y = height * (.05 + progress * .25);
      const gradient = context.createLinearGradient(x, y, x + 100, y - 48);
      gradient.addColorStop(0, `rgba(246,222,186,${Math.sin(progress * Math.PI) * .7})`);
      gradient.addColorStop(1, 'rgba(246,222,186,0)');
      context.strokeStyle = gradient;context.lineWidth = 1.5;context.beginPath();context.moveTo(x,y);context.lineTo(x+100,y-48);context.stroke();
    }
  }

  function frame(now) {
    frameId = 0;
    if (!motionEnabled || document.hidden || dialog.open || (!heroVisible && !(cyclePlaying && moonVisible))) return;
    if (!lastFrame) lastFrame = now;
    const delta = Math.min(60, now - lastFrame);
    if (delta >= 30) {
      elapsed += delta;
      lastFrame = now;
      if (heroVisible) drawStars(elapsed);
      if (cyclePlaying && moonVisible) setCycle((lunarValue + delta / 280) % 100, false);
    }
    frameId = requestAnimationFrame(frame);
  }

  function resumeFrames() {
    if (!frameId && motionEnabled && !document.hidden && !dialog.open && (heroVisible || (cyclePlaying && moonVisible))) {
      lastFrame = 0;
      frameId = requestAnimationFrame(frame);
    }
  }

  function updateMotion() {
    motionEnabled = motionPreference && !reducedMotion.matches;
    document.body.dataset.motion = motionEnabled ? 'on' : 'off';
    document.documentElement.style.scrollBehavior = motionEnabled ? '' : 'auto';
    motionControl.disabled = reducedMotion.matches;
    motionControl.setAttribute('aria-pressed', String(motionEnabled));
    motionControl.setAttribute('aria-label', reducedMotion.matches ? 'Reduced motion is enabled in your system settings' : motionEnabled ? 'Pause ambient animations' : 'Resume ambient animations');
    motionControl.innerHTML = `${icon(motionEnabled ? 'pause' : 'play')}<span>${reducedMotion.matches ? 'Reduced motion' : motionEnabled ? 'Motion on' : 'Motion paused'}</span>`;
    if (!motionEnabled) {
      cancelAnimationFrame(frameId);frameId = 0;
      cancelAnimationFrame(moonTweenId);
      stopCycle();
      animations.forEach(animation => { try { animation.finish(); } catch { animation.cancel(); } });
      document.querySelectorAll('[style*="--tilt"], [style*="--magnet"]').forEach(element => {
        ['--tilt-x','--tilt-y','--magnet-x','--magnet-y'].forEach(property => element.style.removeProperty(property));
      });
      heroArt.style.backgroundPosition = '';
      heroArt.style.removeProperty('--scroll-parallax');
      drawStars(0);
    } else resumeFrames();
    cycleButton.disabled = !motionEnabled;
  }

  const appeared = new WeakSet();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      entry.target.classList.toggle('in-view', entry.isIntersecting);
      if (entry.target === hero) heroVisible = entry.isIntersecting;
      if (entry.target.matches('.moon-experience')) moonVisible = entry.isIntersecting;
      if (entry.isIntersecting && entry.target.matches('#consultation-grid, #product-grid, .journal-grid') && !appeared.has(entry.target)) {
        appeared.add(entry.target);animateGrid(entry.target);
      }
    });
    resumeFrames();
  }, {threshold: .05});
  document.querySelectorAll('.hero, .philosophy-art, .moon-experience, .closing, #consultation-grid, #product-grid, .journal-grid').forEach(element => observer.observe(element));
  const resizeObserver = new ResizeObserver(resizeStars);
  resizeObserver.observe(hero);
  document.addEventListener('visibilitychange', () => {
    document.body.toggleAttribute('data-page-hidden', document.hidden);
    if (document.hidden) { cancelAnimationFrame(frameId);frameId = 0; }
    else resumeFrames();
  });
  reducedMotion.addEventListener('change', updateMotion);
  dialog.addEventListener('close', resumeFrames);

  hero.addEventListener('pointermove', event => {
    if (!motionEnabled || !finePointer.matches) return;
    const rectangle = hero.getBoundingClientRect();
    pointer.targetX = (event.clientX - rectangle.left) / rectangle.width;
    pointer.targetY = (event.clientY - rectangle.top) / rectangle.height;
    pointer.inside = true;
  });
  hero.addEventListener('pointerleave', () => { pointer.inside = false;pointer.targetX = .65;pointer.targetY = .4;heroArt.style.backgroundPosition = ''; });

  // Responsive highlights follow the pointer, without replacing the cursor.
  let hoverFrame = 0;
  document.addEventListener('pointermove', event => {
    if (!motionEnabled || !finePointer.matches || hoverFrame) return;
    const card = event.target.closest('.consultation-card, .product-image, .reading-cosmos');
    const button = event.target.closest('.button');
    if (!card && !button) return;
    const {clientX, clientY} = event;
    hoverFrame = requestAnimationFrame(() => {
      hoverFrame = 0;
      if (card) {
        const rectangle = card.getBoundingClientRect();
        const x = (clientX - rectangle.left) / rectangle.width;
        const y = (clientY - rectangle.top) / rectangle.height;
        card.style.setProperty('--glow-x', `${x * 100}%`);card.style.setProperty('--glow-y', `${y * 100}%`);
        card.style.setProperty('--tilt-x', `${(y - .5) * -4}deg`);card.style.setProperty('--tilt-y', `${(x - .5) * 4}deg`);
      }
      if (button) {
        const rectangle = button.getBoundingClientRect();
        button.style.setProperty('--magnet-x', `${(clientX - rectangle.left - rectangle.width / 2) * .08}px`);
        button.style.setProperty('--magnet-y', `${(clientY - rectangle.top - rectangle.height / 2) * .12}px`);
      }
    });
  });
  document.addEventListener('pointerout', event => {
    const element = event.target.closest('.consultation-card, .product-image, .reading-cosmos, .button');
    if (!element || element.contains(event.relatedTarget)) return;
    ['--tilt-x','--tilt-y','--magnet-x','--magnet-y'].forEach(property => element.style.removeProperty(property));
  });

  const search = document.querySelector('#product-search');
  let searchFrame = 0;
  search.addEventListener('input', () => {
    productSearch = search.value;visibleProductCount = 9;
    if (!searchFrame) searchFrame = requestAnimationFrame(() => { searchFrame = 0;renderProducts(false); });
  });

  document.addEventListener('click', event => {
    const target = event.target.closest('button, a');
    if (!target) return;
    if (target.dataset.finderIntention) { finder.intention = target.dataset.finderIntention;finder.step = 2;showFinder(); }
    if (target.dataset.finderPlan) { finder.plan = target.dataset.finderPlan;window.LunicReadings?.select(finder.plan, {withMotion: false});finder.step = 3;showFinder(); }
    if (target.dataset.save || target.dataset.dialogSave) {
      animate(document.querySelector('.bag-button'), [{transform: 'scale(1)'}, {transform: 'scale(1.3) rotate(-7deg)'}, {transform: 'scale(1)'}], {duration: 450});
    }
    if (target.matches('.button') && motionEnabled && event.detail) {
      const rectangle = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'button-ripple';ripple.setAttribute('aria-hidden','true');
      ripple.style.left = `${event.clientX - rectangle.left}px`;ripple.style.top = `${event.clientY - rectangle.top}px`;
      target.append(ripple);setTimeout(() => ripple.remove(), 700);
    }
    switch (target.dataset.action) {
      case 'find-reading': showFinder(true);break;
      case 'finder-back': finder.step = Math.max(1, finder.step - 1);showFinder();break;
      case 'toggle-motion':
        motionPreference = !motionPreference;
        try { localStorage.setItem('lunic-motion', motionPreference ? 'on' : 'off'); } catch { /* Optional preference only. */ }
        updateMotion();break;
      case 'play-cycle':
        if (!motionEnabled) break;
        cancelAnimationFrame(moonTweenId);
        if (cyclePlaying) stopCycle();
        else { cyclePlaying = true;phaseContent.setAttribute('aria-live','off');cycleButton.setAttribute('aria-pressed','true');cycleButton.innerHTML = `${icon('pause')}<span>Pause the cycle</span>`;resumeFrames(); }
        break;
      case 'reset-collection':
        productSearch = '';search.value = '';activeFilter = 'all';visibleProductCount = 9;resetProductFacets();
        document.querySelectorAll('[data-filter]').forEach(button => { const active = button.dataset.filter === 'all';button.classList.toggle('active',active);button.setAttribute('aria-pressed',active); });
        renderProducts();search.focus({preventScroll:true});break;
      case 'zoom-product': {
        const stage = target.closest('.product-image-stage');
        const zoomed = stage.classList.toggle('zoomed');
        target.setAttribute('aria-pressed',String(zoomed));
        target.setAttribute('aria-label',zoomed ? 'Zoom out of product image' : 'Zoom in on product image');
        target.innerHTML = `${icon('zoom')}<span>${zoomed ? 'Back to full view' : 'Look closer'}</span>`;
        break;
      }
      case 'scroll-top': window.scrollTo({top:0,behavior:motionEnabled ? 'smooth' : 'auto'});break;
    }
  });

  const navigationLinks = Array.from(document.querySelectorAll('.desktop-nav a, #mobile-nav a'));
  const navigationSections = ['philosophy','consultations','collection','journal'].map(id => document.getElementById(id));
  const progress = document.querySelector('.reading-progress span');
  const topButton = document.querySelector('.back-to-top');
  let scrollQueued = false;
  function updateScroll() {
    scrollQueued = false;
    const scrollable = document.documentElement.scrollHeight - innerHeight;
    progress.style.transform = `scaleX(${scrollable ? scrollY / scrollable : 0})`;
    topButton.classList.toggle('visible', scrollY > 650);
    topButton.tabIndex = scrollY > 650 ? 0 : -1;
    document.querySelector('.site-header').classList.toggle('scrolled',scrollY > 30);
    let active = '';
    navigationSections.forEach(section => { if (section.getBoundingClientRect().top <= 180) active = section.id; });
    navigationLinks.forEach(link => {
      const current = link.hash === `#${active}`;
      link.classList.toggle('current', current);
      if (current) link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');
    });
    if (heroVisible && motionEnabled) heroArt.style.setProperty('--scroll-parallax', `${Math.min(scrollY * .045, 25)}px`);
  }
  window.addEventListener('scroll', () => { if (!scrollQueued) {scrollQueued = true;requestAnimationFrame(updateScroll);} }, {passive:true});
  window.addEventListener('resize',updateScroll);

  window.LunicExperience = {animateGrid, animateDialog, setPhase: selectPhase};
  resizeStars();updateMotion();updateScroll();
})();
