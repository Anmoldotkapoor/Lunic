// Lunic's WhatsApp inquiry number, including country code, digits only.
window.LUNIC_CONFIG = { whatsappNumber: '919990751200' };

;
'use strict';

// Concept catalog. Availability, actual stone specifications and prices are confirmed on inquiry.
// Traditional Navaratna associations: https://www.gia.edu/gia-website/jewels-of-india
window.LUNIC_GEMSTONES = [
  {
    id: 'ruby', name: 'Ruby', vernacular: 'Manik', series: 'navaratna',
    planet: 'Surya · Sun', categoryLabel: 'SURYA · SUN', tag: 'NAVARATNA',
    aliases: ['manikya', 'manikyam', 'surya', 'sun', 'माणिक्य', 'माणिक'],
    image: 'gemstones/ruby.webp',
    subtitle: 'A luminous expression of the Sun.',
    description: 'A richly coloured ruby, envisioned in an elegant oval cut. Known as Manik in the Vedic gemstone tradition, ruby is the Navaratna gem associated with Surya, the Sun.',
    details: ['Manik', 'Ruby · Corundum', 'Sun · Surya'],
    tradition: 'Explore ruby through its traditional solar symbolism. Your inquiry can include preferred colour, cut, carat weight and a conversation about its relevance to your personal chart.'
  },
  {
    id: 'pearl', name: 'Pearl', vernacular: 'Moti', series: 'navaratna',
    planet: 'Chandra · Moon', categoryLabel: 'CHANDRA · MOON', tag: 'NAVARATNA',
    aliases: ['chandra pearl', 'mukta', 'moti', 'moon', 'मोती', 'चन्द्र'],
    image: 'pearl.webp',
    subtitle: 'The quiet luminosity of Chandra.',
    description: 'A softly luminous pearl, traditionally known as Moti and associated with Chandra, the Moon. Its gentle nacre makes it a natural expression of Lunic’s lunar world.',
    details: ['Moti', 'Pearl', 'Moon · Chandra'],
    tradition: 'Pearl is one of the nine Navaratna gems. Ask about the available pearl’s type, origin, size and lustre, alongside personal guidance on its traditional astrological use.'
  },
  {
    id: 'red-coral', name: 'Red Coral', vernacular: 'Moonga', series: 'navaratna',
    planet: 'Mangal · Mars', categoryLabel: 'MANGAL · MARS', tag: 'NAVARATNA',
    aliases: ['munga', 'moonga', 'mangala', 'vidruma', 'mars', 'मूंगा', 'मंगल'],
    image: 'gemstones/red-coral.webp',
    subtitle: 'A warm vermilion connection to Mangal.',
    description: 'A smooth, domed red coral cabochon in a warm vermilion hue. Moonga occupies the place of Mangal, or Mars, in the traditional Navaratna collection.',
    details: ['Moonga', 'Polished cabochon', 'Mars · Mangal'],
    tradition: 'Discuss the traditional meaning of Moonga and ask about material identity, provenance, finish and availability when making your personal inquiry.'
  },
  {
    id: 'emerald', name: 'Emerald', vernacular: 'Panna', series: 'navaratna',
    planet: 'Budha · Mercury', categoryLabel: 'BUDHA · MERCURY', tag: 'NAVARATNA',
    aliases: ['panna', 'marakata', 'mercury', 'budh', 'पन्ना', 'बुध'],
    image: 'gemstones/emerald.webp',
    subtitle: 'Budha’s green gem, thoughtfully chosen.',
    description: 'A deep green emerald with architectural step-cut facets. Known as Panna, this member of the beryl family is traditionally associated with Budha, or Mercury.',
    details: ['Panna', 'Emerald · Beryl', 'Mercury · Budha'],
    tradition: 'Explore Panna’s place in the Navaratna tradition. Ask about the actual stone’s colour, inclusions, treatment disclosure, cut and any available gemological report.'
  },
  {
    id: 'yellow-sapphire', name: 'Yellow Sapphire', vernacular: 'Pukhraj', series: 'navaratna',
    planet: 'Guru · Jupiter', categoryLabel: 'GURU · JUPITER', tag: 'NAVARATNA',
    aliases: ['pukhraj', 'pushparaga', 'brihaspati', 'guru', 'jupiter', 'पुखराज', 'बृहस्पति'],
    image: 'gemstones/yellow-sapphire.webp',
    subtitle: 'Golden light, in the tradition of Guru.',
    description: 'A golden yellow sapphire envisioned in a luminous oval cut. Pukhraj is the traditional Navaratna stone of Guru, also called Brihaspati or Jupiter.',
    details: ['Pukhraj', 'Sapphire · Corundum', 'Jupiter · Guru'],
    tradition: 'Bring your questions about Pukhraj to a personal conversation. The available stone’s shade, carat weight, treatment details and pricing can be discussed on inquiry.'
  },
  {
    id: 'diamond', name: 'Diamond', vernacular: 'Heera', series: 'navaratna',
    planet: 'Shukra · Venus', categoryLabel: 'SHUKRA · VENUS', tag: 'NAVARATNA',
    aliases: ['heera', 'hira', 'vajra', 'shukra', 'venus', 'हीरा', 'शुक्र'],
    image: 'gemstones/diamond.webp',
    subtitle: 'Shukra’s gem of clear brilliance.',
    description: 'A round brilliant diamond with a crisp play of light. Traditionally called Heera or Vajra, diamond represents Shukra, or Venus, in the nine-gem tradition.',
    details: ['Heera', 'Round brilliant concept', 'Venus · Shukra'],
    tradition: 'A personal selection can take account of your intended use, preferred cut and budget. Ask about natural or laboratory-grown origin, specifications and any independent report for the actual stone.'
  },
  {
    id: 'blue-sapphire', name: 'Blue Sapphire', vernacular: 'Neelam', series: 'navaratna',
    planet: 'Shani · Saturn', categoryLabel: 'SHANI · SATURN', tag: 'NAVARATNA',
    aliases: ['neelam', 'nilam', 'indraneel', 'shani', 'saturn', 'नीलम', 'शनि'],
    image: 'gemstones/blue-sapphire.webp',
    subtitle: 'Deep blue, in the tradition of Shani.',
    description: 'A royal blue sapphire with a softly squared cushion silhouette. Neelam is the traditional Navaratna gem associated with Shani, or Saturn.',
    details: ['Neelam', 'Sapphire · Corundum', 'Saturn · Shani'],
    tradition: 'Explore Neelam in the context of your own chart and intentions. Ask about the available stone’s colour, cut, origin, treatment disclosure and report details.'
  },
  {
    id: 'hessonite', name: 'Hessonite', vernacular: 'Gomed', series: 'navaratna',
    planet: 'Rahu · North lunar node', categoryLabel: 'RAHU · NORTH LUNAR NODE', tag: 'NAVARATNA',
    aliases: ['gomed', 'gomeda', 'gomedh', 'rahu', 'north node', 'गोमेद', 'राहु'],
    image: 'gemstones/hessonite.webp',
    subtitle: 'Honeyed light, traditionally linked with Rahu.',
    description: 'A honey-cinnamon hessonite garnet, with warm amber depths and softly glowing facets. Gomed is the Navaratna stone associated with Rahu, the north lunar node.',
    details: ['Gomed', 'Hessonite · Garnet', 'Rahu · North lunar node'],
    tradition: 'Discover Gomed’s traditional symbolism through a personal consultation. Availability, actual colour, clarity, cut and gemological identification can be discussed on inquiry.'
  },
  {
    id: 'cats-eye', name: 'Cat’s Eye', vernacular: 'Lehsunia', series: 'navaratna',
    planet: 'Ketu · South lunar node', categoryLabel: 'KETU · SOUTH LUNAR NODE', tag: 'NAVARATNA',
    aliases: ['cats eye', 'cat eye', "cat's eye", 'lehsuniya', 'lahsuniya', 'vaidurya', 'chrysoberyl', 'ketu', 'south node', 'लहसुनिया', 'केतु'],
    image: 'gemstones/cats-eye.webp',
    subtitle: 'An unmistakable line of light.',
    description: 'A chrysoberyl cat’s-eye cabochon, distinguished by a narrow band of reflected light across its domed surface. Known as Lehsunia, it is the Navaratna gem traditionally associated with Ketu.',
    details: ['Lehsunia', 'Cat’s-eye · Chrysoberyl', 'Ketu · South lunar node'],
    tradition: 'Ask about the identity of the cat’s-eye material, its colour, the character of its chatoyant band and the actual piece available, alongside guidance on its traditional use.'
  },
  {
    id: 'white-sapphire', name: 'White Sapphire', vernacular: 'Safed Pukhraj', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'COLOURLESS CORUNDUM',
    aliases: ['safed pukhraj', 'white pukhraj', 'colorless sapphire', 'colourless sapphire', 'shukra', 'venus', 'सफेद पुखराज'],
    image: 'gemstones/white-sapphire.webp',
    subtitle: 'A quieter kind of brilliance.',
    description: 'An oval white sapphire with cool, clear facets and restrained silver-white reflections. A considered choice for someone drawn to colourless gemstones and a subtle play of light.',
    details: ['Safed Pukhraj', 'Sapphire · Corundum', 'Companion gemstone'],
    tradition: 'White sapphire is discussed as a companion to Venus-associated gems in some Jyotish traditions. Explore its material character and personal relevance in your inquiry.'
  },
  {
    id: 'opal', name: 'Opal', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'PLAY OF COLOUR',
    aliases: ['white opal', 'fire colours', 'play of color', 'play of colour', 'ओपल'],
    image: 'gemstones/opal.webp',
    subtitle: 'A small universe of shifting colour.',
    description: 'A milky opal cabochon with delicate flashes of colour that change with the light. Its gentle iridescence makes each actual stone a distinctly personal selection.',
    details: ['Opal', 'Cabochon concept', 'Companion gemstone'],
    tradition: 'Choose for its beauty and the meaning it holds for you. Ask about the actual opal’s type, origin, colour pattern, care and availability.'
  },
  {
    id: 'citrine', name: 'Citrine', vernacular: 'Sunela', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'GOLDEN QUARTZ',
    aliases: ['sunela', 'yellow quartz', 'golden quartz', 'सुनेला'],
    image: 'gemstones/citrine.webp',
    subtitle: 'A little golden warmth, held in stone.',
    description: 'A cushion-cut citrine with honey-gold colour and broad, luminous quartz facets. A warm addition to a personal gemstone collection or an intentionally chosen piece of jewellery.',
    details: ['Sunela', 'Citrine · Quartz', 'Companion gemstone'],
    tradition: 'Discuss its colour, size, cut and any treatment information when choosing an actual piece. Personal astrological guidance is available separately on inquiry.'
  },
  {
    id: 'peridot', name: 'Peridot', vernacular: 'Zabarjad', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'OLIVE-GREEN LIGHT',
    aliases: ['zabarjad', 'olivine', 'green peridot', 'जबरजद'],
    image: 'gemstones/peridot.webp',
    subtitle: 'Fresh green, with a golden undertone.',
    description: 'A pear-shaped peridot with lively olive-green colour and a gentle golden undertone. Its distinctive shade brings a fresh expression to the companion gemstone edit.',
    details: ['Zabarjad', 'Peridot · Olivine', 'Companion gemstone'],
    tradition: 'A personal inquiry can explore the actual stone’s hue, proportions, carat weight and available setting options, along with any questions about traditional use.'
  },
  {
    id: 'red-garnet', name: 'Red Garnet', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'DEEP WINE RED',
    aliases: ['garnet', 'wine red', 'garnet stone', 'गार्नेट'],
    image: 'gemstones/red-garnet.webp',
    subtitle: 'Rich colour. A grounded presence.',
    description: 'A deep wine-red garnet with glowing burgundy edges and precise cushion-cut facets. An expressive choice for someone drawn to rich colour and a quieter, darker brilliance.',
    details: ['Red garnet', 'Cushion-cut concept', 'Companion gemstone'],
    tradition: 'Explore the garnet variety, colour and actual piece available through a personal inquiry. Traditional gemstone selections can also be discussed during a consultation.'
  },
  {
    id: 'blue-topaz', name: 'Blue Topaz', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'SKY-BLUE CLARITY',
    aliases: ['sky blue topaz', 'topaz', 'blue topaz stone', 'नीला टोपाज'],
    image: 'gemstones/blue-topaz.webp',
    subtitle: 'A clear-sky colour, close at hand.',
    description: 'A pear-cut blue topaz with pale sky-blue colour and crisp reflections. A light, airy expression within the companion gemstone collection.',
    details: ['Blue topaz', 'Pear-cut concept', 'Companion gemstone'],
    tradition: 'Ask about the shade, treatment disclosure, dimensions and care of the actual gemstone. Choose the colour and form that feels relevant to your collection.'
  },
  {
    id: 'turquoise', name: 'Turquoise', vernacular: 'Firoza', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'EARTH & SKY',
    aliases: ['firoza', 'feroza', 'turquoise stone', 'फिरोजा', 'फिरोज़ा'],
    image: 'gemstones/turquoise.webp',
    subtitle: 'Blue-green colour, shaped by the earth.',
    description: 'An oval turquoise cabochon with blue-green colour and a delicate web of dark matrix. Known as Firoza, it brings an earthy, distinctly individual character to the collection.',
    details: ['Firoza', 'Turquoise cabochon', 'Companion gemstone'],
    tradition: 'Ask about the actual stone’s matrix pattern, material identity, stabilisation or other treatment, dimensions and availability when making your selection.'
  }
].map(stone => ({category: 'gemstones', ...stone}));

;
'use strict';

// AI concept catalog. Geometry, inscriptions, materials and preparation are confirmed on inquiry.
// Context: https://www.britishmuseum.org/collection/object/A_1940-0716-329
// Navagraha: https://old.ssvt.org/Deities/navagrahas.asp
window.LUNIC_YANTRAS = [
  {
    "id": "surya-yantra",
    "name": "Surya Yantra",
    "vernacular": "Aditya · Sun",
    "family": "planetary",
    "planet": "Surya · Sun",
    "aliases": [
      "aditya",
      "ravi",
      "sun",
      "सूर्य",
      "आदित्य"
    ],
    "image": "yantras/surya-yantra.webp",
    "subtitle": "A considered moment for your solar centre.",
    "description": "A copper-toned yantra concept dedicated to Surya, the Sun in Jyotish. Its warm finish and ordered geometry offer a focal point for a personal solar practice or a thoughtfully arranged altar.",
    "details": [
      "Surya · Sun",
      "Copper-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "chandra-yantra",
    "name": "Chandra Yantra",
    "vernacular": "Soma · Moon",
    "family": "planetary",
    "planet": "Chandra · Moon",
    "aliases": [
      "soma",
      "chand",
      "moon",
      "चंद्र",
      "चन्द्र",
      "सोम"
    ],
    "image": "chandra.webp",
    "subtitle": "Make space for your inner moon.",
    "description": "A warm copper-toned yantra concept dedicated to Chandra, the Moon. A quiet expression of Lunic’s lunar world, envisioned for a personal altar and a reflective moment in your day.",
    "details": [
      "Chandra · Moon",
      "Copper-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "mangal-yantra",
    "name": "Mangal Yantra",
    "vernacular": "Mangala · Mars",
    "family": "planetary",
    "planet": "Mangal · Mars",
    "aliases": [
      "mangala",
      "angaraka",
      "kuja",
      "mars",
      "मंगल",
      "मङ्गल"
    ],
    "image": "yantras/mangal-yantra.webp",
    "subtitle": "Bring attention to the way you act.",
    "description": "A red-copper yantra concept dedicated to Mangal, also known as Mangala or Angaraka. Explore its place in the Navagraha tradition and discuss how a planetary practice relates to your own birth chart.",
    "details": [
      "Mangal · Mars",
      "Red-copper concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "budha-yantra",
    "name": "Budha Yantra",
    "vernacular": "Budh · Mercury",
    "family": "planetary",
    "planet": "Budha · Mercury",
    "aliases": [
      "budh",
      "mercury",
      "बुध"
    ],
    "image": "yantras/budha-yantra.webp",
    "subtitle": "An invitation to thoughtful expression.",
    "description": "A finely engraved bronze-toned concept dedicated to Budha, Mercury in Jyotish. Designed as a considered addition to a sacred corner, with personal guidance available on its traditional context.",
    "details": [
      "Budha · Mercury",
      "Bronze-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "brihaspati-yantra",
    "name": "Brihaspati Yantra",
    "vernacular": "Guru · Jupiter",
    "family": "planetary",
    "planet": "Brihaspati · Jupiter",
    "aliases": [
      "guru",
      "brihaspathi",
      "jupiter",
      "बृहस्पति",
      "गुरु"
    ],
    "image": "yantras/brihaspati-yantra.webp",
    "subtitle": "A little room for a wider perspective.",
    "description": "A honey-gold yantra concept dedicated to Brihaspati, or Guru, the Jupiter graha. Its warm metal and measured geometry create a contemplative focal point for a personal devotional space.",
    "details": [
      "Guru · Jupiter",
      "Brass-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "shukra-yantra",
    "name": "Shukra Yantra",
    "vernacular": "Shukra · Venus",
    "family": "planetary",
    "planet": "Shukra · Venus",
    "aliases": [
      "sukra",
      "venus",
      "शुक्र"
    ],
    "image": "yantras/shukra-yantra.webp",
    "subtitle": "Find grace in the attention you give.",
    "description": "A softly luminous, gold-toned concept dedicated to Shukra, Venus in the Navagraha tradition. An elegant object to explore through its devotional meaning and its relevance to your personal practice.",
    "details": [
      "Shukra · Venus",
      "Gold-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "shani-yantra",
    "name": "Shani Yantra",
    "vernacular": "Shanidev · Saturn",
    "family": "planetary",
    "planet": "Shani · Saturn",
    "aliases": [
      "sani",
      "shanidev",
      "saturn",
      "शनि",
      "शनिदेव"
    ],
    "image": "yantras/shani-yantra.webp",
    "subtitle": "A quiet companion to patient practice.",
    "description": "An aged copper-toned yantra concept dedicated to Shani, Saturn in Jyotish. The darker patina and precise lines create a restrained, contemplative presence for a personal altar.",
    "details": [
      "Shani · Saturn",
      "Aged-copper concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "rahu-yantra",
    "name": "Rahu Yantra",
    "vernacular": "Rahu · North lunar node",
    "family": "planetary",
    "planet": "Rahu · North lunar node",
    "aliases": [
      "north node",
      "ascending node",
      "राहु"
    ],
    "image": "yantras/rahu-yantra.webp",
    "subtitle": "An invitation to look a little deeper.",
    "description": "A smoky bronze-toned yantra concept dedicated to Rahu, the ascending lunar node used in Jyotish. Explore this form with a conversation about the wider chart and the tradition behind a planetary practice.",
    "details": [
      "Rahu · Lunar node",
      "Bronze-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "ketu-yantra",
    "name": "Ketu Yantra",
    "vernacular": "Ketu · South lunar node",
    "family": "planetary",
    "planet": "Ketu · South lunar node",
    "aliases": [
      "south node",
      "descending node",
      "केतु"
    ],
    "image": "yantras/ketu-yantra.webp",
    "subtitle": "A considered space for inward attention.",
    "description": "An antique brass-toned yantra concept dedicated to Ketu, the descending lunar node used in Jyotish. A contemplative object to choose with an understanding of its meaning and your personal practice.",
    "details": [
      "Ketu · Lunar node",
      "Antique-brass concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "sri-yantra",
    "name": "Sri Yantra",
    "vernacular": "Shri Chakra · Tripura Sundari",
    "family": "devotional",
    "deity": "Lalita Tripura Sundari",
    "aliases": [
      "shree",
      "shri chakra",
      "sri chakra",
      "srichakra",
      "lalita",
      "tripura sundari",
      "श्री यंत्र",
      "श्री चक्र"
    ],
    "image": "yantras/sri-yantra.webp",
    "subtitle": "Many lines. One still centre.",
    "description": "A flat copper-toned interpretation of the Sri Chakra, a revered yantra in Sri Vidya traditions. Interlocking triangles, lotus forms and a central bindu inspire a contemplative object for a sacred space.",
    "details": [
      "Sri Chakra",
      "Flat-plate concept",
      "Sri Vidya tradition"
    ]
  },
  {
    "id": "meru",
    "name": "Sri Meru Yantra",
    "vernacular": "Maha Meru · Sri Chakra",
    "family": "devotional",
    "deity": "Lalita Tripura Sundari",
    "aliases": [
      "maha meru",
      "mahameru",
      "shri meru",
      "sri chakra",
      "three dimensional",
      "3d",
      "श्री मेरु"
    ],
    "image": "yantra.webp",
    "subtitle": "An invitation to centre your intention.",
    "description": "A three-dimensional interpretation of the Sri Yantra, with ascending geometric tiers and a warm brass finish. A sculptural focal point for meditation and a thoughtfully arranged sacred space.",
    "details": [
      "Maha Meru form",
      "Brass-tone concept",
      "Sri Vidya tradition"
    ]
  },
  {
    "id": "lakshmi-yantra",
    "name": "Maha Lakshmi Yantra",
    "vernacular": "Mahalakshmi · Shri",
    "family": "devotional",
    "deity": "Lakshmi",
    "aliases": [
      "mahalaxmi",
      "mahalakshmi",
      "laxmi",
      "श्री लक्ष्मी",
      "महालक्ष्मी"
    ],
    "image": "yantras/lakshmi-yantra.webp",
    "subtitle": "A place for gratitude and abundance.",
    "description": "A lotus-inspired, brass-toned yantra concept dedicated to Maha Lakshmi. Envisioned as a meaningful focal point for Lakshmi devotion, a home altar or a personal moment of gratitude.",
    "details": [
      "Maha Lakshmi",
      "Brass-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "kubera-yantra",
    "name": "Kubera Yantra",
    "vernacular": "Kuber · Dhanada",
    "family": "devotional",
    "deity": "Kubera",
    "aliases": [
      "kuber",
      "dhanada",
      "धन कुबेर",
      "कुबेर"
    ],
    "image": "yantras/kubera-yantra.webp",
    "subtitle": "Consider what you choose to value.",
    "description": "A warm antique-brass yantra concept dedicated to Kubera. Its balanced grid and substantial metal finish create a considered object to explore within the context of a personal devotional practice.",
    "details": [
      "Kubera",
      "Antique-brass concept",
      "Devotional collection"
    ]
  },
  {
    "id": "ganesha-yantra",
    "name": "Ganesha Yantra",
    "vernacular": "Ganapati · Vinayaka",
    "family": "devotional",
    "deity": "Ganesha",
    "aliases": [
      "ganesh",
      "ganpati",
      "ganapati",
      "vinayaka",
      "गणेश",
      "गणपति"
    ],
    "image": "yantras/ganesha-yantra.webp",
    "subtitle": "Begin with presence and intention.",
    "description": "A copper-toned yantra concept dedicated to Ganesha, also known as Ganapati. A thoughtful choice for a devotional corner and a personal ritual marking a meaningful beginning.",
    "details": [
      "Ganesha · Ganapati",
      "Copper-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "saraswati-yantra",
    "name": "Saraswati Yantra",
    "vernacular": "Sarasvati · Sharada",
    "family": "devotional",
    "deity": "Saraswati",
    "aliases": [
      "sarasvati",
      "sharada",
      "vidya",
      "सरस्वती",
      "शारदा"
    ],
    "image": "yantras/saraswati-yantra.webp",
    "subtitle": "Make room for learning and expression.",
    "description": "A pale gold-toned yantra concept dedicated to Saraswati. Fine engraving and a quiet, luminous finish offer a contemplative object for a study space, music corner or personal altar.",
    "details": [
      "Saraswati · Sharada",
      "Gold-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "durga-yantra",
    "name": "Durga Yantra",
    "vernacular": "Devi Durga · Shakti",
    "family": "devotional",
    "deity": "Durga",
    "aliases": [
      "devi",
      "shakti",
      "दुर्गा",
      "शक्ति"
    ],
    "image": "yantras/durga-yantra.webp",
    "subtitle": "An expression of devotion to Shakti.",
    "description": "A red-copper yantra concept dedicated to Devi Durga. Its layered geometry and warm metal finish are envisioned as a devotional focal point for a considered sacred space.",
    "details": [
      "Devi Durga",
      "Red-copper concept",
      "Devotional collection"
    ]
  },
  {
    "id": "mahamrityunjaya-yantra",
    "name": "Mahamrityunjaya Yantra",
    "vernacular": "Shiva · Tryambaka",
    "family": "devotional",
    "deity": "Shiva",
    "aliases": [
      "maha mrityunjaya",
      "mahamrityunjay",
      "mrityunjay",
      "tryambaka",
      "शिव",
      "महामृत्युंजय"
    ],
    "image": "yantras/mahamrityunjaya-yantra.webp",
    "subtitle": "Return to a quiet moment of devotion.",
    "description": "An antique copper-toned concept associated with Shiva’s Mahamrityunjaya tradition. A reflective addition to a Shiva altar, with its actual design and the intended devotional practice discussed personally.",
    "details": [
      "Shiva · Tryambaka",
      "Copper-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "hanuman-yantra",
    "name": "Hanuman Yantra",
    "vernacular": "Bajrangbali · Anjaneya",
    "family": "devotional",
    "deity": "Hanuman",
    "aliases": [
      "bajrangbali",
      "anjaneya",
      "maruti",
      "हनुमान",
      "बजरंगबली"
    ],
    "image": "yantras/hanuman-yantra.webp",
    "subtitle": "A reminder of devotion in action.",
    "description": "A warm bronze-toned yantra concept dedicated to Hanuman, also known as Anjaneya. Envisioned for a personal altar and a devotional practice grounded in attention and understanding.",
    "details": [
      "Hanuman · Anjaneya",
      "Bronze-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "baglamukhi-yantra",
    "name": "Baglamukhi Yantra",
    "vernacular": "Bagalamukhi · Pitambara",
    "family": "devotional",
    "deity": "Baglamukhi",
    "aliases": [
      "bagalamukhi",
      "pitambara",
      "bagla mukhi",
      "बगलामुखी",
      "पीताम्बरा"
    ],
    "image": "yantras/baglamukhi-yantra.webp",
    "subtitle": "A focused expression of Devi devotion.",
    "description": "A golden brass-toned yantra concept dedicated to Baglamukhi, one of the Mahavidyas. Explore this form with guidance on its particular tradition, meaning and devotional context.",
    "details": [
      "Baglamukhi · Pitambara",
      "Brass-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "navagraha-yantra",
    "name": "Navagraha Yantra",
    "vernacular": "Nava Graha · The nine grahas",
    "family": "devotional",
    "deity": "Navagraha",
    "aliases": [
      "navgraha",
      "nava graha",
      "nine planets",
      "nine grahas",
      "नवग्रह"
    ],
    "image": "yantras/navagraha-yantra.webp",
    "subtitle": "Nine grahas. One considered composition.",
    "description": "A combined brass-toned yantra concept bringing the nine grahas into one composition: Surya, Chandra, Mangal, Budha, Brihaspati, Shukra, Shani, Rahu and Ketu. A companion to a broader conversation about your chart.",
    "details": [
      "Combined Navagraha",
      "Brass-tone concept",
      "Nine-graha composition"
    ]
  },
  {
    "id": "vastu-purusha-yantra",
    "name": "Vastu Purusha Yantra",
    "vernacular": "Vastu Mandala · Sacred space",
    "family": "space",
    "deity": "Vastu Purusha",
    "aliases": [
      "vaastu",
      "vastu mandala",
      "vastu purush",
      "home",
      "space",
      "वास्तु",
      "वास्तु पुरुष"
    ],
    "image": "yantras/vastu-purusha-yantra.webp",
    "subtitle": "Bring intention to the space you inhabit.",
    "description": "A copper-toned yantra concept inspired by the ordered grid of a Vastu mandala. A considered object for exploring the relationship between sacred geometry, architectural space and your own home.",
    "details": [
      "Vastu mandala",
      "Copper-tone concept",
      "Space & ritual"
    ]
  }
].map(yantra => ({
  ...yantra,
  category: 'yantras',
  series: yantra.family === 'planetary' ? 'navagraha-yantra' : 'sacred-yantra',
  categoryLabel: yantra.planet ? yantra.planet.toUpperCase() : yantra.family === 'space' ? 'SPACE & SACRED GEOMETRY' : 'DEVOTION & SACRED GEOMETRY',
  tag: yantra.family === 'planetary' ? 'NAVAGRAHA' : yantra.family === 'space' ? 'VASTU & SPACE' : 'SACRED FORMS',
  tradition: 'Ask about the actual yantra’s geometry, inscriptions, metal, dimensions and any ritual preparation. The AI artwork is a visual concept; placement and worship guidance should follow the tradition you practise.'
}));

;
'use strict';

// Concept selections. Origin, mukhi count and natural formation are verified on the actual bead.
// Background: https://www.himalayanacademy.com/wp-content/uploads/2025/02/1997-mar-insight-tulsi-and-rudraksha.pdf
window.LUNIC_RUDRAKSHA = (() => {
  const origins = [
    {id:'nepali', label:'Nepali', place:'Nepal', character:'A deeply textured, earthy brown concept with a sculptural, rugged surface.'},
    {id:'java', label:'Java', place:'Java · Indonesia', character:'A compact, warm brown concept with a finer, closely textured surface.'}
  ];
  const names = [
    ['Ek Mukhi','One face','एकमुखी'],
    ['Dwi Mukhi','Two faces','द्विमुखी'],
    ['Tri Mukhi','Three faces','त्रिमुखी'],
    ['Chatur Mukhi','Four faces','चतुर्मुखी'],
    ['Pancha Mukhi','Five faces','पंचमुखी'],
    ['Shat Mukhi','Six faces','षण्मुखी'],
    ['Sapta Mukhi','Seven faces','सप्तमुखी'],
    ['Ashta Mukhi','Eight faces','अष्टमुखी'],
    ['Nava Mukhi','Nine faces','नवमुखी'],
    ['Dasha Mukhi','Ten faces','दशमुखी'],
    ['Ekadasha Mukhi','Eleven faces','एकादशमुखी'],
    ['Dwadasha Mukhi','Twelve faces','द्वादशमुखी'],
    ['Trayodasha Mukhi','Thirteen faces','त्रयोदशमुखी'],
    ['Chaturdasha Mukhi','Fourteen faces','चतुर्दशमुखी'],
    ['Pancha Dasha Mukhi','Fifteen faces','पंद्रह मुखी'],
    ['Shodasha Mukhi','Sixteen faces','षोडशमुखी'],
    ['Sapta Dasha Mukhi','Seventeen faces','सत्रह मुखी'],
    ['Ashta Dasha Mukhi','Eighteen faces','अठारह मुखी'],
    ['Ekonavimshati Mukhi','Nineteen faces','उन्नीस मुखी'],
    ['Vimshati Mukhi','Twenty faces','बीस मुखी'],
    ['Ekavimshati Mukhi','Twenty-one faces','इक्कीस मुखी']
  ];
  const forms = [
    {id:'gauri-shankar', name:'Gauri Shankar', local:'Gowri Shankar', aliases:['gaurishankar','gowrishankar','gauri sankar','गौरी शंकर'], subtitle:'Two forms, naturally together.', description:'A concept of two Rudraksha seed lobes joined as one specimen. Explore the distinctive double form, its devotional context and the character of an actual piece.', detail:'Double joined form'},
    {id:'ganesh', name:'Ganesh', local:'Ganesha Rudraksha', aliases:['ganesha','ganapati','ganpati','गणेश'], subtitle:'A singular expression of nature.', description:'A Rudraksha concept with a trunk-like natural projection, the characteristic behind the name Ganesh. Every formation is individual; ask to view the contours of the actual bead.', detail:'Natural projection'},
    {id:'garbh-gauri', name:'Garbh Gauri', local:'Garbha Gauri', aliases:['garbha gauri','garbhgauri','गर्भ गौरी'], subtitle:'A small form, held by a larger one.', description:'A concept of a larger Rudraksha lobe naturally joined to a distinctly smaller lobe. Explore this unequal double form through photographs and the details of the actual specimen.', detail:'Unequal joined form'},
    {id:'trijuti', name:'Trijuti', local:'Tribhangi · Three joined forms', aliases:['tribhangi','trijuthi','three joined','brahma vishnu mahesh','त्रिजुटी'], subtitle:'Three forms. One natural composition.', description:'A concept of three Rudraksha seed lobes joined as one formation. Envisioned as a distinctive devotional object, with the actual joins, condition and specifications reviewed personally.', detail:'Triple joined form'}
  ];
  const tradition = 'Rudraksha is part of Shaiva devotional practice. Request all-around photographs, inspection of the natural lines or joins, dimensions, condition and any available identification report. Origin and classification are confirmed on the actual specimen.';
  const products = [];
  for (let mukhi = 1; mukhi <= 21; mukhi++) {
    for (const origin of origins) {
      const [local, faces, hindi] = names[mukhi - 1];
      products.push({
        id:`${origin.id}-${mukhi}-mukhi`,
        name:`${mukhi} Mukhi · ${origin.label}`,
        vernacular:`${local} · ${faces}`,
        category:'rudraksha', categoryLabel:`${origin.place.toUpperCase()} · RUDRAKSHA`,
        tag:`${mukhi} MUKHI`, series:'mukhi-rudraksha',
        origin:origin.id, originLabel:origin.label, mukhi, form:'bead',
        counterpartId:`${origin.id === 'nepali' ? 'java' : 'nepali'}-${mukhi}-mukhi`,
        aliases:['rudraksha','rudraksh','rudrakasha','rudrakshas','rudrakashas',origin.id === 'java' ? 'indonesian javanese' : 'nepalese',origin.place,local,faces,hindi,`${mukhi} faced`,`${mukhi} face`,`${mukhi} mukhi rudraksha`],
        image:`rudraksha/${origin.id}-${mukhi}-mukhi.webp`,
        subtitle:mukhi === 1 ? 'A considered, individual sourcing inquiry.' : `${faces}. A moment of quiet attention.`,
        description:mukhi === 1
          ? `An inquiry for a one-faced Rudraksha of requested ${origin.label} origin. The physical form, natural divisions and origin need assessment on a specific specimen. Discuss the actual piece and its identification before choosing.`
          : `Explore a ${mukhi} Mukhi Rudraksha selection of requested ${origin.label} origin. ${origin.character} Choose it as a contemplative object or discuss a bead for your personal devotional practice.`,
        details:[faces,`${origin.place} · requested origin`,'Loose-bead concept'],
        tradition
      });
    }
  }
  for (const form of forms) {
    for (const origin of origins) {
      products.push({
        id:`${origin.id}-${form.id}`,
        name:`${form.name} · ${origin.label}`, vernacular:form.local,
        category:'rudraksha', categoryLabel:`${origin.place.toUpperCase()} · RUDRAKSHA`,
        tag:'SPECIAL FORM', series:'special-rudraksha',
        origin:origin.id, originLabel:origin.label, mukhi:null, form:form.id,
        counterpartId:`${origin.id === 'nepali' ? 'java' : 'nepali'}-${form.id}`,
        aliases:['rudraksha','rudraksh','rudrakasha','special',origin.place,...form.aliases],
        image:`rudraksha/${origin.id}-${form.id}.webp`,
        subtitle:form.subtitle, description:`${form.description} This is an inquiry for requested ${origin.label} origin.`,
        details:[form.detail,`${origin.place} · requested origin`,'Individual specimen'],
        tradition
      });
    }
  }
  return products;
})();

;
'use strict';

// Concept collection: actual product specifications and placement are confirmed on inquiry.
window.LUNIC_VASTU = [
  {
    "id": "pyramid",
    "name": "Copper Vastu Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu.webp",
    "subtitle": "A small ritual for the spaces you call home.",
    "description": "An architectural copper pyramid with a square base and a warm, polished surface. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper finish",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper pyramid",
      "tamba",
      "तांबा"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-pyramid",
    "name": "Brass Vastu Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-pyramid.webp",
    "subtitle": "A warm point of focus.",
    "description": "A single square-based brass pyramid with clean edges and a softly brushed golden finish. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Brass-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "peetal pyramid",
      "पीतल"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "quartz-pyramid",
    "name": "Clear Quartz Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/quartz-pyramid.webp",
    "subtitle": "Geometry, held in a little light.",
    "description": "A single transparent clear quartz pyramid, with polished triangular faces, subtle internal veils and a square base. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Clear quartz concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "sphatik pyramid",
      "sphatika",
      "crystal pyramid",
      "स्फटिक"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "amethyst-pyramid",
    "name": "Amethyst Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/amethyst-pyramid.webp",
    "subtitle": "A violet accent for a quiet corner.",
    "description": "A single polished amethyst pyramid with translucent violet colour and natural-looking pale mineral bands. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Amethyst concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "purple pyramid"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "rose-quartz-pyramid",
    "name": "Rose Quartz Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/rose-quartz-pyramid.webp",
    "subtitle": "A softer expression of form.",
    "description": "A single polished pale pink rose quartz pyramid with gently clouded translucency. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Rose quartz concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "pink pyramid"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "nine-pyramid-plate",
    "name": "Nine-Pyramid Copper Plate",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/nine-pyramid-plate.webp",
    "subtitle": "Nine small forms. One composition.",
    "description": "A square copper plate bearing exactly nine small raised copper pyramids arranged in a precise three-by-three grid. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "9 pyramid plate",
      "nine pyramids"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "eightyone-pyramid-plate",
    "name": "81-Pyramid Copper Plate",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/eightyone-pyramid-plate.webp",
    "subtitle": "A finely ordered geometric field.",
    "description": "A square copper plate bearing a regular nine-by-nine grid of eighty-one small raised pyramids. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "81 pyramid plate",
      "eighty one pyramids"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "three-layer-pyramid",
    "name": "Three-Layer Copper Pyramid",
    "category": "vastu",
    "categoryLabel": "PYRAMIDS & GEOMETRY",
    "vastuGroup": "geometry",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/three-layer-pyramid.webp",
    "subtitle": "Layers of considered geometry.",
    "description": "A stepped copper Vastu pyramid made of three nested square tiers with a small pyramidal apex. A geometric focal point for a shelf, desk or meditation corner. Ask about dimensions and a considered placement in your space.",
    "details": [
      "Copper-tone concept",
      "Pyramids & Geometry",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "3 layer pyramid",
      "multilayer pyramid"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "copper-helix",
    "name": "Copper Vastu Helix",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/copper-helix.webp",
    "subtitle": "A simple curve, thoughtfully placed.",
    "description": "A single upright copper helix with three broad smooth coils rising from a small circular metal foot. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Copper-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper coil",
      "tamba helix"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-helix",
    "name": "Brass Vastu Helix",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-helix.webp",
    "subtitle": "A sculptural line in warm brass.",
    "description": "A single upright brass helix with three smooth coils and a small circular metal foot. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Brass-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "brass coil",
      "peetal helix"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "zinc-helix",
    "name": "Zinc Vastu Helix",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/zinc-helix.webp",
    "subtitle": "A cool metallic counterpoint.",
    "description": "A single upright satin silver-grey zinc helix with three smooth coils and a small circular foot. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Zinc-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "zinc coil",
      "silver grey helix"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "copper-vastu-strip",
    "name": "Copper Vastu Strip",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/copper-vastu-strip.webp",
    "subtitle": "A detail to discuss with your space.",
    "description": "A neat coil of narrow flat copper strip with one short gently curved tail revealing the thin rectangular profile. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Copper-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper tape",
      "copper patti",
      "metal strip"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-vastu-strip",
    "name": "Brass Vastu Strip",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-vastu-strip.webp",
    "subtitle": "A warm metallic line.",
    "description": "A neat coil of narrow flat golden brass strip with one short gently curved tail revealing the thin rectangular profile. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Brass-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "brass tape",
      "brass patti",
      "metal strip"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "aluminium-vastu-strip",
    "name": "Aluminium Vastu Strip",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/aluminium-vastu-strip.webp",
    "subtitle": "A restrained silver-toned finish.",
    "description": "A neat coil of narrow flat satin aluminium strip with a short gently curved tail revealing the thin rectangular profile. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Aluminium-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "aluminum strip",
      "aluminium tape",
      "silver metal strip"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "copper-vastu-plate",
    "name": "Copper Vastu Plate",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/copper-vastu-plate.webp",
    "subtitle": "An elemental surface, simply made.",
    "description": "A single thick square copper plate with bevelled edges and a subtly hammered, uninscribed surface, standing at a slight backward lean. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Copper-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "copper sheet",
      "tamba plate"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-vastu-plate",
    "name": "Brass Vastu Plate",
    "category": "vastu",
    "categoryLabel": "METALS & PLACEMENT",
    "vastuGroup": "metals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-vastu-plate.webp",
    "subtitle": "A considered square of warm metal.",
    "description": "A single thick square brass plate with bevelled edges and a softly brushed, uninscribed surface, standing at a slight backward lean. Explore this object as part of a guided Vastu selection. Placement and any fitting requirements are discussed before choosing.",
    "details": [
      "Brass-tone concept",
      "Metals & Placement",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "brass sheet",
      "peetal plate"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-tortoise",
    "name": "Brass Tortoise",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-tortoise.webp",
    "subtitle": "A small sculptural moment.",
    "description": "A single low brass tortoise sculpture with four visible feet, a domed patterned shell and a gently extended head. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "turtle",
      "kachhua",
      "कछुआ"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "crystal-tortoise",
    "name": "Crystal Tortoise",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/crystal-tortoise.webp",
    "subtitle": "A familiar form, full of light.",
    "description": "A single clear quartz tortoise carving with a translucent domed shell, four feet and a gently extended head. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Clear quartz concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "crystal turtle",
      "sphatik tortoise",
      "kachhua"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "kamadhenu",
    "name": "Kamadhenu Cow & Calf",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/kamadhenu.webp",
    "subtitle": "A tender composition for a sacred corner.",
    "description": "One brass sculpture group of a standing Indian cow and a small calf nuzzling beside her, both on a single low oval brass base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "kamdhenu",
      "cow calf",
      "gaumata",
      "कामधेनु"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "elephant-pair",
    "name": "Brass Elephant Pair",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/elephant-pair.webp",
    "subtitle": "Two forms, in quiet company.",
    "description": "A matching pair of small Indian brass elephant sculptures with gently raised trunks, standing side by side. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "hathi",
      "elephants",
      "हाथी"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "sun-plaque",
    "name": "Brass Surya Plaque",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/sun-plaque.webp",
    "subtitle": "A little solar warmth for your space.",
    "description": "A circular brass wall plaque of a serene traditional Indian sun face surrounded by a symmetrical ring of gently curling rays, standing against a discreet support. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "sun face",
      "surya",
      "सूर्य"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "om-symbol",
    "name": "Brass Om Symbol",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/om-symbol.webp",
    "subtitle": "A familiar symbol, thoughtfully displayed.",
    "description": "A single freestanding traditional Devanagari Om symbol, ॐ, cast in warm brass on a minimal narrow rectangular base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "aum",
      "omkar",
      "ॐ"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "swastik-symbol",
    "name": "Brass Swastik Symbol",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/swastik-symbol.webp",
    "subtitle": "An auspicious form for a considered entrance.",
    "description": "A traditional Hindu brass puja plaque with an upright sacred swastik, four small dots and a circular lotus-petal border. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "swastika",
      "svastika",
      "स्वस्तिक"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "running-horse",
    "name": "Brass Running Horse",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/running-horse.webp",
    "subtitle": "Movement, captured in a sculptural line.",
    "description": "A single graceful brass horse sculpture in a running pose with flowing mane and tail, supported on a low integral oval base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "horse",
      "ghoda",
      "अश्व"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-camel",
    "name": "Brass Camel",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-camel.webp",
    "subtitle": "A distinctive silhouette in warm brass.",
    "description": "A single elegant brass one-humped camel sculpture standing on four legs with a slender curved neck and simple understated surface detail. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "camel",
      "oont",
      "ऊंट"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-deer",
    "name": "Brass Deer",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-deer.webp",
    "subtitle": "A light-footed sculptural accent.",
    "description": "A single graceful brass deer sculpture with a slender neck, small branching antlers and four legs on a discreet low base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "deer",
      "hiran",
      "हिरण"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "rabbit-pair",
    "name": "Brass Rabbit Pair",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/rabbit-pair.webp",
    "subtitle": "A gentle pair for a personal corner.",
    "description": "A matching pair of small seated brass rabbit sculptures with long upright ears and softly rounded bodies. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "rabbits",
      "hare",
      "khargosh",
      "खरगोश"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-eagle",
    "name": "Brass Eagle",
    "category": "vastu",
    "categoryLabel": "SYMBOLS & SCULPTURE",
    "vastuGroup": "symbols",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/brass-eagle.webp",
    "subtitle": "A sculptural study in wings and form.",
    "description": "A single brass eagle sculpture with wings partly spread, perched on a low sculpted rock-like brass base. A sculptural accent for a home, entrance or workspace. Discuss the intended setting and the actual object’s proportions.",
    "details": [
      "Brass-tone concept",
      "Symbols & Sculpture",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "eagle",
      "bird",
      "garuda"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "quartz-sphere",
    "name": "Clear Quartz Sphere",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/quartz-sphere.webp",
    "subtitle": "A quiet orbit of reflected light.",
    "description": "A single polished transparent clear quartz sphere with fine natural-looking internal veils, resting in a discreet low brass ring cradle. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Clear quartz concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "sphatik ball",
      "crystal ball",
      "quartz ball"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "rose-quartz-tree",
    "name": "Rose Quartz Tree",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/rose-quartz-tree.webp",
    "subtitle": "A small tree in the softest pink.",
    "description": "A small decorative tree of delicate copper wire branches bearing pale pink rose quartz chip leaves, rooted in a low rough dark stone base. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Rose quartz concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "pink crystal tree",
      "rose quartz bonsai"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "citrine-tree",
    "name": "Citrine Crystal Tree",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/citrine-tree.webp",
    "subtitle": "A warm little canopy of colour.",
    "description": "A small decorative tree of copper wire branches bearing translucent honey-yellow citrine chip leaves, rooted in a low rough dark stone base. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Citrine concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "yellow crystal tree",
      "citrine bonsai"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "seven-stone-tree",
    "name": "Seven-Stone Crystal Tree",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/seven-stone-tree.webp",
    "subtitle": "A little colour for your everyday.",
    "description": "A small decorative copper wire tree with seven distinct clusters of crystal chip leaves in violet, indigo, blue, green, yellow, orange and red, on a low rough stone base. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Mixed-stone concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "seven chakra tree",
      "7 stone tree",
      "rainbow tree"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "quartz-point",
    "name": "Clear Quartz Point",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/quartz-point.webp",
    "subtitle": "A natural-looking point of focus.",
    "description": "A single upright clear quartz point with six prismatic sides and a naturally formed pointed termination, showing subtle translucent internal veils. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Clear quartz concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "crystal pencil",
      "sphatik point",
      "quartz tower"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "black-tourmaline",
    "name": "Black Tourmaline Cluster",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/black-tourmaline.webp",
    "subtitle": "A dark, tactile mineral accent.",
    "description": "A single compact cluster of intergrown jet-black tourmaline prismatic crystals with realistic vertical striations and slightly uneven terminations. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Black tourmaline concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "schorl",
      "black crystal",
      "tourmaline"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "salt-lamp",
    "name": "Rock Salt Lamp",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/salt-lamp.webp",
    "subtitle": "A small pool of amber light.",
    "description": "An irregular pink-orange rock salt lamp glowing softly from within, mounted on a low round dark wooden foot, with the electrical cable discreetly out of view. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Rock-salt concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "himalayan salt lamp",
      "pink salt light"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "salt-bowl",
    "name": "Rock Salt Bowl",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/salt-bowl.webp",
    "subtitle": "A tactile accent in warm mineral tones.",
    "description": "A single shallow carved pink-orange rock salt bowl holding a small handful of matching rough salt chunks as one product set. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Rock-salt concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "salt energizer",
      "salt bowl",
      "sendha namak",
      "सेंधा नमक"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "tabletop-fountain",
    "name": "Tabletop Water Fountain",
    "category": "vastu",
    "categoryLabel": "CRYSTALS & SALT",
    "vastuGroup": "crystals",
    "tag": "OBJECTS FOR YOUR SPACE",
    "series": "vastu-collection",
    "image": "vastu/tabletop-fountain.webp",
    "subtitle": "A little movement for a considered corner.",
    "description": "A compact tabletop fountain made of three small staggered copper bowls on a dark charcoal stone structure above an integrated round basin, with a thin gentle stream of water linking the bowls. A tactile accent for a reflective corner. Actual colour, natural variations and specifications are confirmed on inquiry.",
    "details": [
      "Stone & copper concept",
      "Crystals & Salt",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "water feature",
      "indoor fountain",
      "waterfall"
    ],
    "tradition": "For placement guidance, share your room layout, intended location and the object’s purpose. The actual material, dimensions, finish and availability are confirmed personally."
  },
  {
    "id": "brass-diya",
    "name": "Brass Diya",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/brass-diya.webp",
    "subtitle": "A small vessel for a daily ritual.",
    "description": "A single small traditional brass oil lamp with a shallow leaf-shaped oil bowl, one short wick spout and a low pedestal foot, shown unlit. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "deepak",
      "oil lamp",
      "दीया"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "brass-bell",
    "name": "Brass Puja Bell",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/brass-bell.webp",
    "subtitle": "A resonant detail for your sacred space.",
    "description": "A single traditional Indian brass hand bell with a flared rounded skirt, slim turned handle and small simple lotus finial. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "ghanti",
      "hand bell",
      "puja bell",
      "घंटी"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "copper-kalash",
    "name": "Copper Kalash",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/copper-kalash.webp",
    "subtitle": "A warm vessel for a personal altar.",
    "description": "A single traditional empty copper kalash vessel with a rounded belly, narrow neck and flared rim, with subtle hand-hammered texture. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Copper-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "kalasha",
      "lota",
      "water vessel",
      "कलश"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "incense-holder",
    "name": "Brass Incense Holder",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/incense-holder.webp",
    "subtitle": "A considered place for a familiar ritual.",
    "description": "A single slender leaf-shaped brass incense holder with an ash-catching channel and one small incense socket, shown without incense or smoke. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "agarbatti stand",
      "incense tray",
      "अगरबत्ती"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "dhoop-burner",
    "name": "Brass Dhoop Burner",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/dhoop-burner.webp",
    "subtitle": "A sculptural vessel for your ritual corner.",
    "description": "A single small brass dhoop burner with a perforated domed lid, lotus-like lower bowl, three short feet and a tiny finial, shown empty and unlit. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "loban burner",
      "sambrani",
      "dhoop holder",
      "धूप"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "conch-stand",
    "name": "Shankha on Brass Stand",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/conch-stand.webp",
    "subtitle": "A familiar ritual form, gently held.",
    "description": "A single uninscribed ivory-white spiral conch shell with a natural elongated taper and warm cream opening, resting horizontally on a simple low brass cradle stand. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Shell & brass concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "shankh",
      "conch",
      "shankha",
      "शंख"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "wind-chime",
    "name": "Five-Tube Brass Wind Chime",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/wind-chime.webp",
    "subtitle": "A gentle detail for an open corner.",
    "description": "One elegant wind chime with exactly five slender vertical brass tubes suspended from a dark round wooden cap, a small central striker and a slim dark wind sail, hanging from a discreet thin black display stand. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "chime",
      "hanging bells",
      "windchime"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  },
  {
    "id": "brass-urli",
    "name": "Brass Urli Bowl",
    "category": "vastu",
    "categoryLabel": "RITUAL & SOUND",
    "vastuGroup": "ritual",
    "tag": "EVERYDAY RITUAL",
    "series": "vastu-collection",
    "image": "vastu/brass-urli.webp",
    "subtitle": "A simple vessel for a welcoming space.",
    "description": "A single broad shallow circular brass urli bowl with two small curved side handles and a gently hammered surface, shown empty. A considered addition to a personal altar or everyday ritual. Ask about the actual size, materials and intended use.",
    "details": [
      "Brass-tone concept",
      "Ritual & Sound",
      "Personal selection"
    ],
    "aliases": [
      "vastu",
      "vaastu",
      "uruli",
      "urlis",
      "decorative bowl",
      "उरली"
    ],
    "tradition": "Discuss your intended practice and the actual object’s materials, dimensions and care. Availability and final specifications are confirmed personally."
  }
];

;
'use strict';

const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const money = (amount) => `₹${amount.toLocaleString('en-IN')}`;

function productEnquiryUrl(product) {
  const phone = String(window.LUNIC_CONFIG?.whatsappNumber || '').replace(/\D/g,'');
  const message = `Hello Lunic,\n\nI’d like to enquire about ${product.name}.\nPlease share the price, availability and product details.\n\nThank you.`;
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

const consultations = [
  {id:'prashna',name:'Chandra Prashna',subtitle:'One question. A clear intention.',price:1100,duration:'One focused query',moon:'crescent',description:'A specific question explored through the Prashna tradition, with your personal context in mind.',features:['Prashna guidance','One focused question'],intention:'question'},
  {id:'crescent',name:'Crescent',subtitle:'Your first light of clarity',price:2100,duration:'15 minutes',moon:'quarter',description:'An introduction to your birth chart, with a thoughtful look at one area of your life.',features:['15-minute personal reading','One life area, explored'],intention:'direction'},
  {id:'moonrise',name:'Moonrise',subtitle:'A deeper kind of perspective',price:5100,duration:'30 minutes',moon:'gibbous',description:'Connect the patterns in your chart, current dashas and the questions shaping your next chapter.',features:['30-minute in-depth reading','Connected themes & guidance'],intention:'deeper',featured:true},
  {id:'purnima',name:'Purnima',subtitle:'The fullness of your story',price:11000,duration:'45 minutes',moon:'full',description:'Space for the bigger picture. Explore your chart, planetary periods and personal priorities in depth.',features:['45-minute comprehensive reading','Your chart, timing & priorities'],intention:'deeper'},
  {id:'tarot',name:'Lunar Tarot',subtitle:'A little light from the cards',price:3100,duration:'30 minutes',moon:'tarot',description:'A moon-inspired space to explore your questions through Tarot. Reflect on the cards, your present circumstances and the possibilities you’d like to consider.',features:['30-minute personal Tarot reading','Your questions & card symbolism'],intention:'reflection'},
  {id:'reserve',name:'Soma Reserve',subtitle:'Your private lunar consultation',price:21000,duration:'Duration agreed personally',moon:'reserve',description:'Our private Jyotish consultation, shaped around the questions and life themes you want to explore in depth. Scope, duration and appointment are agreed personally before confirmation.',features:['A bespoke private consultation','Personal scope & appointment'],intention:'private',vip:true},
  {id:'chandra-kala',name:'Chandra Kala · Muhurta & Panchanga',subtitle:'The art of choosing when.',price:1100,duration:'Occasion-led consultation',moon:'crescent',description:'Personal Vedic timing guidance for beginnings, buying, selling, moving, travel and ceremonies. Explore dates and time windows in the context of your occasion, location and practical constraints.',features:['Muhurta & Panchanga','Dates, timings & planning'],intention:'timing',separate:true}
];

const originalProducts = [
  {id:'moonstone',name:'Moonstone Sphere',category:'gemstones',categoryLabel:'THE LUNAR COLLECTION',tag:'MOON-INSPIRED',image:'moonstone.webp',subtitle:'A soft reminder to return to yourself.',description:'A milky, luminous moonstone sphere for a reflective corner, a personal altar or a moment of quiet. Its gentle shimmer echoes the changing light of the moon.',details:['Moonstone','Decorative sphere','Personal ritual'],tradition:'Moonstone is often associated with lunar symbolism in contemporary spiritual practice. For chart-specific gemstone guidance, begin with a personal consultation.'},
  {id:'meru',name:'Sri Meru Yantra',category:'yantras',categoryLabel:'SACRED GEOMETRY',tag:'TIMELESS TRADITION',image:'yantra.webp',subtitle:'An invitation to centre your intention.',description:'A three-dimensional interpretation of the Sri Yantra, with ascending geometric tiers and a warm brass finish. A meaningful focal point for meditation and a thoughtfully arranged sacred space.',details:['Brass finish','Sacred geometry','Meditation space'],tradition:'The Sri Yantra is a revered form in the Shakta tradition. Placement and worship practices vary; personal guidance is available on inquiry.'},
  {id:'pearl',name:'Chandra Pearl',category:'gemstones',categoryLabel:'THE CHANDRA EDIT',tag:'LUNAR LUMINOSITY',image:'pearl.webp',subtitle:'Quiet beauty, in its most luminous form.',description:'A luminous pearl, traditionally associated with Chandra in Jyotish. Explore it as a meaningful keepsake or ask about a personal gemstone recommendation before choosing it as an astrological remedy.',details:['Pearl','Chandra symbolism','Personal selection'],tradition:'Pearls have a traditional association with the Moon in Jyotish. Suitability, quality, origin, size and any certification should be discussed and confirmed before purchase.'},
  {id:'pyramid',name:'Copper Vastu Pyramid',category:'vastu',categoryLabel:'SPACE & STILLNESS',tag:'INTENTIONAL SPACES',image:'vastu.webp',subtitle:'A small ritual for the spaces you call home.',description:'An architectural copper pyramid that brings a warm, sculptural accent to a desk, meditation corner or personal altar. Choose it as an intentional object for the space you inhabit.',details:['Copper finish','Vastu-inspired','Home & altar'],tradition:'For placement advice, ask about guidance tailored to your space, its layout and how you intend to use this object.'},
  {id:'amethyst',name:'Amethyst Cluster',category:'gemstones',categoryLabel:'EARTH & INTENTION',tag:'NATURALLY EXPRESSIVE',image:'amethyst.webp',subtitle:'A little stillness, beautifully grounded.',description:'A sculptural cluster of violet crystals for a contemplative corner. Every natural mineral formation is different; inquire to discuss the actual piece, dimensions and availability.',details:['Amethyst','Natural crystal cluster','Decorative object'],tradition:'Amethyst’s violet tones make it a distinctive addition to a reflective corner. Ask about the actual piece and its natural variations.'},
  {id:'chandra-yantra',name:'Chandra Yantra',category:'yantras',categoryLabel:'SACRED GEOMETRY',tag:'A MOMENT FOR CHANDRA',image:'chandra.webp',subtitle:'Make space for your inner moon.',description:'A copper-tone yantra inspired by the traditional symbolism of Chandra. A contemplative object for your sacred space, chosen with attention to its meaning and your own intention.',details:['Copper finish','Lunar symbolism','Personal altar'],tradition:'The preview artwork illustrates the design direction. The final yantra’s geometry, inscriptions, material and any ritual preparation will be confirmed personally before purchase.'}
];


const gemstoneCatalog = window.LUNIC_GEMSTONES || [];
const yantraCatalog = window.LUNIC_YANTRAS || [];
const rudrakshaCatalog = window.LUNIC_RUDRAKSHA || [];
const vastuCatalog = window.LUNIC_VASTU || [];
const catalogIds = new Set([...gemstoneCatalog, ...yantraCatalog, ...rudrakshaCatalog, ...vastuCatalog].map(product => product.id));
const products = [...gemstoneCatalog, ...yantraCatalog, ...rudrakshaCatalog, ...vastuCatalog, ...originalProducts.filter(product => !catalogIds.has(product.id))]
  .map(product => product.id === 'vastu-purusha-yantra' ? {...product, collections:['yantras','vastu'], vastuGroup:'geometry'} : product);

const normalizeSearch = value => String(value).toLocaleLowerCase().replace(/[’']/g, '').replace(/[-–—]/g, ' ').replace(/\s+/g, ' ').trim();
const productById = new Map(products.map(product => [product.id, product]));
const productSearchIndex = new Map(products.map(product => {
  const text = normalizeSearch([product.name, product.vernacular || '', product.planet || '', product.deity || '', product.family || '', product.origin || '', product.vastuGroup || '', product.category, product.series || '', product.subtitle, ...product.details, ...(product.aliases || [])].join(' '));
  return [product.id, {text, words:new Set(text.split(/[^\p{L}\p{N}]+/u))}];
}));
const collectionCounts = Object.fromEntries(['all','navaratna','gemstones','yantras','rudraksha','vastu'].map(category => [category, products.filter(product => productInCollection(product,category)).length]));

const phases = {
  new:{sanskrit:'AMAVASYA',title:'Make room for beginnings.',description:'A quieter sky, a clean page. Write down one intention you’d like to grow, and give yourself permission to begin gently.'},
  waxing:{sanskrit:'SHUKLA PAKSHA',title:'Give your intention a little light.',description:'As the moon grows, choose one small action that supports your intention. Consistency can be a gentle kind of devotion.'},
  full:{sanskrit:'PURNIMA',title:'Pause. Notice what is already full.',description:'Take a moment to reflect on what has grown. Write down three things you’re grateful for, and let yourself receive the good.'},
  waning:{sanskrit:'KRISHNA PAKSHA',title:'There is grace in letting go.',description:'Make a little space. Clear one corner, loosen one expectation, or put down a thought you no longer need to carry.'}
};

const articles = {
  vastu:{category:'A CONSIDERED SPACE',title:'Begin with your space.',body:`<p>A useful placement conversation begins with the room itself: its layout, entrances, natural light and everyday use. Choose objects with a clear idea of where they will sit and what they mean to you.</p><h3>Explore the collection</h3><p>Browse geometry, metal tools, symbolic sculpture, crystals and ritual essentials. Some objects are decorative, some belong to a devotional practice, and others are intended for a guided Vastu selection.</p><h3>Bring a little context</h3><p>For placement guidance, share a simple plan and your intended location. Ask about the actual object’s dimensions, material, finish, fitting and care before choosing.</p><h3>Preview and actual piece</h3><p>Images are for illustration purposes only. Actual products may vary. Availability and final specifications are confirmed personally on inquiry.</p>`,cta:'Explore Vastu objects'},
  rudraksha:{category:'A LIVING TRADITION',title:'A bead. A face. A personal practice.',body:`<p>Rudraksha seeds have a long place in Shaiva devotional practice. They may be chosen as single beads or used in a mala for japa, the repetition of a mantra.</p><h3>What is a mukhi?</h3><p>Mukhi refers to the natural faces or divisions of a bead. The principal grooves run between its poles; a close view of one side alone cannot establish the complete count.</p><h3>Nepali and Java selections</h3><p>Explore both origins in this collection, then ask about the actual specimen’s size, shape, natural lines and supporting identification. The AI previews show a visual direction, rather than proving a bead’s origin or mukhi count.</p><h3>Choose with understanding</h3><p>Discuss your intended practice and practical preferences before choosing a bead or natural joined form.</p><p><a href="https://www.himalayanacademy.com/wp-content/uploads/2025/02/1997-mar-insight-tulsi-and-rudraksha.pdf" target="_blank" rel="noopener noreferrer">Read about the Rudraksha tradition · Himalayan Academy <svg class="inline-icon" aria-hidden="true"><use href="#i-arrow"/></svg></a></p>`,cta:'Explore Rudraksha'},
  moon:{category:'THE LUNAR LIFE',title:'What your Moon sign says about your inner world',body:`<p>In Jyotish, the Moon—Chandra—is traditionally connected with the mind, emotional experience and our sense of comfort. While the Sun is often the starting point in popular astrology, a Vedic reading gives the Moon an important place in the conversation.</p><h3>A more personal starting point</h3><p>Your Moon sign describes the zodiac sign occupied by the Moon at birth. Its nakshatra, or lunar mansion, adds another layer of symbolism. An astrologer reads these alongside the whole chart, rather than treating any single placement as the whole story.</p><h3>It’s a conversation, not a label</h3><p>Two people with the same Moon sign can have very different lives. Planetary relationships, the ascendant, dashas and personal circumstances all matter. The useful question is less “What am I destined to be?” and more “Which patterns do I recognise, and how would I like to respond?”</p><h3>A small reflection</h3><p>Notice the places, people and routines that help you feel at ease. Bring those observations to a reading. Your lived experience gives the symbols a much more meaningful context.</p>`,cta:'Explore your inner orbit'},
  yantra:{category:'SACRED SPACES',title:'More than geometry: the meaning of a yantra',body:`<p>A yantra is a geometric form used in certain Indian spiritual traditions as a focus for contemplation, ritual or devotion. The word can refer to an instrument or support; in practice, the object is part of a wider relationship with attention and intention.</p><h3>Geometry with a purpose</h3><p>Triangles, circles, a central point and surrounding boundaries recur in many yantras. Their arrangement carries meanings within the particular tradition. The Sri Yantra, for example, is a revered form associated with the Shakta tradition.</p><h3>Begin with understanding</h3><p>Before choosing a yantra, ask what it represents, how it is made, and whether the relevant tradition recommends a particular placement or practice. There is no need to build an elaborate ritual before you understand the object’s meaning.</p><h3>A considered corner</h3><p>A clean, quiet place and a few minutes of undistracted attention can be a thoughtful starting point. If you want to follow a specific devotional practice, seek guidance from someone grounded in that tradition.</p>`,cta:'Explore sacred geometry'},
  reading:{category:'YOUR FIRST READING',title:'A little preparation. A more meaningful reading.',body:`<p>A useful consultation begins with your questions. You don’t need to know astrological terminology. A little preparation simply gives your conversation more room to be personal and specific.</p><h3>Bring the details you know</h3><p>For a birth-chart consultation, prepare your birth date, birth time and birthplace. If the time is approximate or unknown, say so. Your astrologer can explain what can and cannot be explored confidently with the information available.</p><h3>Choose what matters now</h3><p>Write down one to three priorities in plain language. A question such as “How can I approach this career transition?” gives a conversation more shape than trying to cover every part of life in a short session.</p><h3>Choose your depth</h3><ul><li>Chandra Prashna: one focused Prashna question or Muhurta inquiry.</li><li>Crescent: 15 minutes for an introduction and one life area.</li><li>Moonrise: 30 minutes to connect a few related themes.</li><li>Purnima: 45 minutes for a wider conversation.</li><li>Lunar Tarot: a 30-minute personal Tarot reading at ₹3,100, with your questions and the symbolism of the cards at its heart.</li><li>Soma Reserve: our VIP private consultation at ₹21,000, with a personally agreed focus, duration and appointment.</li></ul><h3>Leave room for your own judgment</h3><p>Consider a reading as a perspective to reflect on, alongside your experience and practical circumstances. You remain the person making your choices.</p>`,cta:'Find your reading'}
};

let selectedIntention = 'all';
let activeFilter = 'all';
let yantraFamily = 'all';
let vastuFamily = 'all';
let rudrakshaOrigin = 'all';
let rudrakshaMukhi = 'all';
let productSearch = '';
let visibleProductCount = 9;
let inquiryMessage = '';
let inquiryContext = null;
let lastFocusedElement = null;
let toastTimer;
let savedProducts;
try { const stored = JSON.parse(localStorage.getItem('lunic-inquiry-bag') || '[]'); savedProducts = Array.isArray(stored) ? [...new Set(stored.filter(id => productById.has(id)))] : []; }
catch { savedProducts = []; }

const dialog = document.querySelector('#main-dialog');
const dialogContent = document.querySelector('#dialog-content');

function renderConsultations() { window.LunicReadings?.render(); }

function productInCollection(product, category) {
  if (category === 'all') return true;
  if (category === 'navaratna') return product.series === 'navaratna';
  return product.category === category || (product.collections || []).includes(category);
}

function matchesRudrakshaMukhi(product) {
  return rudrakshaMukhi === 'all' || (rudrakshaMukhi === 'special' ? product.series === 'special-rudraksha' : product.mukhi === Number(rudrakshaMukhi));
}

function resetProductFacets() {
  yantraFamily = 'all';
  vastuFamily = 'all';
  rudrakshaOrigin = 'all';
  rudrakshaMukhi = 'all';
  document.querySelector('#rudraksha-mukhi').value = 'all';
  document.querySelectorAll('[data-yantra-family],[data-rudraksha-origin],[data-vastu-family]').forEach(button => {
    const selected = (button.dataset.yantraFamily || button.dataset.rudrakshaOrigin || button.dataset.vastuFamily) === 'all';
    button.classList.toggle('active',selected);
    button.setAttribute('aria-pressed',String(selected));
  });
}

function renderProducts(withMotion = true, append = false) {
  const query = normalizeSearch(productSearch);
  const terms = query.split(' ').filter(Boolean);
  const matched = products.filter(product => {
    const inCategory = productInCollection(product, activeFilter);
    const inFamily = activeFilter !== 'yantras' || yantraFamily === 'all' || product.family === yantraFamily;
    const inOrigin = activeFilter !== 'rudraksha' || rudrakshaOrigin === 'all' || product.origin === rudrakshaOrigin;
    const inMukhi = activeFilter !== 'rudraksha' || matchesRudrakshaMukhi(product);
    const {text, words} = productSearchIndex.get(product.id);
    const inSearch = terms.every(term => /^\d+$/.test(term) ? words.has(term) : text.includes(term));
    const inVastuGroup = activeFilter !== 'vastu' || vastuFamily === 'all' || product.vastuGroup === vastuFamily;
    return inCategory && inFamily && inOrigin && inMukhi && inVastuGroup && inSearch;
  });
  if (activeFilter === 'vastu' && vastuFamily === 'all') {
    const highlights = ['pyramid','brass-tortoise','salt-lamp','copper-helix','brass-diya','tabletop-fountain','kamadhenu','quartz-pyramid','wind-chime'];
    const rank = product => { const index = highlights.indexOf(product.id); return index < 0 ? 999 : index; };
    matched.sort((a,b) => rank(a) - rank(b));
  }
  const visible = matched.slice(0, visibleProductCount);
  const grid = document.querySelector('#product-grid');
  const existing = [...grid.querySelectorAll('.product-card')];
  const start = append && existing.every((card,index) => card.dataset.productKey === visible[index]?.id) ? existing.length : 0;
  const cards = visible.slice(start).map(product => `<article class="product-card" data-product-key="${product.id}">
    <div class="product-image">
      <button data-product="${product.id}" aria-label="View ${product.name}"><img src="./assets/${product.image}" alt="AI concept image of ${product.name}" loading="lazy" decoding="async" width="900" height="900"><span class="product-look" aria-hidden="true">Explore object <svg class="inline-icon" aria-hidden="true"><use href="#i-arrow"/></svg></span></button>
      <span class="product-tag">${product.tag}</span>
      <button class="save-product${savedProducts.includes(product.id) ? ' saved' : ''}" data-save="${product.id}" aria-label="${savedProducts.includes(product.id) ? 'Remove' : 'Add'} ${product.name} ${savedProducts.includes(product.id) ? 'from' : 'to'} inquiry bag" aria-pressed="${savedProducts.includes(product.id)}">${icon(savedProducts.includes(product.id) ? 'check' : 'plus')}</button>
    </div>
    <p class="product-image-note">Illustrative image · Actual product may vary</p>
    <div class="product-info"><span class="product-category">${product.categoryLabel}</span>
      <div class="product-title-row"><button data-product="${product.id}"><h3>${product.name}</h3>${product.vernacular ? `<span class="product-local-name">${product.vernacular}</span>` : ''}</button><button class="product-open" data-product="${product.id}" aria-label="View ${product.name} details">${icon('arrow')}</button></div>
      <p class="product-subtitle">${product.subtitle}</p>
      <div class="product-inquiry"><span>Price on inquiry</span><a href="${escapeHtml(productEnquiryUrl(product))}" target="_blank" rel="noopener noreferrer" data-whatsapp-product="${product.id}" aria-label="Enquire about ${escapeHtml(product.name)} on WhatsApp (opens in a new tab)">${icon('whatsapp')}<span>Enquire on WhatsApp</span></a></div>
    </div>
  </article>`).join('');
  if (start) grid.insertAdjacentHTML('beforeend',cards);
  else grid.innerHTML = cards;
  if (!matched.length) document.querySelector('#product-grid').innerHTML = '<div class="collection-empty"><span aria-hidden="true">✧</span><h3>A different kind of search.</h3><p>No objects match those words. Try a gemstone, yantra, Rudraksha, mukhi number or traditional name.</p><button class="text-link" data-action="reset-collection">Explore all essentials <svg class="inline-icon" aria-hidden="true"><use href="#i-arrow"/></svg></button></div>';
  if (withMotion) window.LunicExperience?.animateGrid(grid,start);
  document.querySelector('.collection-count').textContent = `${matched.length} object${matched.length === 1 ? '' : 's'}, infinite intention`;
  document.querySelector('#collection-announcement').textContent = `Showing ${visible.length} of ${matched.length} object${matched.length === 1 ? '' : 's'}${query ? ` for ${productSearch.trim()}` : ''}.`;
  const remaining = matched.length - visible.length;
  const pagination = document.querySelector('#collection-pagination');
  pagination.hidden = matched.length === 0;
  document.querySelector('#collection-page-summary').textContent = `Showing ${visible.length} of ${matched.length} object${matched.length === 1 ? '' : 's'}`;
  const more = document.querySelector('[data-action="load-more-products"]');
  more.hidden = remaining <= 0;
  more.innerHTML = `Show ${Math.min(9, remaining)} more ${activeFilter === 'gemstones' || activeFilter === 'navaratna' ? 'gemstones' : activeFilter === 'yantras' ? 'yantras' : activeFilter === 'rudraksha' ? 'rudraksha' : activeFilter === 'vastu' ? (remaining === 1 ? 'Vastu object' : 'Vastu objects') : 'essentials'} ${icon('plus')}`;
  document.querySelectorAll('[data-filter-count]').forEach(label => {
    const category = label.dataset.filterCount;
    const count = collectionCounts[category];
    label.textContent = String(count).padStart(2, '0');
  });
  document.querySelector('.gemstone-intro').hidden = ['yantras','rudraksha','vastu'].includes(activeFilter);
  document.querySelector('.yantra-intro').hidden = activeFilter !== 'yantras';
  document.querySelector('.yantra-families').hidden = activeFilter !== 'yantras';
  document.querySelectorAll('[data-yantra-count]').forEach(label => {
    label.textContent = yantraCatalog.filter(product => label.dataset.yantraCount === 'all' || product.family === label.dataset.yantraCount).length;
  });
  document.querySelector('.rudraksha-intro').hidden = activeFilter !== 'rudraksha';
  document.querySelector('#rudraksha-filters').hidden = activeFilter !== 'rudraksha';
  document.querySelectorAll('[data-rudraksha-total]').forEach(label => { label.textContent = rudrakshaCatalog.length; });
  document.querySelectorAll('[data-rudraksha-count]').forEach(label => {
    label.textContent = rudrakshaCatalog.filter(product => matchesRudrakshaMukhi(product) && (label.dataset.rudrakshaCount === 'all' || product.origin === label.dataset.rudrakshaCount)).length;
  });
  document.querySelector('.vastu-intro').hidden = activeFilter !== 'vastu';
  document.querySelector('.vastu-families').hidden = activeFilter !== 'vastu';
  document.querySelectorAll('[data-vastu-count]').forEach(label => {
    label.textContent = products.filter(product => productInCollection(product,'vastu') && (label.dataset.vastuCount === 'all' || product.vastuGroup === label.dataset.vastuCount)).length;
  });
  document.querySelector('[data-gemstone-total]').textContent = products.filter(product => product.category === 'gemstones').length;
}

function updateBag() {
  const count = document.querySelector('.bag-count');
  count.textContent = savedProducts.length;
  count.hidden = !savedProducts.length;
  document.querySelector('.bag-button').setAttribute('aria-label', `Open inquiry bag, ${savedProducts.length} object${savedProducts.length === 1 ? '' : 's'}`);
  try { localStorage.setItem('lunic-inquiry-bag', JSON.stringify(savedProducts)); } catch { /* The bag still works when browser storage is unavailable. */ }
}

function toggleProduct(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;
  const index = savedProducts.indexOf(id);
  if (index >= 0) { savedProducts.splice(index,1); toast(`${product.name} removed from your inquiry bag.`); }
  else { savedProducts.push(id); toast(`${product.name} added to your inquiry bag.`); }
  updateBag();
  // Preserve the grid, decoded images and keyboard focus when one object changes.
  const saved = savedProducts.includes(id);
  document.querySelectorAll(`[data-save="${id}"]`).forEach(button => {
    button.classList.toggle('saved', saved);
    button.setAttribute('aria-pressed', String(saved));
    button.setAttribute('aria-label', `${saved ? 'Remove' : 'Add'} ${product.name} ${saved ? 'from' : 'to'} inquiry bag`);
    button.innerHTML = icon(saved ? 'check' : 'plus');
  });
}

function openDialog(html, label) {
  window.LunicBirth?.detach();
  if (!dialog.open) lastFocusedElement = document.activeElement;
  dialogContent.innerHTML = html;
  window.LunicExperience?.animateDialog();
  dialog.setAttribute('aria-label', label);
  if (!dialog.open) dialog.showModal();
  document.body.classList.add('dialog-open');
  dialog.scrollTop = 0;
  const heading = dialogContent.querySelector('h2');
  if (heading) {
    heading.id = 'dialog-title';
    heading.tabIndex = -1;
    dialog.setAttribute('aria-labelledby', 'dialog-title');
    heading.focus({preventScroll:true});
  }
}

function closeDialog() { dialog.close(); }
dialog.addEventListener('close', () => { document.body.classList.remove('dialog-open'); lastFocusedElement?.focus({preventScroll:true}); });
document.querySelector('.dialog-close').addEventListener('click', closeDialog);
dialog.addEventListener('click', event => { if(event.target === dialog) { const rect = dialog.getBoundingClientRect(); if(event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDialog(); } });

function showProduct(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;
  const saved = savedProducts.includes(id);
  const originChoices = product.category === 'rudraksha'
    ? '<div class="rudraksha-origin-switch" role="group" aria-label="Choose Rudraksha origin">' + [product, products.find(item => item.id === product.counterpartId)].filter(Boolean).sort((a,b) => (a.origin === 'nepali' ? -1 : 1) - (b.origin === 'nepali' ? -1 : 1)).map(item => `<button data-product="${item.id}" class="${item.id === id ? 'active' : ''}" aria-pressed="${item.id === id}">${item.originLabel === 'Java' ? 'Java · Indonesia' : 'Nepali · Nepal'}</button>`).join('') + '</div>'
    : '';
  openDialog(`<div class="dialog-product${product.category === 'yantras' ? ' yantra-detail' : product.category === 'rudraksha' ? ' rudraksha-detail' : product.category === 'vastu' ? ' vastu-detail' : ''}"><div class="product-image-stage"><img class="dialog-product-image" src="./assets/${product.image}" alt="AI concept image of ${product.name}"><button class="product-zoom" data-action="zoom-product" aria-label="Zoom in on ${product.name}" aria-pressed="false">${icon('zoom')}<span>Look closer</span></button></div><div class="dialog-product-copy"><div class="dialog-eyebrow">${product.categoryLabel}</div><h2>${product.name}</h2><p class="dialog-illustration-note">Images are for illustration purposes only. Actual products may vary.</p>${product.vernacular ? `<p class="dialog-gem-name">${product.vernacular}${product.series === 'navaratna' ? ' · Navaratna' : ''}</p>` : ''}${originChoices}<p class="dialog-description">${product.description}</p><div class="detail-chips">${product.details.map(detail => `<span>${detail}</span>`).join('')}</div><p class="dialog-small">${product.tradition}</p><a class="button" href="${escapeHtml(productEnquiryUrl(product))}" target="_blank" rel="noopener noreferrer" data-whatsapp-product="${id}" aria-label="Enquire about ${escapeHtml(product.name)} on WhatsApp (opens in a new tab)">${icon('whatsapp')}<span>Enquire on WhatsApp</span></a><button class="button secondary-button" data-dialog-save="${id}">${saved ? 'Remove from inquiry bag' : 'Add to inquiry bag'} ${icon(saved ? 'check' : 'plus')}</button><p class="dialog-small">Materials, availability and pricing are confirmed before purchase.</p></div></div>`,product.name);
}

function localDate() { const now = new Date(); return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`; }

function showInquiry(context) {
  inquiryContext = context;
  const plan = context.plan ? consultations.find(p => p.id === context.plan) : null;
  const product = context.product ? products.find(p => p.id === context.product) : null;
  const isBag = context.type === 'bag';
  const isReserve = Boolean(plan?.vip);
  const isTiming = plan?.id === 'chandra-kala';
  const title = isTiming ? 'Let’s find your moment.' : isReserve ? 'Your private orbit.' : plan ? 'A little closer to clarity.' : product ? `A moment for ${product.name.toLowerCase()}.` : isBag ? 'Your little collection of intention.' : context.type === 'remedy' ? 'Find your personal starting point.' : 'Let’s start a conversation.';
  const description = isTiming ? 'Begin your Chandra Kala enquiry. Tell us what you’re planning, where it will happen and the dates you can consider. We’ll confirm the consultation details personally.' : isReserve ? 'Begin your Soma Reserve enquiry. Share the questions that deserve your fullest attention. We’ll agree the focus, duration and appointment personally before you confirm.' : plan ? `Prepare your ${plan.name} inquiry. We’ll confirm availability and the details personally before your consultation.` : product ? 'Ask about this object, its availability, materials or personal suitability. Final details and pricing are confirmed on inquiry.' : isBag ? 'Ask about your selected objects in one message. Availability and prices will be confirmed personally.' : 'Tell us what you’re curious about. We’ll help you find a reading or sacred object that feels relevant to you.';
  const summary = plan ? `<div class="inquiry-summary"><span>${plan.name} · ${plan.duration}</span><strong>${money(plan.price)}</strong></div>` : product ? `<div class="inquiry-summary"><span>${product.name}</span><span>Price on inquiry</span></div>` : isBag ? `<div class="inquiry-summary"><span>${savedProducts.map(id => products.find(p => p.id === id)?.name).join(' · ')}</span><span>${savedProducts.length} object${savedProducts.length === 1 ? '' : 's'}</span></div>` : '';
  openDialog(`<div class="dialog-content-padded${isReserve ? ' reserve-inquiry' : ''}"><div class="dialog-eyebrow">${isTiming ? 'CHANDRA KALA / THE ART OF WHEN' : isReserve ? 'SOMA RESERVE / PRIVATE CLIENT' : plan ? 'YOUR PERSONAL READING' : 'A PERSONAL INQUIRY'}</div><h2>${title}</h2><p class="dialog-description">${description}</p>${summary}<form class="inquiry-form" id="inquiry-form"><div class="field"><label for="inquiry-name">Your name *</label><input id="inquiry-name" name="name" autocomplete="name" placeholder="What should we call you?" maxlength="80" required></div><div class="field"><label for="inquiry-email">Email <span>(optional)</span></label><input id="inquiry-email" name="email" type="email" autocomplete="email" placeholder="you@example.com" maxlength="150"></div>${isTiming ? window.LunicTiming?.fields(context.occasion) || '' : ''}${window.LunicBirth?.fields({required:['crescent','moonrise','purnima','reserve'].includes(plan?.id),today:localDate()}) || ''}${plan ? `<div class="field"><label for="inquiry-date">${isTiming ? 'Preferred consultation date' : 'Preferred date'} <span>(optional)</span></label><input id="inquiry-date" name="date" type="date" min="${localDate()}"></div><div class="field"><label for="inquiry-time">${isTiming ? 'Consultation time window' : 'Preferred time window'} · IST</label><select id="inquiry-time" name="time"><option value="Flexible">I’m flexible</option><option>Morning · 9 am–12 pm</option><option>Afternoon · 12–4 pm</option><option>Evening · 4–7 pm</option></select></div>` : ''}<div class="field full-width"><label for="inquiry-message">${isTiming ? 'Anything else about your occasion?' : isReserve ? 'What deserves our fullest attention?' : plan ? 'What would you like to explore?' : 'Your question or message'} <span>(optional)</span></label><textarea id="inquiry-message" name="message" maxlength="2000" placeholder="A question, a new chapter, or something you’d like a little clarity on…">${escapeHtml(context.message || '')}</textarea></div><p class="form-note">${plan ? 'Preferred times are requests, not confirmed slots. No payment is taken here. ' : ''}This prepares a message to review, then open in WhatsApp, copy or save. Your inquiry is not sent automatically.</p><button type="submit" class="button">${isTiming ? 'Prepare my timing enquiry' : isReserve ? 'Prepare my private enquiry' : 'Prepare my inquiry'} ${icon('arrow')}</button></form></div>`,plan ? `Inquire about ${plan.name}` : 'Prepare your inquiry');
  window.LunicBirth?.attach(document.querySelector('#inquiry-form'));
}

function prepareInquiry(form) {
  const fields = new FormData(form);
  const plan = inquiryContext.plan ? consultations.find(p => p.id === inquiryContext.plan) : null;
  const product = inquiryContext.product ? products.find(p => p.id === inquiryContext.product) : null;
  const lines = ['Hello Lunic,', '', `My name is ${fields.get('name').trim()}.`];
  if (plan) { lines.push(`I’d like to inquire about the ${plan.name}${plan.vip ? ' VIP' : ''} consultation (${money(plan.price)}, ${plan.duration}).`); if(fields.get('focus')) lines.push(`Focus: ${fields.get('focus')}`); }
  else if(product) lines.push(`I’m interested in the ${product.name}. Please share availability, materials, dimensions and pricing.`);
  else if(inquiryContext.type === 'bag') { lines.push('I’m interested in the following objects:'); savedProducts.forEach(id => lines.push(`• ${products.find(p => p.id === id).name}`)); lines.push('Please share availability and pricing.'); }
  else if(inquiryContext.type === 'remedy') lines.push('I’d like some personal guidance on choosing a consultation or sacred object.');
  else lines.push('I’d love to know more about Lunic.');
  if (plan?.id === 'chandra-kala') window.LunicTiming?.appendToMessage(fields,lines);
  if (fields.get('email')?.trim()) lines.push(`Email: ${fields.get('email').trim()}`);
  window.LunicBirth?.appendToMessage(fields,lines);
  if (fields.get('date')) {const [y,m,d] = fields.get('date').split('-');lines.push(`${plan?.id === 'chandra-kala' ? 'Preferred consultation date' : 'Preferred date'}: ${d}/${m}/${y}`);}
  if (fields.get('time')) lines.push(`${plan?.id === 'chandra-kala' ? 'Preferred consultation time' : 'Preferred time'}: ${fields.get('time')} (IST)`);
  if (fields.get('message')?.trim()) lines.push('',fields.get('message').trim());
  lines.push('','Thank you. Please let me know the next steps.');
  inquiryMessage = lines.join('\n');
  const phone = String(window.LUNIC_CONFIG?.whatsappNumber || '').replace(/\D/g,'');
  const whatsappReady = /^\d{10,15}$/.test(phone);
  const phoneLabel = phone.startsWith('91') && phone.length === 12 ? `+91 ${phone.slice(2,7)} ${phone.slice(7)}` : `+${phone}`;
  openDialog(`<div class="dialog-content-padded"><div class="ready-symbol">${icon('check')}</div><div class="dialog-eyebrow">A THOUGHTFUL FIRST STEP</div><h2>Your inquiry is ready.</h2><p class="dialog-description">${whatsappReady ? `Review your message below, then open WhatsApp to send it to Lunic at ${phoneLabel}.` : 'Lunic’s WhatsApp channel is being set up. For now, copy or save your message so it’s ready when we connect.'}</p><pre class="message-preview">${escapeHtml(inquiryMessage)}</pre><div class="inquiry-actions">${whatsappReady ? `<a class="button" href="https://wa.me/${phone}?text=${encodeURIComponent(inquiryMessage)}" target="_blank" rel="noopener noreferrer">${icon('whatsapp')}<span>Open WhatsApp</span></a>` : ''}<button class="button${whatsappReady ? ' secondary-button' : ''}" data-action="copy-inquiry">Copy inquiry ${icon('plus')}</button><button class="button secondary-button" data-action="save-inquiry">Save as a note ${icon('arrow')}</button></div><p class="dialog-small">${plan ? 'This is a booking inquiry. Your appointment and payment will be confirmed personally after you send it.' : 'No message has been sent and no order has been placed.'}</p><button class="text-link" data-action="edit-inquiry">Start a new inquiry <svg class="inline-icon" aria-hidden="true"><use href="#i-arrow"/></svg></button></div>`,'Your inquiry is ready');
}

function showBag() {
  openDialog(`<div class="dialog-content-padded"><div class="dialog-eyebrow">YOUR SACRED SHORTLIST</div><h2>A little collection<br>of intention.</h2>${savedProducts.length ? `<div class="bag-list">${savedProducts.map(id => { const product = products.find(p => p.id === id); return `<div class="bag-item"><img src="./assets/${product.image}" alt="${product.name}"><div><h3>${product.name}</h3><p>Availability & price on inquiry</p></div><button data-bag-remove="${id}" aria-label="Remove ${product.name} from inquiry bag">Remove</button></div>`; }).join('')}</div><p class="bag-total">${savedProducts.length} thoughtfully chosen object${savedProducts.length === 1 ? '' : 's'}. Ask about your whole collection in one personal inquiry.</p><div class="inquiry-actions"><button class="button" data-action="inquire-bag">Inquire about my collection ${icon('arrow')}</button></div><p class="dialog-small">Your shortlist is stored only in this browser. No order or payment is placed here.</p>` : '<p class="empty-bag">Your collection is a clean page. Explore the sacred essentials and use the + button to save an object that speaks to you.</p><a class="button" href="#collection" data-action="browse-collection">Explore the collection '+icon('arrow')+'</a>'}</div>`,'Your inquiry bag');
}

function showArticle(key) {
  const article = articles[key];
  if(!article) return;
  openDialog(`<article class="dialog-content-padded"><div class="dialog-eyebrow">MOON NOTES / ${article.category}</div><h2>${article.title}</h2><div class="article-body">${article.body}<p class="article-footnote">Moon notes are starting points for reflection. Bring your own questions and experiences to the conversation.</p></div><a class="text-link" href="${['yantra','rudraksha','vastu'].includes(key) ? '#collection' : '#consultations'}" data-action="close-and-explore">${article.cta} <svg class="inline-icon" aria-hidden="true"><use href="#i-arrow"/></svg></a></article>`,article.title);
}

function showPolicy(type) {
  const privacy = type === 'privacy';
  openDialog(`<div class="dialog-content-padded"><div class="dialog-eyebrow">A LITTLE TRANSPARENCY</div><h2>${privacy ? 'Your space. Your information.' : 'A note on care & intention.'}</h2><div class="article-body">${privacy ? '<p>This preview does not have a booking backend, payment processor, analytics tracker or mailing list. Inquiry text stays in the current page until you copy it, download it or choose to send it through WhatsApp.</p><h3>Birth details and maps</h3><p>Birth details stay in the current form and are not saved in browser storage. The place names you search are sent to Photon for location suggestions. Date and time of birth are not sent to the search provider. A map preview loads OpenStreetMap only when you request it. Opening Google Maps sends the selected place or map pin to Google. Your birth details are included in the message you choose to share through WhatsApp.</p><h3>Your inquiry bag</h3><p>Only the IDs of products you save are stored in this browser’s local storage. Remove them from the inquiry bag, or clear this site’s browser data, to delete the shortlist.</p><h3>When you use WhatsApp</h3><p>The WhatsApp button will open a prepared message. Sending is your choice, and WhatsApp’s privacy terms apply. Lunic’s full business privacy policy and retention practices will be provided before launch.</p>' : '<p>Lunic is currently a design preview. Consultation names and listed fees are proposed offerings. Moonrise is shown as a 30-minute session for this preview; its final duration can be adjusted.</p><h3>Inquiries, not confirmed purchases</h3><p>No appointment is confirmed, order placed or payment taken on this preview. Availability, consultation arrangements, product specifications, final prices, delivery, cancellation and refund terms will be confirmed before purchase.</p><h3>Objects with context</h3><p>All collection images are AI-created illustrations. Actual gemstones and handcrafted objects will vary. No certification, origin, ritual preparation or treatment status is claimed by these preview images.</p><h3>Your choices remain yours</h3><p>Astrology and spiritual objects are offered for personal reflection and traditional practice. They do not guarantee outcomes or replace appropriate medical, legal or financial advice.</p>'}</div></div>`,privacy ? 'Privacy in this preview' : 'Terms and care');
}

function toast(message) { const element = document.querySelector('.toast'); clearTimeout(toastTimer); element.textContent = message; element.classList.add('visible'); toastTimer = setTimeout(() => element.classList.remove('visible'),3500); }

document.addEventListener('click', async (event) => {
  const target = event.target.closest('button,a');
  if(!target) return;
  if(target.dataset.plan) showInquiry({type:'consultation',plan:target.dataset.plan,message:target.dataset.readingPrompt || '',occasion:target.dataset.timingOccasion || window.LunicTiming?.selected()});
  else if(target.dataset.product) showProduct(target.dataset.product);
  else if(target.dataset.save) toggleProduct(target.dataset.save);
  else if(target.dataset.dialogSave) {toggleProduct(target.dataset.dialogSave);showProduct(target.dataset.dialogSave);}
  else if(target.dataset.bagRemove) {toggleProduct(target.dataset.bagRemove);showBag();}
  else if(target.dataset.article) showArticle(target.dataset.article);
  else if(target.dataset.yantraFamily) {
    yantraFamily = target.dataset.yantraFamily;
    visibleProductCount = 9;
    document.querySelectorAll('[data-yantra-family]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',String(button === target)); });
    renderProducts();
  }
  else if(target.dataset.vastuFamily) {
    vastuFamily = target.dataset.vastuFamily;
    visibleProductCount = 9;
    document.querySelectorAll('[data-vastu-family]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',String(button === target)); });
    renderProducts();
  }
  else if(target.dataset.rudrakshaOrigin) {
    rudrakshaOrigin = target.dataset.rudrakshaOrigin;
    visibleProductCount = 9;
    document.querySelectorAll('[data-rudraksha-origin]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',String(button === target)); });
    renderProducts();
  }
  else if(target.dataset.filter) {
    activeFilter = target.dataset.filter;
    resetProductFacets();
    visibleProductCount = 9;
    document.querySelectorAll('[data-filter]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',button === target); });
    renderProducts();
  }
  else if(target.dataset.intention) {
    selectedIntention = target.dataset.intention;
    document.querySelectorAll('[data-intention]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',button === target); });
    renderConsultations();
  }
  else if(target.dataset.phase) {
    if (window.LunicExperience) { window.LunicExperience.setPhase(target.dataset.phase); return; }
    const phase = phases[target.dataset.phase];
    if(!phase) return;
    document.querySelector('.interactive-moon').dataset.phase = target.dataset.phase;
    document.querySelector('#phase-sanskrit').textContent = phase.sanskrit;
    document.querySelector('#phase-title').textContent = phase.title;
    document.querySelector('#phase-description').textContent = phase.description;
    document.querySelectorAll('button[data-phase]').forEach(button => { button.classList.toggle('active',button === target); button.setAttribute('aria-pressed',button === target); });
  }
  else if(target.dataset.action) {
    switch(target.dataset.action) {
      case 'load-more-products': {
        const previousCount = document.querySelectorAll('.product-card').length;
        visibleProductCount += 9;
        renderProducts(true,true);
        document.querySelectorAll('.product-card')[previousCount]?.querySelector('button[data-product]')?.focus({preventScroll:true});
        break;
      }
      case 'bag': showBag();break;
      case 'contact': showInquiry({type:'contact'});break;
      case 'personal-remedy': showInquiry({type:'remedy'});break;
      case 'inquire-bag': showInquiry({type:'bag'});break;
      case 'privacy': showPolicy('privacy');break;
      case 'terms': showPolicy('terms');break;
      case 'browse-collection':case 'close-and-explore':closeDialog();break;
      case 'edit-inquiry': showInquiry(inquiryContext || {type:'contact'});break;
      case 'copy-inquiry':
        try { await navigator.clipboard.writeText(inquiryMessage);toast('Inquiry copied. A little clarity, ready to share.');target.innerHTML = `Copied ${icon('check')}`; }
        catch { const preview = document.querySelector('.message-preview');const range = document.createRange();range.selectNodeContents(preview);const selection = window.getSelection();selection.removeAllRanges();selection.addRange(range);toast('Select Copy in your browser to copy the highlighted inquiry.'); }
        break;
      case 'save-inquiry': {
        const url = URL.createObjectURL(new Blob([inquiryMessage],{type:'text/plain;charset=utf-8'}));
        const link = document.createElement('a');link.href=url;link.download='my-lunic-inquiry.txt';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Your inquiry has been saved as a note.');break;
      }
    }
  }
});

document.querySelector('#rudraksha-mukhi').addEventListener('change', event => {
  rudrakshaMukhi = event.target.value;
  visibleProductCount = 9;
  renderProducts();
});

document.addEventListener('submit', event => {
  if(event.target.id === 'inquiry-form') { event.preventDefault(); if(event.target.reportValidity()) prepareInquiry(event.target); }
});

const menuButton = document.querySelector('.menu-button');
const mobileNav = document.querySelector('#mobile-nav');
function closeMenu(){mobileNav.hidden=true;menuButton.setAttribute('aria-expanded','false');menuButton.setAttribute('aria-label','Open navigation');menuButton.innerHTML=icon('menu');}
menuButton.addEventListener('click',()=>{const open=menuButton.getAttribute('aria-expanded')==='true';mobileNav.hidden=open;menuButton.setAttribute('aria-expanded',String(!open));menuButton.setAttribute('aria-label',open?'Open navigation':'Close navigation');menuButton.innerHTML=icon(open?'menu':'close');});
mobileNav.addEventListener('click',event=>{if(event.target.closest('a'))closeMenu();});
document.addEventListener('keydown',event=>{if(event.key==='Escape' && menuButton.getAttribute('aria-expanded')==='true'){closeMenu();menuButton.focus();}});
window.matchMedia('(min-width:651px)').addEventListener('change',event=>{if(event.matches)closeMenu();});

const whatsappChat = document.querySelector('#whatsapp-chat');
const whatsappChatNumber = String(window.LUNIC_CONFIG?.whatsappNumber || '').replace(/\D/g,'');
if (/^\d{10,15}$/.test(whatsappChatNumber)) {
  const greeting = 'Hello Lunic, I’d like to know more about your consultations and sacred collection.';
  whatsappChat.href = `https://wa.me/${whatsappChatNumber}?text=${encodeURIComponent(greeting)}`;
  whatsappChat.hidden = false;
}

renderConsultations();renderProducts();updateBag();
document.querySelector('#year').textContent=new Date().getFullYear();

if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce), (max-width:900px), (pointer:coarse)').matches) {
  document.body.classList.add('js-reveals');
  const observer = new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}});},{threshold:.08});
  document.querySelectorAll('.reveal').forEach(element=>observer.observe(element));
}


;
'use strict';

(() => {
  const cache = new Map();
  let active = null;
  const pin = '<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg>';
  const accuracyOptions = '<option value="confirmed">Confirmed</option><option value="estimated">Estimated</option><option value="unknown">Unknown</option>';

  function fields({required = false, today}) {
    const star = required ? ' *' : '';
    return `<fieldset class="birth-details" data-birth-required="${required}">
      <legend>Your birth details <span>${required ? 'For your chart reading' : 'Optional'}</span></legend>
      <p class="birth-intro">Share what you know. Mark each detail as confirmed, estimated or unknown.</p>
      <div class="birth-grid">
        <div class="field"><label for="birth-date">Date of birth<span data-birth-marker="date">${star}</span></label><input id="birth-date" name="birthDate" type="date" autocomplete="bday" max="${today}" ${required ? 'required' : ''}><input id="birth-date-estimate" name="birthDateEstimate" placeholder="e.g. May 1995, or around 1995" maxlength="100" aria-label="Estimated date of birth" hidden disabled><label class="birth-accuracy-label" for="birth-date-accuracy">How certain is the date?</label><select id="birth-date-accuracy" name="birthDateAccuracy" data-birth-accuracy="date">${accuracyOptions}</select></div>
        <div class="field"><label for="birth-time">Time of birth<span data-birth-marker="time">${star}</span></label><input id="birth-time" name="birthTime" type="time" step="60" ${required ? 'required' : ''} aria-describedby="birth-time-hint"><input id="birth-time-estimate" name="birthTimeEstimate" placeholder="e.g. around 8 am, or morning" maxlength="100" aria-label="Estimated time of birth" hidden disabled><label class="birth-accuracy-label" for="birth-time-accuracy">How certain is the time?</label><select id="birth-time-accuracy" name="birthTimeAccuracy" data-birth-accuracy="time">${accuracyOptions}</select><small id="birth-time-hint" class="birth-field-hint">Use the local time at your birthplace.</small></div>
        <div class="field birth-place-field"><label for="birth-place">Place of birth<span data-birth-marker="place">${star}</span></label><div class="birth-place-search"><span class="birth-search-icon">${pin}</span><input id="birth-place" name="birthPlace" type="text" placeholder="Search your birth town or city" autocomplete="off" spellcheck="false" maxlength="200" role="combobox" aria-autocomplete="list" aria-controls="birth-place-options" aria-expanded="false" aria-describedby="birth-place-hint birth-place-status" ${required ? 'required' : ''}><ul id="birth-place-options" class="birth-place-options" role="listbox" aria-label="Matching birthplaces" hidden></ul></div><small id="birth-place-hint" class="birth-field-hint">Choose a suggestion to attach a city map pin, or enter a place manually.</small><p id="birth-place-status" class="birth-place-status" role="status" aria-live="polite"></p><label class="birth-accuracy-label" for="birth-place-accuracy">How certain is the place?</label><select id="birth-place-accuracy" name="birthPlaceAccuracy" data-birth-accuracy="place">${accuracyOptions}</select><input type="hidden" name="birthLatitude"><input type="hidden" name="birthLongitude">
        <div id="birth-location-preview" class="birth-location-preview" hidden><div class="birth-location-label">${pin}<div><strong id="birth-selected-label"></strong><small id="birth-location-note">City / town map pin</small></div></div><div class="birth-map-actions"><button type="button" data-birth-map-preview>Preview map ${icon('plus')}</button><a id="birth-map-link" target="_blank" rel="noopener noreferrer">Open Google Maps ${icon('arrow')}</a></div><div id="birth-map-frame" class="birth-map-frame" hidden></div></div>
        <p class="birth-place-credit">Search by <a href="https://photon.komoot.io/" target="_blank" rel="noopener noreferrer">Photon</a> · Map data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a></p></div>
        <div class="field birth-details-notes"><label for="birth-details-notes">Anything to clarify? <span>(optional)</span></label><textarea id="birth-details-notes" name="birthDetailsNotes" rows="2" maxlength="500" placeholder="For example: the time is a family estimate, or only the birth year is known."></textarea></div>
      </div><p class="birth-privacy-note">Your date and time stay in this form until you choose to share your enquiry. Only the place search is sent to the location service.</p>
    </fieldset>`;
  }

  function detach() {
    if (!active) return;
    clearTimeout(active.timer);
    active.request?.abort();
    active.events.abort();
    active = null;
  }

  function attach(form) {
    detach();
    if (!form?.querySelector('.birth-details')) return;
    const state = {form, events:new AbortController(), timer:null, request:null, sequence:0, options:[], highlighted:-1, selected:null};
    active = state;
    const input = form.querySelector('#birth-place');
    const list = form.querySelector('#birth-place-options');
    const status = form.querySelector('#birth-place-status');
    const preview = form.querySelector('#birth-location-preview');
    const frame = form.querySelector('#birth-map-frame');
    const mapLink = form.querySelector('#birth-map-link');
    const previewButton = form.querySelector('[data-birth-map-preview]');
    const required = form.querySelector('.birth-details').dataset.birthRequired === 'true';
    const listen = (element, name, callback) => element.addEventListener(name, callback, {signal:state.events.signal});
    const setStatus = text => { status.textContent = text; };

    function closeOptions() {
      list.hidden = true;
      input.setAttribute('aria-expanded', 'false');
      input.removeAttribute('aria-activedescendant');
      state.highlighted = -1;
    }

    function clearPin() {
      state.selected = null;
      form.elements.birthLatitude.value = '';
      form.elements.birthLongitude.value = '';
      frame.replaceChildren();
      frame.hidden = true;
      previewButton.hidden = false;
      previewButton.innerHTML = `Preview map ${icon('plus')}`;
    }

    function manualPreview() {
      const value = input.value.trim();
      preview.hidden = !value;
      if (!value) return;
      form.querySelector('#birth-selected-label').textContent = value;
      form.querySelector('#birth-location-note').textContent = 'Place entered manually · Map pin not selected';
      mapLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(value)}`;
      previewButton.hidden = true;
    }

    function choose(index) {
      const place = state.options[index];
      if (!place) return;
      clearTimeout(state.timer);
      state.sequence++;
      state.request?.abort();
      clearPin();
      state.selected = place;
      input.value = place.label;
      form.elements.birthLatitude.value = place.latitude;
      form.elements.birthLongitude.value = place.longitude;
      form.querySelector('#birth-selected-label').textContent = place.label;
      form.querySelector('#birth-location-note').textContent = 'City / town map pin · Check this is your intended place';
      mapLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${place.latitude},${place.longitude}`)}`;
      previewButton.hidden = false;
      preview.hidden = false;
      closeOptions();
      setStatus('Place selected. You can preview the map or open Google Maps.');
      input.focus({preventScroll:true});
    }

    function showOptions(options) {
      state.options = options;
      state.highlighted = -1;
      list.innerHTML = options.map((place,index) => `<li role="presentation"><button type="button" role="option" id="birth-place-option-${index}" data-birth-option="${index}" aria-selected="false" tabindex="-1">${pin}<span><strong>${escapeHtml(place.name)}</strong><small>${escapeHtml(place.context)}</small></span></button></li>`).join('');
      list.hidden = !options.length;
      input.setAttribute('aria-expanded', String(Boolean(options.length)));
      input.removeAttribute('aria-activedescendant');
      setStatus(options.length ? `${options.length} places found. Choose your town or city.` : 'No matching place found. Try adding the state or country, or continue with the place entered manually.');
    }

    async function search() {
      const query = input.value.trim();
      if (query.length < 3 || input.disabled) return;
      const sequence = ++state.sequence;
      state.request?.abort();
      const key = query.toLocaleLowerCase();
      const cached = cache.get(key);
      if (cached && Date.now() - cached.saved < 600000) { showOptions(cached.places); return; }
      const request = new AbortController();
      state.request = request;
      let timedOut = false;
      const timeout = setTimeout(() => { timedOut = true; request.abort(); }, 5000);
      setStatus('Finding places…');
      input.setAttribute('aria-busy','true');
      try {
        const url = new URL(window.LUNIC_CONFIG?.placeSearchUrl || 'https://photon.komoot.io/api/');
        url.search = new URLSearchParams({q:query, limit:'6', lang:'en'}).toString();
        url.searchParams.append('layer','city');
        url.searchParams.append('layer','locality');
        url.searchParams.append('layer','district');
        const response = await fetch(url, {signal:request.signal, credentials:'omit', referrerPolicy:'no-referrer', headers:{Accept:'application/json'}});
        if (!response.ok) throw new Error('Place search unavailable');
        const data = await response.json();
        if (active !== state || sequence !== state.sequence || !form.isConnected) return;
        const places = (data.features || []).map(feature => {
          const p = feature.properties || {};
          const [longitude, latitude] = feature.geometry?.coordinates || [];
          const name = p.name || p.city;
          if (!name || !Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude)>90 || Math.abs(longitude)>180) return null;
          const parts = [...new Set([name,p.state || p.county,p.country].filter(Boolean))];
          return {name, label:parts.join(', '), context:parts.slice(1).join(', '), latitude, longitude};
        }).filter(Boolean).filter((place,index,all) => all.findIndex(item => item.label === place.label) === index).slice(0,6);
        if (cache.size >= 40) cache.delete(cache.keys().next().value);
        cache.set(key,{saved:Date.now(),places});
        showOptions(places);
      } catch (error) {
        if (active !== state || sequence !== state.sequence || (request.signal.aborted && !timedOut)) return;
        closeOptions();
        setStatus('Place search is taking a moment. Enter your town/city manually, or try searching again. You can still continue.');
      } finally {
        clearTimeout(timeout);
        if (active === state && sequence === state.sequence) input.removeAttribute('aria-busy');
      }
    }

    function updateAccuracy(kind) {
      const accuracy = form.querySelector(`#birth-${kind}-accuracy`).value;
      const exact = form.querySelector(`#birth-${kind}`);
      const estimate = form.querySelector(`#birth-${kind}-estimate`);
      const unknown = accuracy === 'unknown';
      const estimated = accuracy === 'estimated';
      const marker = form.querySelector(`[data-birth-marker="${kind}"]`);
      marker.textContent = unknown ? ' · unknown' : estimated ? ' · estimated' : required ? ' *' : '';
      exact.required = required && !unknown && (!estimated || kind === 'place');
      exact.disabled = unknown || (estimated && Boolean(estimate));
      exact.hidden = estimated && Boolean(estimate);
      if (estimate) {
        if (estimated && !estimate.value && exact.value) estimate.value = kind === 'date' ? formatDate(exact.value) : formatTime(exact.value);
        estimate.disabled = !estimated;
        estimate.hidden = !estimated;
        estimate.required = required && estimated;
        marker.closest('label').htmlFor = estimated ? estimate.id : exact.id;
      }
      if (kind === 'place') {
        clearTimeout(state.timer);
        state.sequence++;
        state.request?.abort();
        input.removeAttribute('aria-busy');
        closeOptions();
        if (unknown) { clearPin(); preview.hidden = true; setStatus('Birthplace marked as unknown. You can continue.'); }
        else {
          input.placeholder = estimated ? 'Search the nearest known town or city' : 'Search your birth town or city';
          if (state.selected) {
            preview.hidden = false;
            form.querySelector('#birth-location-note').textContent = estimated ? 'Nearest known place · Birthplace marked as estimated' : 'City / town map pin · Check this is your intended place';
          } else manualPreview();
          setStatus('');
        }
      }
    }

    listen(input,'input',() => {
      clearTimeout(state.timer);
      state.sequence++;
      state.request?.abort();
      input.removeAttribute('aria-busy');
      clearPin();
      closeOptions();
      manualPreview();
      if (input.value.trim().length < 3) { setStatus(input.value ? 'Type at least 3 characters to search.' : ''); return; }
      setStatus('');
      state.timer = setTimeout(search, 280);
    });
    listen(input,'focus',() => { if (!state.selected && input.value.trim().length >= 3) { clearTimeout(state.timer); state.timer = setTimeout(search, 280); } });
    listen(input,'keydown',event => {
      if (event.key === 'Escape' && !list.hidden) { event.preventDefault(); event.stopPropagation(); closeOptions(); return; }
      if (event.key === 'Enter' && !list.hidden) { event.preventDefault(); if (state.highlighted >= 0) choose(state.highlighted); return; }
      if (!['ArrowDown','ArrowUp'].includes(event.key) || !state.options.length || list.hidden) return;
      event.preventDefault();
      state.highlighted = (state.highlighted + (event.key === 'ArrowDown' ? 1 : -1) + state.options.length) % state.options.length;
      list.querySelectorAll('[role="option"]').forEach((option,index) => option.setAttribute('aria-selected',String(index === state.highlighted)));
      const option = list.querySelector(`#birth-place-option-${state.highlighted}`);
      input.setAttribute('aria-activedescendant',option.id);
      option.scrollIntoView({block:'nearest'});
    });
    listen(list,'mousedown',event => event.preventDefault());
    listen(list,'click',event => { const option = event.target.closest('[data-birth-option]'); if (option) choose(Number(option.dataset.birthOption)); });
    listen(form,'focusout',event => { if (event.target === input && !form.querySelector('.birth-place-search').contains(event.relatedTarget)) closeOptions(); });
    form.querySelectorAll('[data-birth-accuracy]').forEach(select => listen(select,'change',() => updateAccuracy(select.dataset.birthAccuracy)));
    listen(previewButton,'click',() => {
      if (!state.selected) return;
      const {latitude:lat,longitude:lon,label} = state.selected;
      const url = new URL('https://www.openstreetmap.org/export/embed.html');
      url.search = new URLSearchParams({bbox:[Math.max(-180,lon-.07),Math.max(-90,lat-.045),Math.min(180,lon+.07),Math.min(90,lat+.045)].join(','),layer:'mapnik',marker:`${lat},${lon}`}).toString();
      const iframe = document.createElement('iframe');
      iframe.title = `Map of ${label}`;
      iframe.loading = 'lazy';
      iframe.referrerPolicy = 'no-referrer';
      iframe.src = url;
      frame.replaceChildren(iframe);
      frame.hidden = false;
      previewButton.hidden = true;
    });
  }

  function formatDate(value) { const [year,month,day] = value.split('-'); return `${day}/${month}/${year}`; }
  function formatTime(value) { const [hours,minutes] = value.split(':'); return `${Number(hours)%12 || 12}:${minutes} ${Number(hours)>=12 ? 'PM' : 'AM'}`; }

  function appendToMessage(data, lines) {
    const labels = {date:'Date of birth',time:'Time of birth',place:'Place of birth'};
    const keys = {date:'Date',time:'Time',place:'Place'};
    const birthLines = [];
    for (const kind of ['date','time','place']) {
      const key = keys[kind];
      const accuracy = data.get(`birth${key}Accuracy`);
      const value = String(data.get(accuracy === 'estimated' && kind !== 'place' ? `birth${key}Estimate` : `birth${key}`) || '').trim();
      if (accuracy === 'unknown') birthLines.push(`${labels[kind]}: Unknown`);
      else if (value) {
        const formatted = accuracy === 'confirmed' && kind === 'date' ? formatDate(value) : accuracy === 'confirmed' && kind === 'time' ? `${formatTime(value)} (local birth time)` : value;
        birthLines.push(`${labels[kind]}: ${formatted} (${accuracy === 'estimated' ? 'Estimated' : 'Confirmed'})`);
      }
    }
    const place = String(data.get('birthPlace') || '').trim();
    if (place && data.get('birthPlaceAccuracy') !== 'unknown') {
      const latitude = data.get('birthLatitude');
      const longitude = data.get('birthLongitude');
      if (latitude && longitude) birthLines.push(`Place map pin: ${latitude}, ${longitude}`);
      const query = latitude && longitude ? `${latitude},${longitude}` : place;
      birthLines.push(`Birthplace map: https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`);
    }
    const notes = String(data.get('birthDetailsNotes') || '').trim();
    if (notes) birthLines.push(`Birth details notes: ${notes}`);
    if (birthLines.length) lines.push('', 'Birth details:', ...birthLines, '');
  }

  window.LunicBirth = {fields, attach, detach, appendToMessage};
  dialog.addEventListener('close',detach);
})();

;
'use strict';

(() => {
  const order = ['prashna', 'crescent', 'moonrise', 'purnima', 'tarot', 'reserve'];
  const stories = {
    prashna: {
      phase: 'The first spark', method: 'Prashna / One question', short: 'One question',
      line: 'One question. A thoughtful place to begin.',
      best: 'A specific question you’d like to explore with personal context.',
      inside: ['A focused conversation around one meaningful question.', 'Explore the Prashna approach with your personal context in mind.'],
      prepare: ['Bring one clear question and the context around it.', 'Share relevant details. We’ll confirm any other information needed.'],
      reflection: 'What would I most like to understand before taking my next step?',
      orbit: 'A single intention. A little more light.'
    },
    crescent: {
      phase: 'The first light', method: 'Jyotish / Birth chart', short: 'A first reading',
      line: 'A little perspective can change how a chapter feels.',
      best: 'Your first birth-chart reading, with room for one area of life.',
      inside: ['Explore one life area through the lens of your birth chart.', 'A 15-minute conversation shaped around your question and personal context.'],
      prepare: ['Have your birth date, birth time and birthplace ready.', 'Choose one priority. Let us know if your birth time is approximate.'],
      reflection: 'Which part of my life would benefit from a fresh perspective?',
      orbit: 'Small beginnings hold their own light.'
    },
    moonrise: {
      phase: 'The unfolding', method: 'Jyotish / Connected themes', short: 'Go a little deeper',
      line: 'Give the questions beneath your questions a little space.',
      best: 'Connecting related life themes and exploring the timing of your current chapter.',
      inside: ['Explore connected chart patterns and current dashas.', 'A 30-minute conversation for the themes shaping your next chapter.'],
      prepare: ['Bring your birth date, birth time and birthplace.', 'Note two or three related themes you’d like to connect.'],
      reflection: 'How do the different parts of my life connect in this chapter?',
      orbit: 'More room for the patterns to emerge.'
    },
    purnima: {
      phase: 'The fuller picture', method: 'Jyotish / In-depth reading', short: 'See the whole',
      line: 'Step back. Make room for the fullness of your story.',
      best: 'A broader look at your chart, planetary periods and personal priorities.',
      inside: ['Explore your birth chart and planetary periods in greater depth.', 'A 45-minute conversation with space for your wider priorities.'],
      prepare: ['Bring your birth date, birth time and birthplace.', 'Write down your main priorities and the context you’d like to share.'],
      reflection: 'What deserves my attention as I look at the bigger picture?',
      orbit: 'Your story, with room to unfold.'
    },
    tarot: {
      phase: 'The inner mirror', method: 'Tarot / Symbolic reflection', short: 'Let the cards speak',
      line: 'A conversation with the cards. A moment with yourself.',
      best: 'Exploring a question through card symbolism and personal reflection.',
      inside: ['A personal, 30-minute Tarot reading centred on your questions.', 'Explore the cards’ symbolism in the context of your present circumstances.'],
      prepare: ['Bring the questions or themes you’d like to explore. Birth details aren’t required.', 'Set aside 30 minutes. Your preferred appointment time is confirmed when you inquire.'],
      reflection: 'What might a different perspective help me notice right now?',
      orbit: 'Symbol. Story. A new perspective.'
    },
    reserve: {
      phase: 'The private orbit', method: 'Soma Reserve / VIP', short: 'Private · VIP',
      line: 'Some chapters deserve a conversation of their own.',
      best: 'A personally shaped Jyotish consultation for the life themes and interconnected questions that matter most to you.',
      inside: ['Begin with your priorities: share the questions you want to give your fullest attention.', 'Explore your birth chart, planetary periods and connected life themes in a dedicated conversation.', 'Agree the scope, session duration and appointment personally before confirming.'],
      prepare: ['Share your birth date, time and place, marking anything estimated or unknown.', 'Tell us which life themes deserve the most space. We’ll shape the session arrangements with you.'],
      reflection: 'What deserves a deeper, more considered conversation in this chapter of my life?',
      orbit: 'A private space. A perspective of your own.'
    }
  };
  const themes = [
    {id: 'career', label: 'Career & purpose'},
    {id: 'relationships', label: 'Relationships'},
    {id: 'self', label: 'Self & direction'},
    {id: 'beginnings', label: 'New beginnings'}
  ];
  const questions = {
    career: {
      prashna: 'What should I bring to a Prashna reading about my next career step?',
      crescent: 'What can my birth chart help me reflect on about my work and direction?',
      moonrise: 'How might my chart and current dashas relate to this career transition?',
      purnima: 'How can I explore my career priorities within the wider picture of my chart?',
      tarot: 'What could I notice about the way I’m approaching my next career chapter?',
      reserve: 'How can we explore my career, purpose and current planetary periods as one connected conversation?'
    },
    relationships: {
      prashna: 'How can I frame one meaningful question about a relationship?',
      crescent: 'Which relationship patterns could I explore through my birth chart?',
      moonrise: 'How do my relationship questions connect with other themes in my chart?',
      purnima: 'What could a wider reading help me reflect on about relationships and my priorities?',
      tarot: 'What perspective could help me bring more understanding to a relationship?',
      reserve: 'How do my relationship questions connect with the wider priorities and patterns in my chart?'
    },
    self: {
      prashna: 'What is the one question I most want to understand about my next step?',
      crescent: 'What could my chart help me notice about my sense of direction?',
      moonrise: 'Which connected themes in my chart feel most relevant to this chapter?',
      purnima: 'How can I explore my personal priorities through a fuller reading of my chart?',
      tarot: 'What am I ready to notice about myself and the choices in front of me?',
      reserve: 'Which interconnected life themes deserve a private, in-depth exploration through my chart?'
    },
    beginnings: {
      prashna: 'What is the one question I most want to explore about this new beginning?',
      crescent: 'What could a first chart reading help me reflect on as I begin again?',
      moonrise: 'How can I explore my current dashas in the context of a new chapter?',
      purnima: 'How does this new beginning sit within the wider themes of my chart?',
      tarot: 'What would help me approach a new beginning with more intention?',
      reserve: 'How can we explore this new beginning within the fuller context of my chart, timing and personal priorities?'
    }
  };
  const intentionPlans = {timing: 'prashna', direction: 'crescent', deeper: 'moonrise', reflection: 'tarot', private:'reserve'};
  const intentionCopy = {
    timing: 'For a new beginning, start with a focused question. Chandra Prashna is a thoughtful fit.',
    direction: 'For one area of life, begin gently. Crescent offers a personal introduction.',
    deeper: 'For connected questions, give yourself more room. Explore Moonrise.',
    reflection: 'For reflection through the cards, explore the Lunar Tarot experience.',
    private: 'For a conversation shaped around your priorities, enter the private orbit of Soma Reserve.'
  };
  let activeReading = 'crescent';
  let activeNotes = 'inside';
  let activeTheme = null;
  let lastIntention = 'all';
  const studio = document.querySelector('#consultation-grid');
  const mobileBar = document.querySelector('#reading-mobile-bookbar');
  const mobileReadingQuery = window.matchMedia('(max-width:700px)');
  const consultationSection = document.querySelector('#consultations');
  let barGeometry = null;
  let barGeometryDirty = true;
  let lastBarShown = false;
  let barQueued = false;

  const planById = id => consultations.find(plan => plan.id === id);
  const currentQuestion = () => activeTheme ? questions[activeTheme][activeReading] : stories[activeReading].reflection;
  const inquiryPrompt = () => activeTheme ? currentQuestion() : '';
  const timeLabel = plan => plan.duration;

  function revealSelectedPhase() {
    if (!window.matchMedia('(max-width:700px)').matches) return;
    const rail = studio.querySelector('.reading-phase-rail');
    const tab = studio.querySelector(`[data-reading-select="${activeReading}"]`);
    const tabLeft = tab.getBoundingClientRect().left - rail.getBoundingClientRect().left + rail.scrollLeft;
    rail.scrollTo({left:tabLeft - (rail.clientWidth - tab.clientWidth) / 2, behavior:'auto'});
  }

  function paintGuidance() {
    const guidance = document.querySelector('#intention-insight');
    guidance.textContent = intentionCopy[selectedIntention] || 'Six readings. Different intentions. Choose the one that feels like your next step.';
    guidance.classList.toggle('has-recommendation', selectedIntention !== 'all');
  }

  function paintQuestion() {
    document.querySelector('#reading-question').textContent = `“${currentQuestion()}”`;
    document.querySelector('#reading-question-label').textContent = activeTheme ? 'YOUR OPENING QUESTION' : 'A QUESTION TO BEGIN WITH';
    document.querySelectorAll('[data-reading-theme]').forEach(button => {
      const selected = button.dataset.readingTheme === activeTheme;
      button.setAttribute('aria-pressed', String(selected));
    });
    [studio.querySelector('[data-plan]'), mobileBar.querySelector('[data-plan]')].forEach(book => {
      if (book) book.dataset.readingPrompt = inquiryPrompt();
    });
    document.querySelector('#reading-question-note').textContent = activeTheme
      ? 'We’ll add this question to your enquiry. You can make it your own before sending.'
      : 'Choose a theme above to shape a question. Bring your own words to the conversation.';
  }

  function paintNotes() {
    const notes = stories[activeReading][activeNotes];
    document.querySelector('#reading-notes').innerHTML = notes.map(note => `<li>${icon('check')}<span>${note}</span></li>`).join('');
    document.querySelector('#reading-notes').setAttribute('aria-labelledby', `reading-notes-${activeNotes}`);
    studio.querySelectorAll('[data-reading-notes]').forEach(button => {
      const selected = button.dataset.readingNotes === activeNotes;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
    });
  }

  function paintReading(withMotion = true) {
    const plan = planById(activeReading);
    const story = stories[activeReading];
    const index = order.indexOf(activeReading);
    studio.querySelector('#reading-phase-count').textContent = `0${index + 1} / ${String(order.length).padStart(2,'0')}`;
    studio.querySelectorAll('[data-reading-select]').forEach(button => {
      const selected = button.dataset.readingSelect === activeReading;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
    });
    const panel = studio.querySelector('#reading-panel');
    panel.setAttribute('aria-labelledby', `reading-tab-${activeReading}`);
    panel.dataset.reading = activeReading;
    panel.innerHTML = `
      <div class="reading-cosmos" aria-hidden="true">
        <div class="cosmos-caption"><span>${plan.vip ? 'LUNIC / THE PRIVATE CONSULTATION' : `0${index + 1} / THE LUNAR READINGS`}</span><span>✦</span></div>
        <div class="reading-moon-scene">
          <div class="reading-orbit orbit-outer"></div><div class="reading-orbit orbit-inner"></div>
          <i class="cosmos-star star-one">✦</i><i class="cosmos-star star-two">✧</i><i class="cosmos-star star-three">·</i>
          ${plan.vip ? '<div class="reserve-corona"></div><div class="reserve-seal"><span class="reserve-seal-top">SOMA RESERVE</span><span class="reserve-monogram">S<span>R</span></span><span class="reserve-seal-bottom">THE PRIVATE ORBIT</span></div>' : plan.id === 'tarot' ? '<div class="reading-deck"><div class="celestial-card card-back">✧</div><div class="celestial-card card-middle">☼</div><div class="celestial-card card-front"><span>☾</span><small>THE INNER MIRROR</small></div></div>' : `<div class="reading-orb ${plan.moon}"><span></span></div>`}
          <span class="cosmos-coordinate coordinate-left">INTENTION</span><span class="cosmos-coordinate coordinate-right">PERSPECTIVE</span>
        </div>
        <div class="cosmos-footer"><span>${story.phase}</span><p>${story.orbit}</p><div class="cosmos-dots">${order.map(id => `<i class="${id === activeReading ? 'active' : ''}"></i>`).join('')}</div></div>
      </div>
      <div class="reading-copy">
        ${plan.vip ? '<div class="reserve-kicker"><span>✦</span> LUNIC / PRIVATE CLIENT</div>' : ''}
        <div class="reading-meta"><span>${story.method}</span><span class="reading-time">${timeLabel(plan)}</span></div>
        <div class="reading-title-row"><h3>${plan.name}</h3>${icon('arrow')}</div>
        <p class="reading-lead">${story.line}</p>
        <p class="reading-best"><span>A LITTLE SPACE FOR</span>${story.best}</p>
        <div class="reading-note-tabs" role="tablist" aria-label="About ${plan.name}">
          <button role="tab" id="reading-notes-inside" data-reading-notes="inside" aria-controls="reading-notes" aria-selected="true">Inside your reading</button>
          <button role="tab" id="reading-notes-prepare" data-reading-notes="prepare" aria-controls="reading-notes" aria-selected="false" tabindex="-1">What to bring</button>
        </div>
        <ul id="reading-notes" class="reading-notes" role="tabpanel" tabindex="0"></ul>
        <div class="reading-reserve"><div class="reading-fee"><strong>${money(plan.price)}</strong><span>${plan.vip ? 'private consultation' : 'per consultation'}</span></div><button class="button reading-book" data-plan="${plan.id}" data-reading-prompt="${escapeHtml(inquiryPrompt())}">${plan.vip ? 'Request a private appointment' : `Enquire about ${plan.name}`} ${icon('arrow')}</button></div>
        <p class="reading-book-note">${plan.vip ? 'Your scope, duration and appointment are agreed personally. Begin with an enquiry.' : 'Pick a preferred time. We’ll confirm the details personally on WhatsApp.'}</p>
      </div>`;
    const ritual = studio.querySelector('#reserve-experience');
    ritual.hidden = !plan.vip;
    mobileBar.classList.toggle('is-reserve', Boolean(plan.vip));
    paintNotes();
    paintQuestion();
    mobileBar.querySelector('strong').textContent = plan.name;
    mobileBar.querySelector('.mobile-reading-price').textContent = money(plan.price);
    mobileBar.querySelector('[data-plan]').dataset.plan = plan.id;
    mobileBar.querySelector('[data-plan]').setAttribute('aria-label', `Enquire about ${plan.name}, ${money(plan.price)}`);
    document.querySelector('#reading-selection-status').textContent = `${plan.name} selected. ${money(plan.price)}. ${timeLabel(plan)}.`;
    if (withMotion) window.LunicExperience?.animateGrid(panel);
    queueBarUpdate();
  }

  function selectReading(id, {preserveIntention = false, withMotion = true} = {}) {
    if (!order.includes(id)) return;
    if (!preserveIntention) {
      selectedIntention = 'all';
      lastIntention = 'all';
      document.querySelectorAll('[data-intention]').forEach(button => {
        const selected = button.dataset.intention === 'all';
        button.classList.toggle('active', selected);
        button.setAttribute('aria-pressed', String(selected));
      });
    }
    activeReading = id;
    activeNotes = 'inside';
    paintGuidance();
    paintReading(withMotion);
    revealSelectedPhase();
  }

  function render() {
    if (!studio.querySelector('#reading-panel')) {
      studio.innerHTML = `<div class="reading-mobile-hint"><span>SWIPE TO EXPLORE THE PHASES ${icon('arrow-right')}</span><span id="reading-phase-count">02 / ${String(order.length).padStart(2,'0')}</span></div><div class="reading-phase-rail" role="tablist" aria-label="Explore the six Lunic readings">${order.map((id, index) => {
        const plan = planById(id);
        return `<button class="reading-choice${plan.vip ? ' reserve-choice' : ''}" role="tab" id="reading-tab-${id}" data-reading-select="${id}" aria-controls="reading-panel" aria-selected="${id === activeReading}" tabindex="${id === activeReading ? '0' : '-1'}"><span class="reading-choice-top"><span>0${index + 1} / ${stories[id].short}</span><span class="card-moon ${plan.moon}" aria-hidden="true"></span></span><strong>${plan.name}</strong><span class="reading-choice-bottom">${money(plan.price)}${icon('arrow')}</span></button>`;
      }).join('')}</div><div id="reading-panel" class="reading-panel" role="tabpanel"></div><div class="reserve-experience" id="reserve-experience" hidden><div><span>01 / THE INTENTION</span><h4>Begin with your story.</h4><p>Share your priorities and birth details, with space to explain what matters.</p></div><div><span>02 / THE CONVERSATION</span><h4>Explore your own constellation.</h4><p>Your chart, planetary periods and connected questions, considered together.</p></div><div><span>03 / THE REFLECTION</span><h4>Bring it back to your life.</h4><p>Consider the perspective alongside your own judgment and lived experience.</p></div></div><p id="reading-selection-status" class="sr-only" role="status" aria-live="polite"></p>`;
    }
    const intentionChanged = lastIntention !== selectedIntention;
    if (intentionChanged) {
      activeReading = intentionPlans[selectedIntention] || activeReading;
      activeNotes = 'inside';
      lastIntention = selectedIntention;
    }
    paintGuidance();
    paintReading(false);
    if (intentionChanged) revealSelectedPhase();
  }

  function showComparison() {
    openDialog(`<div class="dialog-content-padded comparison-dialog"><div class="dialog-eyebrow">SIX WAYS TO FIND YOUR LIGHT</div><h2>A reading for<br><em>your kind of question.</em></h2><p class="dialog-description">Compare the approach, time and fee. Every reading is a personal, one-to-one conversation.</p><div class="reading-compare-grid">${order.map(id => {
      const plan = planById(id);
      const story = stories[id];
      return `<article class="reading-compare-card${plan.vip ? ' reserve-compare' : ''}${id === activeReading ? ' is-current' : ''}"><div class="compare-card-top"><div class="card-moon ${plan.moon}" aria-hidden="true"></div><span>${plan.vip ? 'PRIVATE / VIP' : id === activeReading ? 'YOUR SELECTION' : story.method.split(' / ')[0]}</span></div><h3>${plan.name}</h3><p class="compare-time">${timeLabel(plan)}</p><p>${story.best}</p><div class="compare-card-bottom"><strong>${money(plan.price)}</strong><button data-plan="${id}" aria-label="Enquire about ${plan.name}, ${money(plan.price)}">${plan.vip ? 'Request appointment' : 'Enquire'} ${icon('arrow')}</button></div></article>`;
    }).join('')}</div><p class="compare-footnote">Appointments are confirmed personally; no payment is taken on this site.</p></div>`, 'Compare Lunic readings');
  }

  function updateMobileBar() {
    barQueued = false;
    let show = false;
    if (mobileReadingQuery.matches) {
      const pageY = window.scrollY;
      if (barGeometryDirty || !barGeometry) {
        const section = consultationSection.getBoundingClientRect();
        const panel = studio.querySelector('#reading-panel').getBoundingClientRect();
        const book = studio.querySelector('.reading-book').getBoundingClientRect();
        barGeometry = {sectionTop:section.top + pageY, sectionBottom:section.bottom + pageY, panelTop:panel.top + pageY, bookTop:book.top + pageY, bookBottom:book.bottom + pageY};
        barGeometryDirty = false;
      }
      const g = barGeometry;
      const bookVisible = g.bookTop - pageY >= 80 && g.bookBottom - pageY <= innerHeight - 16;
      show = g.sectionTop - pageY < 100 && g.sectionBottom - pageY > 170 && g.panelTop - pageY < innerHeight - 140 && !bookVisible;
    }
    if (show !== lastBarShown) {
      lastBarShown = show;
      mobileBar.hidden = !show;
      document.body.classList.toggle('reading-bar-visible', show);
    }
  }

  function queueBarUpdate() {
    barGeometryDirty = true;
    scheduleBarUpdate();
  }
  function scheduleBarUpdate() {
    if (!barQueued) { barQueued = true; requestAnimationFrame(updateMobileBar); }
  }
  window.addEventListener('scroll', scheduleBarUpdate, {passive:true});
  window.addEventListener('resize', queueBarUpdate, {passive:true});
  const readingResizeObserver = new ResizeObserver(queueBarUpdate);
  readingResizeObserver.observe(consultationSection);
  readingResizeObserver.observe(document.body);
  mobileReadingQuery.addEventListener('change', queueBarUpdate);

  document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.readingSelect) selectReading(button.dataset.readingSelect);
    if (button.dataset.readingNotes) { activeNotes = button.dataset.readingNotes; paintNotes(); }
    if (button.dataset.readingTheme) {
      activeTheme = activeTheme === button.dataset.readingTheme ? null : button.dataset.readingTheme;
      paintQuestion();
    }
    if (button.dataset.action === 'compare-readings') showComparison();
    if (button.dataset.action === 'explore-reserve') {
      selectReading('reserve');
      studio.querySelector('#reading-panel').scrollIntoView({block:'start',behavior:document.body.dataset.motion === 'on' ? 'smooth' : 'auto'});
    }
  });

  document.addEventListener('keydown', event => {
    const button = event.target.closest('[data-reading-select], [data-reading-notes]');
    if (!button || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const isReading = Boolean(button.dataset.readingSelect);
    const options = isReading ? order : ['inside', 'prepare'];
    let index = options.indexOf(isReading ? activeReading : activeNotes);
    index = event.key === 'Home' ? 0 : event.key === 'End' ? options.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + options.length) % options.length;
    if (isReading) selectReading(options[index]);
    else { activeNotes = options[index]; paintNotes(); }
    document.querySelector(`[data-reading-${isReading ? 'select' : 'notes'}="${options[index]}"]`).focus({preventScroll: true});
  });

  window.LunicReadings = {render, select: selectReading};
  render();
})();

;
'use strict';

(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const lightExperience = window.matchMedia('(max-width:900px), (pointer:coarse)');
  let motionPreference = true;
  try { motionPreference = localStorage.getItem('lunic-motion') !== 'off'; } catch { /* Motion works without storage. */ }
  let motionEnabled = motionPreference && !reducedMotion.matches;
  const motionControl = document.querySelector('.motion-control');
  const animations = new Set();

  function animate(element, keyframes, options = {}) {
    if (!motionEnabled || !element?.animate) return;
    const animation = element.animate(keyframes, {duration: 480, easing: 'cubic-bezier(.2,.7,.2,1)', ...options, ...(lightExperience.matches ? {duration:180, delay:0} : {})});
    animations.add(animation);
    animation.finished.then(() => animations.delete(animation), () => animations.delete(animation));
    return animation;
  }

  function animateGrid(grid, start = 0) {
    if (lightExperience.matches) return;
    Array.from(grid.children).slice(start).forEach((card, index) => {
      animate(card, [{opacity: 0, transform: 'translateY(23px) scale(.985)'}, {opacity: 1, transform: 'translateY(0) scale(1)'}], {delay: Math.min(index, 8) * 45, duration: 550});
    });
  }

  function animateDialog() {
    animate(dialogContent, [{opacity: 0, transform: 'translateY(12px)'}, {opacity: 1, transform: 'translateY(0)'}], {duration: 360});
  }

  // A short, preference-led reading finder. It does not calculate a birth chart.
  let finder = {step: 1, intention: null, plan: null};
  const intentions = [
    {id: 'question', symbol: '☾', title: 'One question', copy: 'Something specific is on my mind.', suggestion: 'prashna'},
    {id: 'beginning', symbol: '✧', title: 'Dates & new beginnings', copy: 'I’m choosing when to begin, buy, sell or celebrate.', suggestion: 'chandra-kala'},
    {id: 'direction', symbol: '◐', title: 'Life & direction', copy: 'I’d like perspective on where I am.', suggestion: 'crescent'},
    {id: 'picture', symbol: '○', title: 'The bigger picture', copy: 'I want to connect the patterns in my life.', suggestion: 'moonrise'},
    {id: 'reflection', symbol: '✦', title: 'Tarot & reflection', copy: 'I’d like to explore my questions through the cards.', suggestion: 'tarot'},
    {id:'private',symbol:'✧',title:'A private consultation',copy:'I’d like a conversation shaped around my priorities.',suggestion:'reserve'}
  ];

  function showFinder(reset = false) {
    if (reset) finder = {step: 1, intention: null, plan: null};
    const intention = intentions.find(item => item.id === finder.intention);
    const progress = `<div class="finder-progress" aria-label="Step ${finder.step} of 3">${['Your intention', 'Your space', 'Your reading'].map((label, index) => `<span class="${index + 1 <= finder.step ? 'complete' : ''}"><i>${index + 1 < finder.step ? '✓' : `0${index + 1}`}</i>${label}</span>`).join('')}</div>`;
    let content;
    if (finder.step === 1) {
      content = `<div class="dialog-eyebrow">A LITTLE DIRECTION FROM LUNIC</div><h2>What brings you<br><em>to this moment?</em></h2><p class="dialog-description">Start with what’s on your mind. There’s no wrong place to begin.</p><div class="finder-options">${intentions.map(item => `<button class="finder-option" data-finder-intention="${item.id}"><span class="finder-option-symbol" aria-hidden="true">${item.symbol}</span><span><strong>${item.title}</strong><small>${item.copy}</small></span>${icon('arrow')}</button>`).join('')}</div>`;
    } else if (finder.step === 2) {
      content = `<div class="dialog-eyebrow">YOUR INTENTION / ${intention.title.toUpperCase()}</div><h2>How much space<br><em>feels right?</em></h2><p class="dialog-description">Choose a focused reading, timing guidance, a longer conversation or Tarot. You can always explore another reading.</p><div class="finder-options finder-duration-options">${consultations.map(plan => `<button class="finder-option${plan.id === intention.suggestion ? ' suggested' : ''}" data-finder-plan="${plan.id}"><div class="card-moon ${plan.moon}" aria-hidden="true"></div><span><strong>${plan.name}</strong><small>${plan.duration}${plan.id === intention.suggestion ? ' · Suggested for your intention' : ''}</small></span><span class="finder-option-price">${money(plan.price)} ${icon('arrow')}</span></button>`).join('')}</div><button class="text-link finder-back" data-action="finder-back">${icon('arrow-left')} Back to my intention</button>`;
    } else {
      const plan = consultations.find(item => item.id === finder.plan);
      const reasons = {
        prashna: 'A focused space for a Prashna question. Bring the one thing you’d most like to explore.',
        'chandra-kala': 'Chandra Kala brings Muhurta and Panchanga into your plans. Share the occasion, event location, date range and practical constraints to discuss meaningful dates and time windows.',
        crescent: 'A gentle introduction to your birth chart, with 15 minutes devoted to one life area and your personal questions.',
        moonrise: 'Room to connect related life themes, explore your current dashas and reflect on the questions shaping your next chapter.',
        purnima: 'A wider conversation about your chart, planetary periods and the priorities you’d like to explore in depth.',
        tarot: 'A personal Tarot reading with space for your questions. Explore the symbolism of the cards, reflect on your present circumstances and consider the possibilities ahead.',
        reserve: 'Soma Reserve is our VIP private Jyotish consultation. Begin with your priorities, then agree the focus, session duration and appointment personally. A considered conversation, shaped around you.'
      };
      content = `<div class="finder-result"><div class="finder-result-orbit" aria-hidden="true"><div class="card-moon ${plan.moon}"></div><span>✦</span></div><div class="dialog-eyebrow">A STARTING POINT FOR YOUR INTENTION</div><h2>${plan.name}</h2><p class="dialog-description">${reasons[plan.id]}</p><div class="finder-result-price"><strong>${money(plan.price)}</strong><span>${plan.duration} · One to one</span></div><button class="button finder-book" data-plan="${plan.id}">Explore my ${plan.name} reading ${icon('arrow')}</button><button class="text-link finder-back" data-action="finder-back">${icon('arrow-left')} Explore another reading</button></div>`;
    }
    openDialog(`<div class="dialog-content-padded finder-dialog">${progress}${content}</div>`, 'Find your personal reading');
  }

  // Continuous illumination, with direct manipulation and optional playback.
  const range = document.querySelector('#lunar-range');
  const lunarMoon = document.querySelector('.interactive-moon');
  const shadow = document.querySelector('.moon-shadow');
  const cycleButton = document.querySelector('[data-action="play-cycle"]');
  const illuminationLabel = document.querySelector('#lunar-illumination');
  const phaseContent = document.querySelector('.phase-content');
  const phaseSanskrit = document.querySelector('#phase-sanskrit');
  const phaseTitle = document.querySelector('#phase-title');
  const phaseDescription = document.querySelector('#phase-description');
  const phaseButtons = [...document.querySelectorAll('button[data-phase]')];
  const moonEdges = Array.from({length:51}, (_, index) => ({y:index * 2, edge:Math.sqrt(Math.max(0, 2500 - (index * 2 - 50) ** 2))}));
  let lastIllumination = -1;
  let lunarValue = 0;
  let lunarPhase = 'new';
  let cyclePlaying = false;
  let moonTweenId = 0;
  const phaseValues = {new: 0, waxing: 25, full: 50, waning: 75};

  function setCycle(value, announce = true) {
    lunarValue = Math.max(0, Math.min(100, value));
    const cosine = Math.cos(lunarValue / 100 * Math.PI * 2);
    const illumination = Math.round((1 - cosine) * 50);
    const waxing = lunarValue <= 50;
    const points = [];
    for (const {y, edge} of moonEdges) {
      points.push(`${(50 + (waxing ? cosine : -cosine) * edge).toFixed(2)}% ${y}%`);
    }
    shadow.style.clipPath = `polygon(${waxing ? '0% 0%' : '100% 0%'},${points.join(',')},${waxing ? '0% 100%' : '100% 100%'})`;
    shadow.style.transform = 'none';
    shadow.style.opacity = '1';
    lunarMoon.style.setProperty('--illumination', illumination / 100);
    range.value = lunarValue;
    range.style.setProperty('--range-progress', `${lunarValue}%`);
    if (illumination !== lastIllumination) {
      illuminationLabel.textContent = `${illumination}% illuminated`;
      lastIllumination = illumination;
    }
    const phaseKey = lunarValue < 6 || lunarValue > 94 ? 'new' : lunarValue < 44 ? 'waxing' : lunarValue <= 56 ? 'full' : 'waning';
    const name = {new: 'New moon', waxing: 'Waxing moon', full: 'Full moon', waning: 'Waning moon'}[phaseKey];
    range.setAttribute('aria-valuetext', `${name}, ${illumination}% illuminated`);
    // Playback is visual; screen readers receive the final phase when paused.
    if (phaseKey !== lunarPhase || announce) {
      const phase = phases[phaseKey];
      lunarPhase = phaseKey;
      lunarMoon.dataset.phase = phaseKey;
      phaseSanskrit.textContent = phase.sanskrit;
      phaseTitle.textContent = phase.title;
      phaseDescription.textContent = phase.description;
      phaseButtons.forEach(button => {
        const active = button.dataset.phase === phaseKey;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', active);
      });
      if (announce) animate(phaseContent, [{opacity: .2, transform: 'translateY(5px)'}, {opacity: 1, transform: 'translateY(0)'}], {duration: 300});
    }
  }

  function stopCycle() {
    cyclePlaying = false;
    cycleButton.setAttribute('aria-pressed', 'false');
    cycleButton.innerHTML = `${icon('play')}<span>Watch the cycle</span>`;
    phaseContent.setAttribute('aria-live', 'polite');
  }

  function selectPhase(key) {
    stopCycle();
    cancelAnimationFrame(moonTweenId);
    const from = lunarValue;
    const to = phaseValues[key];
    if (!motionEnabled) { setCycle(to); return; }
    const start = performance.now();
    function tween(now) {
      const progress = Math.min(1, (now - start) / 750);
      setCycle(from + (to - from) * (1 - (1 - progress) ** 3), false);
      if (progress < 1) moonTweenId = requestAnimationFrame(tween);
    }
    moonTweenId = requestAnimationFrame(tween);
  }

  range.addEventListener('input', () => {
    stopCycle();
    cancelAnimationFrame(moonTweenId);
    setCycle(Number(range.value), false);
  });
  setCycle(0, false);

  // Draw the atmosphere locally. No heavy animation framework or remote assets.
  const canvas = document.querySelector('.starfield');
  const context = canvas.getContext('2d');
  const hero = document.querySelector('.hero');
  const heroArt = document.querySelector('.hero-art');
  let width = 0;
  let height = 0;
  let stars = [];
  let heroVisible = true;
  let moonVisible = false;
  let frameId = 0;
  let lastFrame = 0;
  let elapsed = 0;
  const pointer = {x: .65, y: .4, targetX: .65, targetY: .4, inside: false};

  function resizeStars() {
    const rectangle = hero.getBoundingClientRect();
    if (width === rectangle.width && height === rectangle.height) return;
    width = rectangle.width;
    height = rectangle.height;
    const ratio = lightExperience.matches ? 1 : Math.min(window.devicePixelRatio || 1, 1.5);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    context?.setTransform(ratio, 0, 0, ratio, 0, 0);
    stars = Array.from({length: lightExperience.matches ? 28 : 86}, () => ({x: Math.random(), y: Math.random() * .85, size: .5 + Math.random() * 1.2, speed: .15 + Math.random() * .8, phase: Math.random() * Math.PI * 2}));
    drawStars(0);
  }

  function drawStars(time) {
    if (!context || !width) return;
    context.clearRect(0, 0, width, height);
    pointer.x += (pointer.targetX - pointer.x) * .045;
    pointer.y += (pointer.targetY - pointer.y) * .045;
    if (motionEnabled && pointer.inside) heroArt.style.backgroundPosition = `calc(50% + ${(pointer.targetX - .5) * 16}px) calc(51% + ${(pointer.targetY - .5) * 12}px)`;
    const near = [];
    stars.forEach(star => {
      const x = star.x * width + (pointer.x - .5) * star.speed * 15;
      const y = star.y * height + Math.sin(time * .00015 * star.speed + star.phase) * 5;
      const alpha = motionEnabled ? .25 + (Math.sin(time * .0007 * star.speed + star.phase) + 1) * .23 : .4;
      context.fillStyle = `rgba(239,218,190,${alpha})`;
      context.beginPath();context.arc(x, y, star.size, 0, Math.PI * 2);context.fill();
      if (pointer.inside && Math.hypot(x - pointer.x * width, y - pointer.y * height) < 170) near.push({x,y});
    });
    if (motionEnabled && pointer.inside) {
      near.forEach((a, index) => near.slice(index + 1).forEach(b => {
        const distance = Math.hypot(a.x - b.x, a.y - b.y);
        if (distance < 110) {
          context.strokeStyle = `rgba(211,181,145,${(1 - distance / 110) * .22})`;
          context.lineWidth = .6;context.beginPath();context.moveTo(a.x,a.y);context.lineTo(b.x,b.y);context.stroke();
        }
      }));
    }
    const meteor = time % 12000;
    if (motionEnabled && meteor > 1500 && meteor < 2650) {
      const progress = (meteor - 1500) / 1150;
      const x = width * (.92 - progress * .4);
      const y = height * (.05 + progress * .25);
      const gradient = context.createLinearGradient(x, y, x + 100, y - 48);
      gradient.addColorStop(0, `rgba(246,222,186,${Math.sin(progress * Math.PI) * .7})`);
      gradient.addColorStop(1, 'rgba(246,222,186,0)');
      context.strokeStyle = gradient;context.lineWidth = 1.5;context.beginPath();context.moveTo(x,y);context.lineTo(x+100,y-48);context.stroke();
    }
  }

  function frame(now) {
    frameId = 0;
    if (!motionEnabled || document.hidden || dialog.open || (!(heroVisible && !lightExperience.matches) && !(cyclePlaying && moonVisible))) return;
    if (!lastFrame) lastFrame = now;
    const delta = Math.min(60, now - lastFrame);
    if (delta >= 30) {
      elapsed += delta;
      lastFrame = now;
      if (heroVisible && !lightExperience.matches) drawStars(elapsed);
      if (cyclePlaying && moonVisible) setCycle((lunarValue + delta / 280) % 100, false);
    }
    frameId = requestAnimationFrame(frame);
  }

  function resumeFrames() {
    if (!frameId && motionEnabled && !document.hidden && !dialog.open && ((heroVisible && !lightExperience.matches) || (cyclePlaying && moonVisible))) {
      lastFrame = 0;
      frameId = requestAnimationFrame(frame);
    }
  }

  function updateMotion() {
    motionEnabled = motionPreference && !reducedMotion.matches;
    document.body.dataset.motion = motionEnabled ? 'on' : 'off';
    document.documentElement.style.scrollBehavior = motionEnabled ? '' : 'auto';
    motionControl.disabled = reducedMotion.matches;
    motionControl.setAttribute('aria-pressed', String(motionEnabled));
    motionControl.setAttribute('aria-label', reducedMotion.matches ? 'Reduced motion is enabled in your system settings' : motionEnabled ? 'Pause ambient animations' : 'Resume ambient animations');
    motionControl.innerHTML = `${icon(motionEnabled ? 'pause' : 'play')}<span>${reducedMotion.matches ? 'Reduced motion' : motionEnabled ? 'Motion on' : 'Motion paused'}</span>`;
    if (!motionEnabled) {
      cancelAnimationFrame(frameId);frameId = 0;
      cancelAnimationFrame(moonTweenId);
      stopCycle();
      animations.forEach(animation => { try { animation.finish(); } catch { animation.cancel(); } });
      document.querySelectorAll('[style*="--tilt"], [style*="--magnet"]').forEach(element => {
        ['--tilt-x','--tilt-y','--magnet-x','--magnet-y'].forEach(property => element.style.removeProperty(property));
      });
      heroArt.style.backgroundPosition = '';
      heroArt.style.removeProperty('--scroll-parallax');
      drawStars(0);
    } else resumeFrames();
    cycleButton.disabled = !motionEnabled;
  }

  const appeared = new WeakSet();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      entry.target.classList.toggle('in-view', entry.isIntersecting);
      if (entry.target === hero) heroVisible = entry.isIntersecting;
      if (entry.target.matches('.moon-experience')) moonVisible = entry.isIntersecting;
      if (entry.isIntersecting && entry.target.matches('#consultation-grid, #product-grid, .journal-grid') && !appeared.has(entry.target)) {
        appeared.add(entry.target);animateGrid(entry.target);
      }
    });
    resumeFrames();
  }, {threshold: .05});
  document.querySelectorAll('.hero, .philosophy-art, .moon-experience, .closing, #consultation-grid, #product-grid, .journal-grid').forEach(element => observer.observe(element));
  const resizeObserver = new ResizeObserver(resizeStars);
  resizeObserver.observe(hero);
  document.addEventListener('visibilitychange', () => {
    document.body.toggleAttribute('data-page-hidden', document.hidden);
    if (document.hidden) { cancelAnimationFrame(frameId);frameId = 0; }
    else resumeFrames();
  });
  reducedMotion.addEventListener('change', updateMotion);
  lightExperience.addEventListener('change', () => {
    width = 0;
    resizeStars();
    heroArt.style.removeProperty('--scroll-parallax');
    resumeFrames();
  });
  dialog.addEventListener('close', resumeFrames);

  hero.addEventListener('pointermove', event => {
    if (!motionEnabled || lightExperience.matches || !finePointer.matches) return;
    const rectangle = hero.getBoundingClientRect();
    pointer.targetX = (event.clientX - rectangle.left) / rectangle.width;
    pointer.targetY = (event.clientY - rectangle.top) / rectangle.height;
    pointer.inside = true;
  });
  hero.addEventListener('pointerleave', () => { pointer.inside = false;pointer.targetX = .65;pointer.targetY = .4;heroArt.style.backgroundPosition = ''; });

  // Responsive highlights follow the pointer, without replacing the cursor.
  let hoverFrame = 0;
  document.addEventListener('pointermove', event => {
    if (!motionEnabled || lightExperience.matches || !finePointer.matches || hoverFrame) return;
    const card = event.target.closest('.consultation-card, .product-image, .reading-cosmos');
    const button = event.target.closest('.button');
    if (!card && !button) return;
    const {clientX, clientY} = event;
    hoverFrame = requestAnimationFrame(() => {
      hoverFrame = 0;
      if (card) {
        const rectangle = card.getBoundingClientRect();
        const x = (clientX - rectangle.left) / rectangle.width;
        const y = (clientY - rectangle.top) / rectangle.height;
        card.style.setProperty('--glow-x', `${x * 100}%`);card.style.setProperty('--glow-y', `${y * 100}%`);
        card.style.setProperty('--tilt-x', `${(y - .5) * -4}deg`);card.style.setProperty('--tilt-y', `${(x - .5) * 4}deg`);
      }
      if (button) {
        const rectangle = button.getBoundingClientRect();
        button.style.setProperty('--magnet-x', `${(clientX - rectangle.left - rectangle.width / 2) * .08}px`);
        button.style.setProperty('--magnet-y', `${(clientY - rectangle.top - rectangle.height / 2) * .12}px`);
      }
    });
  });
  document.addEventListener('pointerout', event => {
    const element = event.target.closest('.consultation-card, .product-image, .reading-cosmos, .button');
    if (!element || element.contains(event.relatedTarget)) return;
    ['--tilt-x','--tilt-y','--magnet-x','--magnet-y'].forEach(property => element.style.removeProperty(property));
  });

  const search = document.querySelector('#product-search');
  let searchFrame = 0;
  search.addEventListener('input', () => {
    productSearch = search.value;visibleProductCount = 9;
    if (!searchFrame) searchFrame = requestAnimationFrame(() => { searchFrame = 0;renderProducts(false); });
  });

  document.addEventListener('click', event => {
    const target = event.target.closest('button, a');
    if (!target) return;
    if (target.dataset.finderIntention) { finder.intention = target.dataset.finderIntention;finder.step = 2;showFinder(); }
    if (target.dataset.finderPlan) { finder.plan = target.dataset.finderPlan;window.LunicReadings?.select(finder.plan, {withMotion: false});finder.step = 3;showFinder(); }
    if (target.dataset.save || target.dataset.dialogSave) {
      animate(document.querySelector('.bag-button'), [{transform: 'scale(1)'}, {transform: 'scale(1.3) rotate(-7deg)'}, {transform: 'scale(1)'}], {duration: 450});
    }
    if (target.matches('.button') && motionEnabled && event.detail) {
      const rectangle = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'button-ripple';ripple.setAttribute('aria-hidden','true');
      ripple.style.left = `${event.clientX - rectangle.left}px`;ripple.style.top = `${event.clientY - rectangle.top}px`;
      target.append(ripple);setTimeout(() => ripple.remove(), 700);
    }
    switch (target.dataset.action) {
      case 'find-reading': showFinder(true);break;
      case 'finder-back': finder.step = Math.max(1, finder.step - 1);showFinder();break;
      case 'toggle-motion':
        motionPreference = !motionPreference;
        try { localStorage.setItem('lunic-motion', motionPreference ? 'on' : 'off'); } catch { /* Optional preference only. */ }
        updateMotion();break;
      case 'play-cycle':
        if (!motionEnabled) break;
        cancelAnimationFrame(moonTweenId);
        if (cyclePlaying) stopCycle();
        else { cyclePlaying = true;phaseContent.setAttribute('aria-live','off');cycleButton.setAttribute('aria-pressed','true');cycleButton.innerHTML = `${icon('pause')}<span>Pause the cycle</span>`;resumeFrames(); }
        break;
      case 'reset-collection':
        productSearch = '';search.value = '';activeFilter = 'all';visibleProductCount = 9;resetProductFacets();
        document.querySelectorAll('[data-filter]').forEach(button => { const active = button.dataset.filter === 'all';button.classList.toggle('active',active);button.setAttribute('aria-pressed',active); });
        renderProducts();search.focus({preventScroll:true});break;
      case 'zoom-product': {
        const stage = target.closest('.product-image-stage');
        const zoomed = stage.classList.toggle('zoomed');
        target.setAttribute('aria-pressed',String(zoomed));
        target.setAttribute('aria-label',zoomed ? 'Zoom out of product image' : 'Zoom in on product image');
        target.innerHTML = `${icon('zoom')}<span>${zoomed ? 'Back to full view' : 'Look closer'}</span>`;
        break;
      }
      case 'scroll-top': window.scrollTo({top:0,behavior:motionEnabled ? 'smooth' : 'auto'});break;
    }
  });

  const navigationLinks = Array.from(document.querySelectorAll('.desktop-nav a, #mobile-nav a'));
  const navigationSections = ['philosophy','consultations','muhurta','collection','journal'].map(id => document.getElementById(id));
  const progress = document.querySelector('.reading-progress span');
  const topButton = document.querySelector('.back-to-top');
  const header = document.querySelector('.site-header');
  let sectionOffsets = [];
  let scrollableHeight = 0;
  let lastActiveSection = null;
  let lastPastTop = null;
  let lastScrolled = null;
  let scrollQueued = false;
  function measurePage() {
    const pageY = window.scrollY;
    sectionOffsets = navigationSections.map(section => ({id:section.id, top:section.getBoundingClientRect().top + pageY}));
    scrollableHeight = Math.max(0, document.documentElement.scrollHeight - innerHeight);
    queueScroll();
  }
  function updateScroll() {
    scrollQueued = false;
    const pageY = Math.max(0, window.scrollY);
    progress.style.transform = `scaleX(${scrollableHeight ? Math.min(1, pageY / scrollableHeight) : 0})`;
    if (lastPastTop !== (pageY > 650)) {
      lastPastTop = pageY > 650;
      topButton.classList.toggle('visible', lastPastTop);
      topButton.tabIndex = lastPastTop ? 0 : -1;
    }
    if (lastScrolled !== (pageY > 30)) {
      lastScrolled = pageY > 30;
      header.classList.toggle('scrolled', lastScrolled);
    }
    let active = '';
    sectionOffsets.forEach(section => { if (section.top <= pageY + 180) active = section.id; });
    if (active !== lastActiveSection) {
      lastActiveSection = active;
      navigationLinks.forEach(link => {
        const current = link.hash === `#${active}`;
        link.classList.toggle('current', current);
        if (current) link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');
      });
    }
    if (heroVisible && motionEnabled && !lightExperience.matches) heroArt.style.setProperty('--scroll-parallax', `${Math.min(pageY * .045, 25)}px`);
  }
  function queueScroll() {
    if (!scrollQueued) { scrollQueued = true; requestAnimationFrame(updateScroll); }
  }
  window.addEventListener('scroll', queueScroll, {passive:true});
  window.addEventListener('resize', measurePage, {passive:true});
  const pageResizeObserver = new ResizeObserver(measurePage);
  pageResizeObserver.observe(document.body);
  navigationSections.forEach(section => pageResizeObserver.observe(section));

  window.LunicExperience = {animateGrid, animateDialog, setPhase: selectPhase};
  resizeStars();updateMotion();measurePage();
})();

;
'use strict';

(() => {
  const occasions = [
    {id:'begin',label:'Begin something',short:'A new beginning',title:'Give your beginning a moment of its own.',copy:'A business launch, a new venture, an important first step. Bring your plans and the dates you can realistically consider.',prompt:'Business launch, new venture or a personal beginning'},
    {id:'buy',label:'Buy something',short:'A considered purchase',title:'A considered purchase. A considered moment.',copy:'Planning a vehicle purchase, property registration or another significant purchase? Discuss a time window around the arrangements you already have.',prompt:'Vehicle purchase, property registration or another purchase'},
    {id:'sell',label:'Sell something',short:'The next chapter',title:'Close one chapter with intention.',copy:'From a property sale to an important handover, explore timing in the context of your location, available dates and agreed deadlines.',prompt:'Sale, signing, registration or handover'},
    {id:'home',label:'Move into a home',short:'A place to begin',title:'A new home. A meaningful first step.',copy:'Explore timing for Griha Pravesh or moving into your space, with room for family arrangements and practical availability.',prompt:'Griha Pravesh, moving in or beginning in a new space'},
    {id:'travel',label:'Plan a journey',short:'A departure with intention',title:'Every journey has a first moment.',copy:'Discuss a departure or an important journey alongside your route, starting city and flexible dates. Share any fixed travel arrangements.',prompt:'Departure, travel or an important journey'},
    {id:'celebrate',label:'Mark an occasion',short:'A day to remember',title:'Make space for a meaningful occasion.',copy:'Planning a ceremony, family milestone or personal ritual? Share the occasion, the people involved and the dates that work for you.',prompt:'Ceremony, family milestone or personal ritual'}
  ];
  let selectedOccasion = occasions[0].id;
  const find = id => occasions.find(item => item.id === id) || occasions[0];

  function fields(id) {
    const occasion = find(id);
    return `<fieldset class="timing-form-fields full-width"><legend>Your plans <span>For Muhurta &amp; Panchanga</span></legend><div class="field"><label for="timing-occasion">What are you planning? *</label><select id="timing-occasion" name="timingOccasion" required>${occasions.map(item => `<option value="${item.id}"${item.id === occasion.id ? ' selected' : ''}>${item.label}</option>`).join('')}</select></div><div class="field"><label for="timing-location">Event city &amp; country *</label><input id="timing-location" name="timingLocation" maxlength="200" minlength="2" placeholder="e.g. Jaipur, India" required><small>Where the occasion will take place, or the starting city for travel.</small></div><div class="field"><label for="timing-dates">Date range &amp; flexibility *</label><input id="timing-dates" name="timingDates" maxlength="250" minlength="3" placeholder="e.g. 5–20 December; weekends preferred" required></div><div class="field"><label for="timing-constraints">Fixed arrangements <span>(optional)</span></label><textarea id="timing-constraints" name="timingConstraints" rows="2" maxlength="600" placeholder="Any deadlines, booked dates, preferred hours or other constraints?"></textarea></div><p>These are dates for your occasion. The preferred consultation date below is a separate request.</p></fieldset>`;
  }

  function appendToMessage(data, lines) {
    const rawId = String(data.get('timingOccasion') || '');
    const occasion = occasions.find(item => item.id === rawId);
    if (occasion) lines.push(`Occasion: ${occasion.label}`);
    for (const [key,label] of [['timingLocation','Event location'],['timingDates','Event date range / flexibility'],['timingConstraints','Fixed arrangements']]) {
      const value = String(data.get(key) || '').trim();
      if (value) lines.push(`${label}: ${value}`);
    }
  }

  function select(id) {
    const occasion = find(id);
    selectedOccasion = occasion.id;
    document.querySelectorAll('[data-timing-select]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.timingSelect === occasion.id)));
    document.querySelector('#timing-title').textContent = occasion.title;
    document.querySelector('#timing-copy').textContent = occasion.copy;
    document.querySelector('#timing-orbit-label').textContent = occasion.short;
    document.querySelector('#timing-enquire').dataset.timingOccasion = occasion.id;
    document.querySelector('#timing-status').textContent = `${occasion.label} selected. Chandra Kala · Muhurta & Panchanga, ₹1,100.`;
  }

  window.LunicTiming = {fields,appendToMessage,selected:()=>selectedOccasion};
  document.querySelector('#timing-occasions').addEventListener('click',event => {
    const button = event.target.closest('[data-timing-select]');
    if (button) select(button.dataset.timingSelect);
  });
})();
