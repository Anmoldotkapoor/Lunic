'use strict';

(() => {
  const order = ['prashna', 'crescent', 'moonrise', 'purnima', 'tarot', 'reserve'];
  const stories = {
    prashna: {
      phase: 'The first spark', method: 'Prashna / Muhurta', short: 'One question',
      line: 'One question. A thoughtful place to begin.',
      best: 'A specific question, or choosing a meaningful time for a new beginning.',
      inside: ['A focused conversation around one question or occasion.', 'Explore Prashna or Muhurta with your personal context in mind.'],
      prepare: ['Bring one clear question, or the occasion you’re planning.', 'Share relevant dates and context. We’ll confirm any other details needed.'],
      reflection: 'What would I most like to understand before taking my next step?',
      orbit: 'A single intention. A little more light.'
    },
    crescent: {
      phase: 'The first light', method: 'Jyotish / Birth chart', short: 'A first reading',
      line: 'A little perspective can change how a chapter feels.',
      best: 'Your first birth-chart reading, with room for one area of life.',
      inside: ['Explore one life area through the lens of your birth chart.', 'A 15-minute conversation shaped around your question and personal context.'],
      prepare: ['Have your birth date, birth time and birthplace ready.', 'Choose one priority. Let us know if your birth time is approximate.'],
      reflection: 'Which part of my life would benefit from a fresh perspective?',
      orbit: 'Small beginnings hold their own light.'
    },
    moonrise: {
      phase: 'The unfolding', method: 'Jyotish / Connected themes', short: 'Go a little deeper',
      line: 'Give the questions beneath your questions a little space.',
      best: 'Connecting related life themes and exploring the timing of your current chapter.',
      inside: ['Explore connected chart patterns and current dashas.', 'A 30-minute conversation for the themes shaping your next chapter.'],
      prepare: ['Bring your birth date, birth time and birthplace.', 'Note two or three related themes you’d like to connect.'],
      reflection: 'How do the different parts of my life connect in this chapter?',
      orbit: 'More room for the patterns to emerge.'
    },
    purnima: {
      phase: 'The fuller picture', method: 'Jyotish / In-depth reading', short: 'See the whole',
      line: 'Step back. Make room for the fullness of your story.',
      best: 'A broader look at your chart, planetary periods and personal priorities.',
      inside: ['Explore your birth chart and planetary periods in greater depth.', 'A 45-minute conversation with space for your wider priorities.'],
      prepare: ['Bring your birth date, birth time and birthplace.', 'Write down your main priorities and the context you’d like to share.'],
      reflection: 'What deserves my attention as I look at the bigger picture?',
      orbit: 'Your story, with room to unfold.'
    },
    tarot: {
      phase: 'The inner mirror', method: 'Tarot / Symbolic reflection', short: 'Let the cards speak',
      line: 'A conversation with the cards. A moment with yourself.',
      best: 'Exploring a question through card symbolism and personal reflection.',
      inside: ['A personal, 30-minute Tarot reading centred on your questions.', 'Explore the cards’ symbolism in the context of your present circumstances.'],
      prepare: ['Bring the questions or themes you’d like to explore. Birth details aren’t required.', 'Set aside 30 minutes. Your preferred appointment time is confirmed when you inquire.'],
      reflection: 'What might a different perspective help me notice right now?',
      orbit: 'Symbol. Story. A new perspective.'
    },
    reserve: {
      phase: 'The private orbit', method: 'Soma Reserve / VIP', short: 'Private · VIP',
      line: 'Some chapters deserve a conversation of their own.',
      best: 'A personally shaped Jyotish consultation for the life themes and interconnected questions that matter most to you.',
      inside: ['Begin with your priorities: share the questions you want to give your fullest attention.', 'Explore your birth chart, planetary periods and connected life themes in a dedicated conversation.', 'Agree the scope, session duration and appointment personally before confirming.'],
      prepare: ['Share your birth date, time and place, marking anything estimated or unknown.', 'Tell us which life themes deserve the most space. We’ll shape the session arrangements with you.'],
      reflection: 'What deserves a deeper, more considered conversation in this chapter of my life?',
      orbit: 'A private space. A perspective of your own.'
    }
  };
  const themes = [
    {id: 'career', label: 'Career & purpose'},
    {id: 'relationships', label: 'Relationships'},
    {id: 'self', label: 'Self & direction'},
    {id: 'beginnings', label: 'New beginnings'}
  ];
  const questions = {
    career: {
      prashna: 'What should I bring to a Prashna reading about my next career step?',
      crescent: 'What can my birth chart help me reflect on about my work and direction?',
      moonrise: 'How might my chart and current dashas relate to this career transition?',
      purnima: 'How can I explore my career priorities within the wider picture of my chart?',
      tarot: 'What could I notice about the way I’m approaching my next career chapter?',
      reserve: 'How can we explore my career, purpose and current planetary periods as one connected conversation?'
    },
    relationships: {
      prashna: 'How can I frame one meaningful question about a relationship?',
      crescent: 'Which relationship patterns could I explore through my birth chart?',
      moonrise: 'How do my relationship questions connect with other themes in my chart?',
      purnima: 'What could a wider reading help me reflect on about relationships and my priorities?',
      tarot: 'What perspective could help me bring more understanding to a relationship?',
      reserve: 'How do my relationship questions connect with the wider priorities and patterns in my chart?'
    },
    self: {
      prashna: 'What is the one question I most want to understand about my next step?',
      crescent: 'What could my chart help me notice about my sense of direction?',
      moonrise: 'Which connected themes in my chart feel most relevant to this chapter?',
      purnima: 'How can I explore my personal priorities through a fuller reading of my chart?',
      tarot: 'What am I ready to notice about myself and the choices in front of me?',
      reserve: 'Which interconnected life themes deserve a private, in-depth exploration through my chart?'
    },
    beginnings: {
      prashna: 'What details should I share for Muhurta guidance for my new beginning?',
      crescent: 'What could a first chart reading help me reflect on as I begin again?',
      moonrise: 'How can I explore my current dashas in the context of a new chapter?',
      purnima: 'How does this new beginning sit within the wider themes of my chart?',
      tarot: 'What would help me approach a new beginning with more intention?',
      reserve: 'How can we explore this new beginning within the fuller context of my chart, timing and personal priorities?'
    }
  };
  const intentionPlans = {timing: 'prashna', direction: 'crescent', deeper: 'moonrise', reflection: 'tarot', private:'reserve'};
  const intentionCopy = {
    timing: 'For a new beginning, start with a focused question. Chandra Prashna is a thoughtful fit.',
    direction: 'For one area of life, begin gently. Crescent offers a personal introduction.',
    deeper: 'For connected questions, give yourself more room. Explore Moonrise.',
    reflection: 'For reflection through the cards, explore the Lunar Tarot experience.',
    private: 'For a conversation shaped around your priorities, enter the private orbit of Soma Reserve.'
  };
  let activeReading = 'crescent';
  let activeNotes = 'inside';
  let activeTheme = null;
  let lastIntention = 'all';
  const studio = document.querySelector('#consultation-grid');
  const mobileBar = document.querySelector('#reading-mobile-bookbar');
  let barQueued = false;

  const planById = id => consultations.find(plan => plan.id === id);
  const currentQuestion = () => activeTheme ? questions[activeTheme][activeReading] : stories[activeReading].reflection;
  const inquiryPrompt = () => activeTheme ? currentQuestion() : '';
  const timeLabel = plan => plan.duration;

  function revealSelectedPhase() {
    if (!window.matchMedia('(max-width:700px)').matches) return;
    const rail = studio.querySelector('.reading-phase-rail');
    const tab = studio.querySelector(`[data-reading-select="${activeReading}"]`);
    const tabLeft = tab.getBoundingClientRect().left - rail.getBoundingClientRect().left + rail.scrollLeft;
    rail.scrollTo({left:tabLeft - (rail.clientWidth - tab.clientWidth) / 2, behavior:'auto'});
  }

  function paintGuidance() {
    const guidance = document.querySelector('#intention-insight');
    guidance.textContent = intentionCopy[selectedIntention] || 'Six readings. Different intentions. Choose the one that feels like your next step.';
    guidance.classList.toggle('has-recommendation', selectedIntention !== 'all');
  }

  function paintQuestion() {
    document.querySelector('#reading-question').textContent = `“${currentQuestion()}”`;
    document.querySelector('#reading-question-label').textContent = activeTheme ? 'YOUR OPENING QUESTION' : 'A QUESTION TO BEGIN WITH';
    document.querySelectorAll('[data-reading-theme]').forEach(button => {
      const selected = button.dataset.readingTheme === activeTheme;
      button.setAttribute('aria-pressed', String(selected));
    });
    [studio.querySelector('[data-plan]'), mobileBar.querySelector('[data-plan]')].forEach(book => {
      if (book) book.dataset.readingPrompt = inquiryPrompt();
    });
    document.querySelector('#reading-question-note').textContent = activeTheme
      ? 'We’ll add this question to your enquiry. You can make it your own before sending.'
      : 'Choose a theme above to shape a question. Bring your own words to the conversation.';
  }

  function paintNotes() {
    const notes = stories[activeReading][activeNotes];
    document.querySelector('#reading-notes').innerHTML = notes.map(note => `<li>${icon('check')}<span>${note}</span></li>`).join('');
    document.querySelector('#reading-notes').setAttribute('aria-labelledby', `reading-notes-${activeNotes}`);
    studio.querySelectorAll('[data-reading-notes]').forEach(button => {
      const selected = button.dataset.readingNotes === activeNotes;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
    });
  }

  function paintReading(withMotion = true) {
    const plan = planById(activeReading);
    const story = stories[activeReading];
    const index = order.indexOf(activeReading);
    studio.querySelector('#reading-phase-count').textContent = `0${index + 1} / ${String(order.length).padStart(2,'0')}`;
    studio.querySelectorAll('[data-reading-select]').forEach(button => {
      const selected = button.dataset.readingSelect === activeReading;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
    });
    const panel = studio.querySelector('#reading-panel');
    panel.setAttribute('aria-labelledby', `reading-tab-${activeReading}`);
    panel.dataset.reading = activeReading;
    panel.innerHTML = `
      <div class="reading-cosmos" aria-hidden="true">
        <div class="cosmos-caption"><span>${plan.vip ? 'LUNIC / THE PRIVATE CONSULTATION' : `0${index + 1} / THE LUNAR READINGS`}</span><span>✦</span></div>
        <div class="reading-moon-scene">
          <div class="reading-orbit orbit-outer"></div><div class="reading-orbit orbit-inner"></div>
          <i class="cosmos-star star-one">✦</i><i class="cosmos-star star-two">✧</i><i class="cosmos-star star-three">·</i>
          ${plan.vip ? '<div class="reserve-corona"></div><div class="reserve-seal"><span class="reserve-seal-top">SOMA RESERVE</span><span class="reserve-monogram">S<span>R</span></span><span class="reserve-seal-bottom">THE PRIVATE ORBIT</span></div>' : plan.id === 'tarot' ? '<div class="reading-deck"><div class="celestial-card card-back">✧</div><div class="celestial-card card-middle">☼</div><div class="celestial-card card-front"><span>☾</span><small>THE INNER MIRROR</small></div></div>' : `<div class="reading-orb ${plan.moon}"><span></span></div>`}
          <span class="cosmos-coordinate coordinate-left">INTENTION</span><span class="cosmos-coordinate coordinate-right">PERSPECTIVE</span>
        </div>
        <div class="cosmos-footer"><span>${story.phase}</span><p>${story.orbit}</p><div class="cosmos-dots">${order.map(id => `<i class="${id === activeReading ? 'active' : ''}"></i>`).join('')}</div></div>
      </div>
      <div class="reading-copy">
        ${plan.vip ? '<div class="reserve-kicker"><span>✦</span> LUNIC / PRIVATE CLIENT</div>' : ''}
        <div class="reading-meta"><span>${story.method}</span><span class="reading-time">${timeLabel(plan)}</span></div>
        <div class="reading-title-row"><h3>${plan.name}</h3><span aria-hidden="true">↗</span></div>
        <p class="reading-lead">${story.line}</p>
        <p class="reading-best"><span>A LITTLE SPACE FOR</span>${story.best}</p>
        <div class="reading-note-tabs" role="tablist" aria-label="About ${plan.name}">
          <button role="tab" id="reading-notes-inside" data-reading-notes="inside" aria-controls="reading-notes" aria-selected="true">Inside your reading</button>
          <button role="tab" id="reading-notes-prepare" data-reading-notes="prepare" aria-controls="reading-notes" aria-selected="false" tabindex="-1">What to bring</button>
        </div>
        <ul id="reading-notes" class="reading-notes" role="tabpanel" tabindex="0"></ul>
        <div class="reading-reserve"><div class="reading-fee"><strong>${money(plan.price)}</strong><span>${plan.vip ? 'private consultation' : 'per consultation'}</span></div><button class="button reading-book" data-plan="${plan.id}" data-reading-prompt="${escapeHtml(inquiryPrompt())}">${plan.vip ? 'Request a private appointment' : `Enquire about ${plan.name}`} ${icon('arrow')}</button></div>
        <p class="reading-book-note">${plan.vip ? 'Your scope, duration and appointment are agreed personally. Begin with an enquiry.' : 'Pick a preferred time. We’ll confirm the details personally on WhatsApp.'}</p>
      </div>`;
    const ritual = studio.querySelector('#reserve-experience');
    ritual.hidden = !plan.vip;
    mobileBar.classList.toggle('is-reserve', Boolean(plan.vip));
    paintNotes();
    paintQuestion();
    mobileBar.querySelector('strong').textContent = plan.name;
    mobileBar.querySelector('.mobile-reading-price').textContent = money(plan.price);
    mobileBar.querySelector('[data-plan]').dataset.plan = plan.id;
    mobileBar.querySelector('[data-plan]').setAttribute('aria-label', `Enquire about ${plan.name}, ${money(plan.price)}`);
    document.querySelector('#reading-selection-status').textContent = `${plan.name} selected. ${money(plan.price)}. ${timeLabel(plan)}.`;
    if (withMotion) window.LunicExperience?.animateGrid(panel);
    queueBarUpdate();
  }

  function selectReading(id, {preserveIntention = false, withMotion = true} = {}) {
    if (!order.includes(id)) return;
    if (!preserveIntention) {
      selectedIntention = 'all';
      lastIntention = 'all';
      document.querySelectorAll('[data-intention]').forEach(button => {
        const selected = button.dataset.intention === 'all';
        button.classList.toggle('active', selected);
        button.setAttribute('aria-pressed', String(selected));
      });
    }
    activeReading = id;
    activeNotes = 'inside';
    paintGuidance();
    paintReading(withMotion);
    revealSelectedPhase();
  }

  function render() {
    if (!studio.querySelector('#reading-panel')) {
      studio.innerHTML = `<div class="reading-mobile-hint"><span>SWIPE TO EXPLORE THE PHASES →</span><span id="reading-phase-count">02 / ${String(order.length).padStart(2,'0')}</span></div><div class="reading-phase-rail" role="tablist" aria-label="Explore the six Lunic readings">${order.map((id, index) => {
        const plan = planById(id);
        return `<button class="reading-choice${plan.vip ? ' reserve-choice' : ''}" role="tab" id="reading-tab-${id}" data-reading-select="${id}" aria-controls="reading-panel" aria-selected="${id === activeReading}" tabindex="${id === activeReading ? '0' : '-1'}"><span class="reading-choice-top"><span>0${index + 1} / ${stories[id].short}</span><span class="card-moon ${plan.moon}" aria-hidden="true"></span></span><strong>${plan.name}</strong><span class="reading-choice-bottom">${money(plan.price)}<span aria-hidden="true">↗</span></span></button>`;
      }).join('')}</div><div id="reading-panel" class="reading-panel" role="tabpanel"></div><div class="reserve-experience" id="reserve-experience" hidden><div><span>01 / THE INTENTION</span><h4>Begin with your story.</h4><p>Share your priorities and birth details, with space to explain what matters.</p></div><div><span>02 / THE CONVERSATION</span><h4>Explore your own constellation.</h4><p>Your chart, planetary periods and connected questions, considered together.</p></div><div><span>03 / THE REFLECTION</span><h4>Bring it back to your life.</h4><p>Consider the perspective alongside your own judgment and lived experience.</p></div></div><p id="reading-selection-status" class="sr-only" role="status" aria-live="polite"></p>`;
    }
    const intentionChanged = lastIntention !== selectedIntention;
    if (intentionChanged) {
      activeReading = intentionPlans[selectedIntention] || activeReading;
      activeNotes = 'inside';
      lastIntention = selectedIntention;
    }
    paintGuidance();
    paintReading(false);
    if (intentionChanged) revealSelectedPhase();
  }

  function showComparison() {
    openDialog(`<div class="dialog-content-padded comparison-dialog"><div class="dialog-eyebrow">SIX WAYS TO FIND YOUR LIGHT</div><h2>A reading for<br><em>your kind of question.</em></h2><p class="dialog-description">Compare the approach, time and fee. Every reading is a personal, one-to-one conversation.</p><div class="reading-compare-grid">${order.map(id => {
      const plan = planById(id);
      const story = stories[id];
      return `<article class="reading-compare-card${plan.vip ? ' reserve-compare' : ''}${id === activeReading ? ' is-current' : ''}"><div class="compare-card-top"><div class="card-moon ${plan.moon}" aria-hidden="true"></div><span>${plan.vip ? 'PRIVATE / VIP' : id === activeReading ? 'YOUR SELECTION' : story.method.split(' / ')[0]}</span></div><h3>${plan.name}</h3><p class="compare-time">${timeLabel(plan)}</p><p>${story.best}</p><div class="compare-card-bottom"><strong>${money(plan.price)}</strong><button data-plan="${id}" aria-label="Enquire about ${plan.name}, ${money(plan.price)}">${plan.vip ? 'Request appointment' : 'Enquire'} ${icon('arrow')}</button></div></article>`;
    }).join('')}</div><p class="compare-footnote">Appointments are confirmed personally; no payment is taken on this site.</p></div>`, 'Compare Lunic readings');
  }

  function updateMobileBar() {
    barQueued = false;
    const section = document.querySelector('#consultations').getBoundingClientRect();
    const panel = studio.querySelector('#reading-panel').getBoundingClientRect();
    const book = studio.querySelector('.reading-book').getBoundingClientRect();
    const bookVisible = book.top >= 80 && book.bottom <= innerHeight - 16;
    const show = window.matchMedia('(max-width:700px)').matches && section.top < 100 && section.bottom > 170 && panel.top < innerHeight - 140 && !bookVisible;
    mobileBar.hidden = !show;
    document.body.classList.toggle('reading-bar-visible', show);
  }

  function queueBarUpdate() {
    if (!barQueued) { barQueued = true; requestAnimationFrame(updateMobileBar); }
  }
  window.addEventListener('scroll', queueBarUpdate, {passive:true});
  window.addEventListener('resize', queueBarUpdate);

  document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.readingSelect) selectReading(button.dataset.readingSelect);
    if (button.dataset.readingNotes) { activeNotes = button.dataset.readingNotes; paintNotes(); }
    if (button.dataset.readingTheme) {
      activeTheme = activeTheme === button.dataset.readingTheme ? null : button.dataset.readingTheme;
      paintQuestion();
    }
    if (button.dataset.action === 'compare-readings') showComparison();
    if (button.dataset.action === 'explore-reserve') {
      selectReading('reserve');
      studio.querySelector('#reading-panel').scrollIntoView({block:'start',behavior:document.body.dataset.motion === 'on' ? 'smooth' : 'auto'});
    }
  });

  document.addEventListener('keydown', event => {
    const button = event.target.closest('[data-reading-select], [data-reading-notes]');
    if (!button || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const isReading = Boolean(button.dataset.readingSelect);
    const options = isReading ? order : ['inside', 'prepare'];
    let index = options.indexOf(isReading ? activeReading : activeNotes);
    index = event.key === 'Home' ? 0 : event.key === 'End' ? options.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + options.length) % options.length;
    if (isReading) selectReading(options[index]);
    else { activeNotes = options[index]; paintNotes(); }
    document.querySelector(`[data-reading-${isReading ? 'select' : 'notes'}="${options[index]}"]`).focus({preventScroll: true});
  });

  window.LunicReadings = {render, select: selectReading};
  render();
})();
