'use strict';

// Concept catalog. Availability, actual stone specifications and prices are confirmed on inquiry.
// Traditional Navaratna associations: https://www.gia.edu/gia-website/jewels-of-india
window.LUNIC_GEMSTONES = [
  {
    id: 'ruby', name: 'Ruby', vernacular: 'Manik', series: 'navaratna',
    planet: 'Surya · Sun', categoryLabel: 'SURYA · SUN', tag: 'NAVARATNA',
    aliases: ['manikya', 'manikyam', 'surya', 'sun', 'माणिक्य', 'माणिक'],
    image: 'gemstones/ruby.webp',
    subtitle: 'A luminous expression of the Sun.',
    description: 'A richly coloured ruby, envisioned in an elegant oval cut. Known as Manik in the Vedic gemstone tradition, ruby is the Navaratna gem associated with Surya, the Sun.',
    details: ['Manik', 'Ruby · Corundum', 'Sun · Surya'],
    tradition: 'Explore ruby through its traditional solar symbolism. Your inquiry can include preferred colour, cut, carat weight and a conversation about its relevance to your personal chart.'
  },
  {
    id: 'pearl', name: 'Pearl', vernacular: 'Moti', series: 'navaratna',
    planet: 'Chandra · Moon', categoryLabel: 'CHANDRA · MOON', tag: 'NAVARATNA',
    aliases: ['chandra pearl', 'mukta', 'moti', 'moon', 'मोती', 'चन्द्र'],
    image: 'pearl.webp',
    subtitle: 'The quiet luminosity of Chandra.',
    description: 'A softly luminous pearl, traditionally known as Moti and associated with Chandra, the Moon. Its gentle nacre makes it a natural expression of Lunic’s lunar world.',
    details: ['Moti', 'Pearl', 'Moon · Chandra'],
    tradition: 'Pearl is one of the nine Navaratna gems. Ask about the available pearl’s type, origin, size and lustre, alongside personal guidance on its traditional astrological use.'
  },
  {
    id: 'red-coral', name: 'Red Coral', vernacular: 'Moonga', series: 'navaratna',
    planet: 'Mangal · Mars', categoryLabel: 'MANGAL · MARS', tag: 'NAVARATNA',
    aliases: ['munga', 'moonga', 'mangala', 'vidruma', 'mars', 'मूंगा', 'मंगल'],
    image: 'gemstones/red-coral.webp',
    subtitle: 'A warm vermilion connection to Mangal.',
    description: 'A smooth, domed red coral cabochon in a warm vermilion hue. Moonga occupies the place of Mangal, or Mars, in the traditional Navaratna collection.',
    details: ['Moonga', 'Polished cabochon', 'Mars · Mangal'],
    tradition: 'Discuss the traditional meaning of Moonga and ask about material identity, provenance, finish and availability when making your personal inquiry.'
  },
  {
    id: 'emerald', name: 'Emerald', vernacular: 'Panna', series: 'navaratna',
    planet: 'Budha · Mercury', categoryLabel: 'BUDHA · MERCURY', tag: 'NAVARATNA',
    aliases: ['panna', 'marakata', 'mercury', 'budh', 'पन्ना', 'बुध'],
    image: 'gemstones/emerald.webp',
    subtitle: 'Budha’s green gem, thoughtfully chosen.',
    description: 'A deep green emerald with architectural step-cut facets. Known as Panna, this member of the beryl family is traditionally associated with Budha, or Mercury.',
    details: ['Panna', 'Emerald · Beryl', 'Mercury · Budha'],
    tradition: 'Explore Panna’s place in the Navaratna tradition. Ask about the actual stone’s colour, inclusions, treatment disclosure, cut and any available gemological report.'
  },
  {
    id: 'yellow-sapphire', name: 'Yellow Sapphire', vernacular: 'Pukhraj', series: 'navaratna',
    planet: 'Guru · Jupiter', categoryLabel: 'GURU · JUPITER', tag: 'NAVARATNA',
    aliases: ['pukhraj', 'pushparaga', 'brihaspati', 'guru', 'jupiter', 'पुखराज', 'बृहस्पति'],
    image: 'gemstones/yellow-sapphire.webp',
    subtitle: 'Golden light, in the tradition of Guru.',
    description: 'A golden yellow sapphire envisioned in a luminous oval cut. Pukhraj is the traditional Navaratna stone of Guru, also called Brihaspati or Jupiter.',
    details: ['Pukhraj', 'Sapphire · Corundum', 'Jupiter · Guru'],
    tradition: 'Bring your questions about Pukhraj to a personal conversation. The available stone’s shade, carat weight, treatment details and pricing can be discussed on inquiry.'
  },
  {
    id: 'diamond', name: 'Diamond', vernacular: 'Heera', series: 'navaratna',
    planet: 'Shukra · Venus', categoryLabel: 'SHUKRA · VENUS', tag: 'NAVARATNA',
    aliases: ['heera', 'hira', 'vajra', 'shukra', 'venus', 'हीरा', 'शुक्र'],
    image: 'gemstones/diamond.webp',
    subtitle: 'Shukra’s gem of clear brilliance.',
    description: 'A round brilliant diamond with a crisp play of light. Traditionally called Heera or Vajra, diamond represents Shukra, or Venus, in the nine-gem tradition.',
    details: ['Heera', 'Round brilliant concept', 'Venus · Shukra'],
    tradition: 'A personal selection can take account of your intended use, preferred cut and budget. Ask about natural or laboratory-grown origin, specifications and any independent report for the actual stone.'
  },
  {
    id: 'blue-sapphire', name: 'Blue Sapphire', vernacular: 'Neelam', series: 'navaratna',
    planet: 'Shani · Saturn', categoryLabel: 'SHANI · SATURN', tag: 'NAVARATNA',
    aliases: ['neelam', 'nilam', 'indraneel', 'shani', 'saturn', 'नीलम', 'शनि'],
    image: 'gemstones/blue-sapphire.webp',
    subtitle: 'Deep blue, in the tradition of Shani.',
    description: 'A royal blue sapphire with a softly squared cushion silhouette. Neelam is the traditional Navaratna gem associated with Shani, or Saturn.',
    details: ['Neelam', 'Sapphire · Corundum', 'Saturn · Shani'],
    tradition: 'Explore Neelam in the context of your own chart and intentions. Ask about the available stone’s colour, cut, origin, treatment disclosure and report details.'
  },
  {
    id: 'hessonite', name: 'Hessonite', vernacular: 'Gomed', series: 'navaratna',
    planet: 'Rahu · North lunar node', categoryLabel: 'RAHU · NORTH LUNAR NODE', tag: 'NAVARATNA',
    aliases: ['gomed', 'gomeda', 'gomedh', 'rahu', 'north node', 'गोमेद', 'राहु'],
    image: 'gemstones/hessonite.webp',
    subtitle: 'Honeyed light, traditionally linked with Rahu.',
    description: 'A honey-cinnamon hessonite garnet, with warm amber depths and softly glowing facets. Gomed is the Navaratna stone associated with Rahu, the north lunar node.',
    details: ['Gomed', 'Hessonite · Garnet', 'Rahu · North lunar node'],
    tradition: 'Discover Gomed’s traditional symbolism through a personal consultation. Availability, actual colour, clarity, cut and gemological identification can be discussed on inquiry.'
  },
  {
    id: 'cats-eye', name: 'Cat’s Eye', vernacular: 'Lehsunia', series: 'navaratna',
    planet: 'Ketu · South lunar node', categoryLabel: 'KETU · SOUTH LUNAR NODE', tag: 'NAVARATNA',
    aliases: ['cats eye', 'cat eye', "cat's eye", 'lehsuniya', 'lahsuniya', 'vaidurya', 'chrysoberyl', 'ketu', 'south node', 'लहसुनिया', 'केतु'],
    image: 'gemstones/cats-eye.webp',
    subtitle: 'An unmistakable line of light.',
    description: 'A chrysoberyl cat’s-eye cabochon, distinguished by a narrow band of reflected light across its domed surface. Known as Lehsunia, it is the Navaratna gem traditionally associated with Ketu.',
    details: ['Lehsunia', 'Cat’s-eye · Chrysoberyl', 'Ketu · South lunar node'],
    tradition: 'Ask about the identity of the cat’s-eye material, its colour, the character of its chatoyant band and the actual piece available, alongside guidance on its traditional use.'
  },
  {
    id: 'white-sapphire', name: 'White Sapphire', vernacular: 'Safed Pukhraj', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'COLOURLESS CORUNDUM',
    aliases: ['safed pukhraj', 'white pukhraj', 'colorless sapphire', 'colourless sapphire', 'shukra', 'venus', 'सफेद पुखराज'],
    image: 'gemstones/white-sapphire.webp',
    subtitle: 'A quieter kind of brilliance.',
    description: 'An oval white sapphire with cool, clear facets and restrained silver-white reflections. A considered choice for someone drawn to colourless gemstones and a subtle play of light.',
    details: ['Safed Pukhraj', 'Sapphire · Corundum', 'Companion gemstone'],
    tradition: 'White sapphire is discussed as a companion to Venus-associated gems in some Jyotish traditions. Explore its material character and personal relevance in your inquiry.'
  },
  {
    id: 'opal', name: 'Opal', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'PLAY OF COLOUR',
    aliases: ['white opal', 'fire colours', 'play of color', 'play of colour', 'ओपल'],
    image: 'gemstones/opal.webp',
    subtitle: 'A small universe of shifting colour.',
    description: 'A milky opal cabochon with delicate flashes of colour that change with the light. Its gentle iridescence makes each actual stone a distinctly personal selection.',
    details: ['Opal', 'Cabochon concept', 'Companion gemstone'],
    tradition: 'Choose for its beauty and the meaning it holds for you. Ask about the actual opal’s type, origin, colour pattern, care and availability.'
  },
  {
    id: 'citrine', name: 'Citrine', vernacular: 'Sunela', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'GOLDEN QUARTZ',
    aliases: ['sunela', 'yellow quartz', 'golden quartz', 'सुनेला'],
    image: 'gemstones/citrine.webp',
    subtitle: 'A little golden warmth, held in stone.',
    description: 'A cushion-cut citrine with honey-gold colour and broad, luminous quartz facets. A warm addition to a personal gemstone collection or an intentionally chosen piece of jewellery.',
    details: ['Sunela', 'Citrine · Quartz', 'Companion gemstone'],
    tradition: 'Discuss its colour, size, cut and any treatment information when choosing an actual piece. Personal astrological guidance is available separately on inquiry.'
  },
  {
    id: 'peridot', name: 'Peridot', vernacular: 'Zabarjad', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'OLIVE-GREEN LIGHT',
    aliases: ['zabarjad', 'olivine', 'green peridot', 'जबरजद'],
    image: 'gemstones/peridot.webp',
    subtitle: 'Fresh green, with a golden undertone.',
    description: 'A pear-shaped peridot with lively olive-green colour and a gentle golden undertone. Its distinctive shade brings a fresh expression to the companion gemstone edit.',
    details: ['Zabarjad', 'Peridot · Olivine', 'Companion gemstone'],
    tradition: 'A personal inquiry can explore the actual stone’s hue, proportions, carat weight and available setting options, along with any questions about traditional use.'
  },
  {
    id: 'red-garnet', name: 'Red Garnet', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'DEEP WINE RED',
    aliases: ['garnet', 'wine red', 'garnet stone', 'गार्नेट'],
    image: 'gemstones/red-garnet.webp',
    subtitle: 'Rich colour. A grounded presence.',
    description: 'A deep wine-red garnet with glowing burgundy edges and precise cushion-cut facets. An expressive choice for someone drawn to rich colour and a quieter, darker brilliance.',
    details: ['Red garnet', 'Cushion-cut concept', 'Companion gemstone'],
    tradition: 'Explore the garnet variety, colour and actual piece available through a personal inquiry. Traditional gemstone selections can also be discussed during a consultation.'
  },
  {
    id: 'blue-topaz', name: 'Blue Topaz', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'SKY-BLUE CLARITY',
    aliases: ['sky blue topaz', 'topaz', 'blue topaz stone', 'नीला टोपाज'],
    image: 'gemstones/blue-topaz.webp',
    subtitle: 'A clear-sky colour, close at hand.',
    description: 'A pear-cut blue topaz with pale sky-blue colour and crisp reflections. A light, airy expression within the companion gemstone collection.',
    details: ['Blue topaz', 'Pear-cut concept', 'Companion gemstone'],
    tradition: 'Ask about the shade, treatment disclosure, dimensions and care of the actual gemstone. Choose the colour and form that feels relevant to your collection.'
  },
  {
    id: 'turquoise', name: 'Turquoise', vernacular: 'Firoza', series: 'companion',
    categoryLabel: 'THE COMPANION EDIT', tag: 'EARTH & SKY',
    aliases: ['firoza', 'feroza', 'turquoise stone', 'फिरोजा', 'फिरोज़ा'],
    image: 'gemstones/turquoise.webp',
    subtitle: 'Blue-green colour, shaped by the earth.',
    description: 'An oval turquoise cabochon with blue-green colour and a delicate web of dark matrix. Known as Firoza, it brings an earthy, distinctly individual character to the collection.',
    details: ['Firoza', 'Turquoise cabochon', 'Companion gemstone'],
    tradition: 'Ask about the actual stone’s matrix pattern, material identity, stabilisation or other treatment, dimensions and availability when making your selection.'
  }
].map(stone => ({category: 'gemstones', ...stone}));
