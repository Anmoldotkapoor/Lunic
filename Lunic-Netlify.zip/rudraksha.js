'use strict';

// Concept selections. Origin, mukhi count and natural formation are verified on the actual bead.
// Background: https://www.himalayanacademy.com/wp-content/uploads/2025/02/1997-mar-insight-tulsi-and-rudraksha.pdf
window.LUNIC_RUDRAKSHA = (() => {
  const origins = [
    {id:'nepali', label:'Nepali', place:'Nepal', character:'A deeply textured, earthy brown concept with a sculptural, rugged surface.'},
    {id:'java', label:'Java', place:'Java · Indonesia', character:'A compact, warm brown concept with a finer, closely textured surface.'}
  ];
  const names = [
    ['Ek Mukhi','One face','एकमुखी'],
    ['Dwi Mukhi','Two faces','द्विमुखी'],
    ['Tri Mukhi','Three faces','त्रिमुखी'],
    ['Chatur Mukhi','Four faces','चतुर्मुखी'],
    ['Pancha Mukhi','Five faces','पंचमुखी'],
    ['Shat Mukhi','Six faces','षण्मुखी'],
    ['Sapta Mukhi','Seven faces','सप्तमुखी'],
    ['Ashta Mukhi','Eight faces','अष्टमुखी'],
    ['Nava Mukhi','Nine faces','नवमुखी'],
    ['Dasha Mukhi','Ten faces','दशमुखी'],
    ['Ekadasha Mukhi','Eleven faces','एकादशमुखी'],
    ['Dwadasha Mukhi','Twelve faces','द्वादशमुखी'],
    ['Trayodasha Mukhi','Thirteen faces','त्रयोदशमुखी'],
    ['Chaturdasha Mukhi','Fourteen faces','चतुर्दशमुखी'],
    ['Pancha Dasha Mukhi','Fifteen faces','पंद्रह मुखी'],
    ['Shodasha Mukhi','Sixteen faces','षोडशमुखी'],
    ['Sapta Dasha Mukhi','Seventeen faces','सत्रह मुखी'],
    ['Ashta Dasha Mukhi','Eighteen faces','अठारह मुखी'],
    ['Ekonavimshati Mukhi','Nineteen faces','उन्नीस मुखी'],
    ['Vimshati Mukhi','Twenty faces','बीस मुखी'],
    ['Ekavimshati Mukhi','Twenty-one faces','इक्कीस मुखी']
  ];
  const forms = [
    {id:'gauri-shankar', name:'Gauri Shankar', local:'Gowri Shankar', aliases:['gaurishankar','gowrishankar','gauri sankar','गौरी शंकर'], subtitle:'Two forms, naturally together.', description:'A concept of two Rudraksha seed lobes joined as one specimen. Explore the distinctive double form, its devotional context and the character of an actual piece.', detail:'Double joined form'},
    {id:'ganesh', name:'Ganesh', local:'Ganesha Rudraksha', aliases:['ganesha','ganapati','ganpati','गणेश'], subtitle:'A singular expression of nature.', description:'A Rudraksha concept with a trunk-like natural projection, the characteristic behind the name Ganesh. Every formation is individual; ask to view the contours of the actual bead.', detail:'Natural projection'},
    {id:'garbh-gauri', name:'Garbh Gauri', local:'Garbha Gauri', aliases:['garbha gauri','garbhgauri','गर्भ गौरी'], subtitle:'A small form, held by a larger one.', description:'A concept of a larger Rudraksha lobe naturally joined to a distinctly smaller lobe. Explore this unequal double form through photographs and the details of the actual specimen.', detail:'Unequal joined form'},
    {id:'trijuti', name:'Trijuti', local:'Tribhangi · Three joined forms', aliases:['tribhangi','trijuthi','three joined','brahma vishnu mahesh','त्रिजुटी'], subtitle:'Three forms. One natural composition.', description:'A concept of three Rudraksha seed lobes joined as one formation. Envisioned as a distinctive devotional object, with the actual joins, condition and specifications reviewed personally.', detail:'Triple joined form'}
  ];
  const tradition = 'Rudraksha is part of Shaiva devotional practice. Request all-around photographs, inspection of the natural lines or joins, dimensions, condition and any available identification report. Origin and classification are confirmed on the actual specimen.';
  const products = [];
  for (let mukhi = 1; mukhi <= 21; mukhi++) {
    for (const origin of origins) {
      const [local, faces, hindi] = names[mukhi - 1];
      products.push({
        id:`${origin.id}-${mukhi}-mukhi`,
        name:`${mukhi} Mukhi · ${origin.label}`,
        vernacular:`${local} · ${faces}`,
        category:'rudraksha', categoryLabel:`${origin.place.toUpperCase()} · RUDRAKSHA`,
        tag:`${mukhi} MUKHI`, series:'mukhi-rudraksha',
        origin:origin.id, originLabel:origin.label, mukhi, form:'bead',
        counterpartId:`${origin.id === 'nepali' ? 'java' : 'nepali'}-${mukhi}-mukhi`,
        aliases:['rudraksha','rudraksh','rudrakasha','rudrakshas','rudrakashas',origin.id === 'java' ? 'indonesian javanese' : 'nepalese',origin.place,local,faces,hindi,`${mukhi} faced`,`${mukhi} face`,`${mukhi} mukhi rudraksha`],
        image:`rudraksha/${origin.id}-${mukhi}-mukhi.webp`,
        subtitle:mukhi === 1 ? 'A considered, individual sourcing inquiry.' : `${faces}. A moment of quiet attention.`,
        description:mukhi === 1
          ? `An inquiry for a one-faced Rudraksha of requested ${origin.label} origin. The physical form, natural divisions and origin need assessment on a specific specimen. Discuss the actual piece and its identification before choosing.`
          : `Explore a ${mukhi} Mukhi Rudraksha selection of requested ${origin.label} origin. ${origin.character} Choose it as a contemplative object or discuss a bead for your personal devotional practice.`,
        details:[faces,`${origin.place} · requested origin`,'Loose-bead concept'],
        tradition
      });
    }
  }
  for (const form of forms) {
    for (const origin of origins) {
      products.push({
        id:`${origin.id}-${form.id}`,
        name:`${form.name} · ${origin.label}`, vernacular:form.local,
        category:'rudraksha', categoryLabel:`${origin.place.toUpperCase()} · RUDRAKSHA`,
        tag:'SPECIAL FORM', series:'special-rudraksha',
        origin:origin.id, originLabel:origin.label, mukhi:null, form:form.id,
        counterpartId:`${origin.id === 'nepali' ? 'java' : 'nepali'}-${form.id}`,
        aliases:['rudraksha','rudraksh','rudrakasha','special',origin.place,...form.aliases],
        image:`rudraksha/${origin.id}-${form.id}.webp`,
        subtitle:form.subtitle, description:`${form.description} This is an inquiry for requested ${origin.label} origin.`,
        details:[form.detail,`${origin.place} · requested origin`,'Individual specimen'],
        tradition
      });
    }
  }
  return products;
})();
