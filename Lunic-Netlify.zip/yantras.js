'use strict';

// AI concept catalog. Geometry, inscriptions, materials and preparation are confirmed on inquiry.
// Context: https://www.britishmuseum.org/collection/object/A_1940-0716-329
// Navagraha: https://old.ssvt.org/Deities/navagrahas.asp
window.LUNIC_YANTRAS = [
  {
    "id": "surya-yantra",
    "name": "Surya Yantra",
    "vernacular": "Aditya · Sun",
    "family": "planetary",
    "planet": "Surya · Sun",
    "aliases": [
      "aditya",
      "ravi",
      "sun",
      "सूर्य",
      "आदित्य"
    ],
    "image": "yantras/surya-yantra.webp",
    "subtitle": "A considered moment for your solar centre.",
    "description": "A copper-toned yantra concept dedicated to Surya, the Sun in Jyotish. Its warm finish and ordered geometry offer a focal point for a personal solar practice or a thoughtfully arranged altar.",
    "details": [
      "Surya · Sun",
      "Copper-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "chandra-yantra",
    "name": "Chandra Yantra",
    "vernacular": "Soma · Moon",
    "family": "planetary",
    "planet": "Chandra · Moon",
    "aliases": [
      "soma",
      "chand",
      "moon",
      "चंद्र",
      "चन्द्र",
      "सोम"
    ],
    "image": "chandra.webp",
    "subtitle": "Make space for your inner moon.",
    "description": "A warm copper-toned yantra concept dedicated to Chandra, the Moon. A quiet expression of Lunic’s lunar world, envisioned for a personal altar and a reflective moment in your day.",
    "details": [
      "Chandra · Moon",
      "Copper-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "mangal-yantra",
    "name": "Mangal Yantra",
    "vernacular": "Mangala · Mars",
    "family": "planetary",
    "planet": "Mangal · Mars",
    "aliases": [
      "mangala",
      "angaraka",
      "kuja",
      "mars",
      "मंगल",
      "मङ्गल"
    ],
    "image": "yantras/mangal-yantra.webp",
    "subtitle": "Bring attention to the way you act.",
    "description": "A red-copper yantra concept dedicated to Mangal, also known as Mangala or Angaraka. Explore its place in the Navagraha tradition and discuss how a planetary practice relates to your own birth chart.",
    "details": [
      "Mangal · Mars",
      "Red-copper concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "budha-yantra",
    "name": "Budha Yantra",
    "vernacular": "Budh · Mercury",
    "family": "planetary",
    "planet": "Budha · Mercury",
    "aliases": [
      "budh",
      "mercury",
      "बुध"
    ],
    "image": "yantras/budha-yantra.webp",
    "subtitle": "An invitation to thoughtful expression.",
    "description": "A finely engraved bronze-toned concept dedicated to Budha, Mercury in Jyotish. Designed as a considered addition to a sacred corner, with personal guidance available on its traditional context.",
    "details": [
      "Budha · Mercury",
      "Bronze-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "brihaspati-yantra",
    "name": "Brihaspati Yantra",
    "vernacular": "Guru · Jupiter",
    "family": "planetary",
    "planet": "Brihaspati · Jupiter",
    "aliases": [
      "guru",
      "brihaspathi",
      "jupiter",
      "बृहस्पति",
      "गुरु"
    ],
    "image": "yantras/brihaspati-yantra.webp",
    "subtitle": "A little room for a wider perspective.",
    "description": "A honey-gold yantra concept dedicated to Brihaspati, or Guru, the Jupiter graha. Its warm metal and measured geometry create a contemplative focal point for a personal devotional space.",
    "details": [
      "Guru · Jupiter",
      "Brass-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "shukra-yantra",
    "name": "Shukra Yantra",
    "vernacular": "Shukra · Venus",
    "family": "planetary",
    "planet": "Shukra · Venus",
    "aliases": [
      "sukra",
      "venus",
      "शुक्र"
    ],
    "image": "yantras/shukra-yantra.webp",
    "subtitle": "Find grace in the attention you give.",
    "description": "A softly luminous, gold-toned concept dedicated to Shukra, Venus in the Navagraha tradition. An elegant object to explore through its devotional meaning and its relevance to your personal practice.",
    "details": [
      "Shukra · Venus",
      "Gold-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "shani-yantra",
    "name": "Shani Yantra",
    "vernacular": "Shanidev · Saturn",
    "family": "planetary",
    "planet": "Shani · Saturn",
    "aliases": [
      "sani",
      "shanidev",
      "saturn",
      "शनि",
      "शनिदेव"
    ],
    "image": "yantras/shani-yantra.webp",
    "subtitle": "A quiet companion to patient practice.",
    "description": "An aged copper-toned yantra concept dedicated to Shani, Saturn in Jyotish. The darker patina and precise lines create a restrained, contemplative presence for a personal altar.",
    "details": [
      "Shani · Saturn",
      "Aged-copper concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "rahu-yantra",
    "name": "Rahu Yantra",
    "vernacular": "Rahu · North lunar node",
    "family": "planetary",
    "planet": "Rahu · North lunar node",
    "aliases": [
      "north node",
      "ascending node",
      "राहु"
    ],
    "image": "yantras/rahu-yantra.webp",
    "subtitle": "An invitation to look a little deeper.",
    "description": "A smoky bronze-toned yantra concept dedicated to Rahu, the ascending lunar node used in Jyotish. Explore this form with a conversation about the wider chart and the tradition behind a planetary practice.",
    "details": [
      "Rahu · Lunar node",
      "Bronze-tone concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "ketu-yantra",
    "name": "Ketu Yantra",
    "vernacular": "Ketu · South lunar node",
    "family": "planetary",
    "planet": "Ketu · South lunar node",
    "aliases": [
      "south node",
      "descending node",
      "केतु"
    ],
    "image": "yantras/ketu-yantra.webp",
    "subtitle": "A considered space for inward attention.",
    "description": "An antique brass-toned yantra concept dedicated to Ketu, the descending lunar node used in Jyotish. A contemplative object to choose with an understanding of its meaning and your personal practice.",
    "details": [
      "Ketu · Lunar node",
      "Antique-brass concept",
      "Navagraha collection"
    ]
  },
  {
    "id": "sri-yantra",
    "name": "Sri Yantra",
    "vernacular": "Shri Chakra · Tripura Sundari",
    "family": "devotional",
    "deity": "Lalita Tripura Sundari",
    "aliases": [
      "shree",
      "shri chakra",
      "sri chakra",
      "srichakra",
      "lalita",
      "tripura sundari",
      "श्री यंत्र",
      "श्री चक्र"
    ],
    "image": "yantras/sri-yantra.webp",
    "subtitle": "Many lines. One still centre.",
    "description": "A flat copper-toned interpretation of the Sri Chakra, a revered yantra in Sri Vidya traditions. Interlocking triangles, lotus forms and a central bindu inspire a contemplative object for a sacred space.",
    "details": [
      "Sri Chakra",
      "Flat-plate concept",
      "Sri Vidya tradition"
    ]
  },
  {
    "id": "meru",
    "name": "Sri Meru Yantra",
    "vernacular": "Maha Meru · Sri Chakra",
    "family": "devotional",
    "deity": "Lalita Tripura Sundari",
    "aliases": [
      "maha meru",
      "mahameru",
      "shri meru",
      "sri chakra",
      "three dimensional",
      "3d",
      "श्री मेरु"
    ],
    "image": "yantra.webp",
    "subtitle": "An invitation to centre your intention.",
    "description": "A three-dimensional interpretation of the Sri Yantra, with ascending geometric tiers and a warm brass finish. A sculptural focal point for meditation and a thoughtfully arranged sacred space.",
    "details": [
      "Maha Meru form",
      "Brass-tone concept",
      "Sri Vidya tradition"
    ]
  },
  {
    "id": "lakshmi-yantra",
    "name": "Maha Lakshmi Yantra",
    "vernacular": "Mahalakshmi · Shri",
    "family": "devotional",
    "deity": "Lakshmi",
    "aliases": [
      "mahalaxmi",
      "mahalakshmi",
      "laxmi",
      "श्री लक्ष्मी",
      "महालक्ष्मी"
    ],
    "image": "yantras/lakshmi-yantra.webp",
    "subtitle": "A place for gratitude and abundance.",
    "description": "A lotus-inspired, brass-toned yantra concept dedicated to Maha Lakshmi. Envisioned as a meaningful focal point for Lakshmi devotion, a home altar or a personal moment of gratitude.",
    "details": [
      "Maha Lakshmi",
      "Brass-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "kubera-yantra",
    "name": "Kubera Yantra",
    "vernacular": "Kuber · Dhanada",
    "family": "devotional",
    "deity": "Kubera",
    "aliases": [
      "kuber",
      "dhanada",
      "धन कुबेर",
      "कुबेर"
    ],
    "image": "yantras/kubera-yantra.webp",
    "subtitle": "Consider what you choose to value.",
    "description": "A warm antique-brass yantra concept dedicated to Kubera. Its balanced grid and substantial metal finish create a considered object to explore within the context of a personal devotional practice.",
    "details": [
      "Kubera",
      "Antique-brass concept",
      "Devotional collection"
    ]
  },
  {
    "id": "ganesha-yantra",
    "name": "Ganesha Yantra",
    "vernacular": "Ganapati · Vinayaka",
    "family": "devotional",
    "deity": "Ganesha",
    "aliases": [
      "ganesh",
      "ganpati",
      "ganapati",
      "vinayaka",
      "गणेश",
      "गणपति"
    ],
    "image": "yantras/ganesha-yantra.webp",
    "subtitle": "Begin with presence and intention.",
    "description": "A copper-toned yantra concept dedicated to Ganesha, also known as Ganapati. A thoughtful choice for a devotional corner and a personal ritual marking a meaningful beginning.",
    "details": [
      "Ganesha · Ganapati",
      "Copper-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "saraswati-yantra",
    "name": "Saraswati Yantra",
    "vernacular": "Sarasvati · Sharada",
    "family": "devotional",
    "deity": "Saraswati",
    "aliases": [
      "sarasvati",
      "sharada",
      "vidya",
      "सरस्वती",
      "शारदा"
    ],
    "image": "yantras/saraswati-yantra.webp",
    "subtitle": "Make room for learning and expression.",
    "description": "A pale gold-toned yantra concept dedicated to Saraswati. Fine engraving and a quiet, luminous finish offer a contemplative object for a study space, music corner or personal altar.",
    "details": [
      "Saraswati · Sharada",
      "Gold-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "durga-yantra",
    "name": "Durga Yantra",
    "vernacular": "Devi Durga · Shakti",
    "family": "devotional",
    "deity": "Durga",
    "aliases": [
      "devi",
      "shakti",
      "दुर्गा",
      "शक्ति"
    ],
    "image": "yantras/durga-yantra.webp",
    "subtitle": "An expression of devotion to Shakti.",
    "description": "A red-copper yantra concept dedicated to Devi Durga. Its layered geometry and warm metal finish are envisioned as a devotional focal point for a considered sacred space.",
    "details": [
      "Devi Durga",
      "Red-copper concept",
      "Devotional collection"
    ]
  },
  {
    "id": "mahamrityunjaya-yantra",
    "name": "Mahamrityunjaya Yantra",
    "vernacular": "Shiva · Tryambaka",
    "family": "devotional",
    "deity": "Shiva",
    "aliases": [
      "maha mrityunjaya",
      "mahamrityunjay",
      "mrityunjay",
      "tryambaka",
      "शिव",
      "महामृत्युंजय"
    ],
    "image": "yantras/mahamrityunjaya-yantra.webp",
    "subtitle": "Return to a quiet moment of devotion.",
    "description": "An antique copper-toned concept associated with Shiva’s Mahamrityunjaya tradition. A reflective addition to a Shiva altar, with its actual design and the intended devotional practice discussed personally.",
    "details": [
      "Shiva · Tryambaka",
      "Copper-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "hanuman-yantra",
    "name": "Hanuman Yantra",
    "vernacular": "Bajrangbali · Anjaneya",
    "family": "devotional",
    "deity": "Hanuman",
    "aliases": [
      "bajrangbali",
      "anjaneya",
      "maruti",
      "हनुमान",
      "बजरंगबली"
    ],
    "image": "yantras/hanuman-yantra.webp",
    "subtitle": "A reminder of devotion in action.",
    "description": "A warm bronze-toned yantra concept dedicated to Hanuman, also known as Anjaneya. Envisioned for a personal altar and a devotional practice grounded in attention and understanding.",
    "details": [
      "Hanuman · Anjaneya",
      "Bronze-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "baglamukhi-yantra",
    "name": "Baglamukhi Yantra",
    "vernacular": "Bagalamukhi · Pitambara",
    "family": "devotional",
    "deity": "Baglamukhi",
    "aliases": [
      "bagalamukhi",
      "pitambara",
      "bagla mukhi",
      "बगलामुखी",
      "पीताम्बरा"
    ],
    "image": "yantras/baglamukhi-yantra.webp",
    "subtitle": "A focused expression of Devi devotion.",
    "description": "A golden brass-toned yantra concept dedicated to Baglamukhi, one of the Mahavidyas. Explore this form with guidance on its particular tradition, meaning and devotional context.",
    "details": [
      "Baglamukhi · Pitambara",
      "Brass-tone concept",
      "Devotional collection"
    ]
  },
  {
    "id": "navagraha-yantra",
    "name": "Navagraha Yantra",
    "vernacular": "Nava Graha · The nine grahas",
    "family": "devotional",
    "deity": "Navagraha",
    "aliases": [
      "navgraha",
      "nava graha",
      "nine planets",
      "nine grahas",
      "नवग्रह"
    ],
    "image": "yantras/navagraha-yantra.webp",
    "subtitle": "Nine grahas. One considered composition.",
    "description": "A combined brass-toned yantra concept bringing the nine grahas into one composition: Surya, Chandra, Mangal, Budha, Brihaspati, Shukra, Shani, Rahu and Ketu. A companion to a broader conversation about your chart.",
    "details": [
      "Combined Navagraha",
      "Brass-tone concept",
      "Nine-graha composition"
    ]
  },
  {
    "id": "vastu-purusha-yantra",
    "name": "Vastu Purusha Yantra",
    "vernacular": "Vastu Mandala · Sacred space",
    "family": "space",
    "deity": "Vastu Purusha",
    "aliases": [
      "vaastu",
      "vastu mandala",
      "vastu purush",
      "home",
      "space",
      "वास्तु",
      "वास्तु पुरुष"
    ],
    "image": "yantras/vastu-purusha-yantra.webp",
    "subtitle": "Bring intention to the space you inhabit.",
    "description": "A copper-toned yantra concept inspired by the ordered grid of a Vastu mandala. A considered object for exploring the relationship between sacred geometry, architectural space and your own home.",
    "details": [
      "Vastu mandala",
      "Copper-tone concept",
      "Space & ritual"
    ]
  }
].map(yantra => ({
  ...yantra,
  category: 'yantras',
  series: yantra.family === 'planetary' ? 'navagraha-yantra' : 'sacred-yantra',
  categoryLabel: yantra.planet ? yantra.planet.toUpperCase() : yantra.family === 'space' ? 'SPACE & SACRED GEOMETRY' : 'DEVOTION & SACRED GEOMETRY',
  tag: yantra.family === 'planetary' ? 'NAVAGRAHA' : yantra.family === 'space' ? 'VASTU & SPACE' : 'SACRED FORMS',
  tradition: 'Ask about the actual yantra’s geometry, inscriptions, metal, dimensions and any ritual preparation. The AI artwork is a visual concept; placement and worship guidance should follow the tradition you practise.'
}));
